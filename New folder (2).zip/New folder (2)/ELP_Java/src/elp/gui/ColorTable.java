package elp.gui;

import java.awt.Color;

import javax.swing.JTable;
import javax.swing.table.DefaultTableCellRenderer;
import javax.swing.table.TableCellRenderer;
import javax.swing.table.TableModel;

import elp.runSinglePart;
import elp.utils.ReadXML;

public class ColorTable extends JTable
{

   private DefaultTableCellRenderer whiteRenderer;
   private DefaultTableCellRenderer grayRenderer;
   private DefaultTableCellRenderer redRenderer;

   public ColorTable()
   {
      super();
   }

   public ColorTable(TableModel tm) {
      super(tm);
   }

   public ColorTable(Object[][] data, Object[] columns)
   {
      super (data, columns);
   }

   public ColorTable(int rows, int columns)
   {
      super (rows, columns);
   }

   /**
    * If row is an even number, getCellRenderer() returns a DefaultTableCellRenderer
    * with white background. For odd rows, this method returns a DefaultTableCellRenderer
    * with a light gray background.
    */
	public TableCellRenderer getCellRenderer(int row, int column)
	{
		if (whiteRenderer == null)
		{
			whiteRenderer = new DefaultTableCellRenderer();
		}
		if (grayRenderer == null)
		{
			grayRenderer = new DefaultTableCellRenderer();
			grayRenderer.setBackground(Color.lightGray);
		}
		if (redRenderer == null){
			redRenderer = new DefaultTableCellRenderer();
			redRenderer.setBackground(Color.red);
		}

		//if ((Integer)runSinglePart.rowData[11] < 75){
			if ( (row % 2) == 0 )
				return whiteRenderer;
			else
				return grayRenderer;
		/*}else{
			return redRenderer;
		}*/
	   
	}
}