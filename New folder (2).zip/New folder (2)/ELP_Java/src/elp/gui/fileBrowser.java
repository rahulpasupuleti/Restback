package elp.gui;
import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Dimension;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.ItemEvent;
import java.awt.event.ItemListener;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.io.BufferedReader;
import java.io.File;
import java.io.FileOutputStream;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.io.PrintStream;
import java.net.InetAddress;
import java.net.UnknownHostException;
import java.text.SimpleDateFormat;
import java.sql.Array;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;

import java.util.Date;
import java.util.List;

import javax.swing.AbstractButton;
import javax.swing.BorderFactory;
import javax.swing.BoxLayout;
import javax.swing.ButtonGroup;
import javax.swing.JButton;
import javax.swing.JCheckBox;
import javax.swing.JComboBox;
import javax.swing.JFileChooser;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JRadioButton;
//import javax.swing.filechooser.*;
import javax.swing.JScrollPane;
import javax.swing.JSplitPane;
import javax.swing.JTable;
import javax.swing.JTextField;
import javax.swing.SwingConstants;
import javax.swing.SwingUtilities;
import javax.swing.UIManager;
import javax.swing.event.DocumentEvent;
import javax.swing.event.DocumentListener;
import javax.swing.filechooser.FileNameExtensionFilter;
import javax.swing.table.DefaultTableModel;
import javax.swing.table.TableModel;

import elp.utils.ConnectMSSQLServer;
import elp.utils.Inputs;
import elp.utils.ReadXML;

import java.util.Random;

public class fileBrowser extends JPanel
                             implements ActionListener {
    /**
	 * Main GUI Class 
	 */
	private static final long serialVersionUID = 1L;
	
	JButton openButton, cancelButton, executeButton, clearLogButton, exportExcelButton, getAssembliesButton;
    JTextField  fileField;
    JLabel fileLabel;
    JLabel inputLabel;
    
    JLabel PNLabel;
    JLabel SNLabel;
    JTextField  PNField;
    JTextField  SNField;
    
    JLabel toolLabel;
    @SuppressWarnings("rawtypes")
	JComboBox toolChooser;
    public JComboBox assemblyChooser;
    JRadioButton inputXMLButton;
    JRadioButton inputBatchButton;
    JRadioButton inputDBButton;
    JCheckBox check = new JCheckBox("Save Seperate Results", false);
    
    JFileChooser fc;
    JFileChooser fc1;
    FileWriter fw ;
    BufferedReader bf;
    JPanel filePane;
    File excelFile;
    FileNameExtensionFilter filter1, filter2;
    static int flagtemp = 20;
    static int licen1 = 11;
    static int detmactype = 20;
    static int flagtempscaler = 6;    
    static int detmactypescaler = -10;
    static String utype = "us"; //code build liberaries united states setting
    static String notApplicFlag = "na"; //print na (not applicable) for parts without data
    static String Err1codeFlag = "er"; 
    static String GreaterThanFlag = "gtr"; 
    static String RandomNumberCheck = "ro"; 
    
    ///// Amit Added
    FileWriter FleetexcelFile;
    ///// Amit Added
        
	public static DefaultTableModel listTableModel;
    public static JSplitPane tablePane;
    public static Object[][] row;
    public static ColorTable table;
    public static String runMode; 
    static String[] assemblies;
    private String[] columnNames= {"Part Number","Serial Number",
            "Temperature","StickSlip","Lateral","Drill Hours",
            "Worst Life","25% Life","Mean Life","75% Life","Best Life",
            "Risk (%)","Part Description","Comments"};
    final JPanel DBComponents ;
	@SuppressWarnings({ "unchecked", "rawtypes" })
	public fileBrowser() {
        super(new BorderLayout());
        
        //list of tools/product families that are available in ELP
        String tools[] = {"Select Tool","ASS", "BCPM", "OnTrak", "ATCurve", "Probe", "LithoTrak","CoilTrak","HydraulicUnit"};
        
        //mode selection buttons
        inputXMLButton = new JRadioButton("XML");
        inputDBButton = new JRadioButton("Database");
        inputBatchButton = new JRadioButton("Batch");
        inputDBButton.setSelected(true);
        
        ButtonGroup InputGroup = new ButtonGroup();
        InputGroup.add(inputXMLButton);
        InputGroup.add(inputDBButton);
        InputGroup.add(inputBatchButton);
        
        //drop-down list to select the production family
        toolChooser = new JComboBox(tools);
        toolChooser.setSelectedIndex(0);
        assemblyChooser = new JComboBox(tools);
        
        //Get Assemblies button
        getAssembliesButton = new JButton("Get Assemblies");
        getAssembliesButton.addActionListener(this);
        getAssembliesButton.setEnabled(false);
        
        //Select the files for XML/Batch run modes 
        fileField = new JTextField ("Click 'Browse' and select the file...", 30);
        fileField.setEditable(false);
        fileField.addMouseListener(new MouseAdapter() {
        	  
        public void mouseClicked(MouseEvent e) {
        	if (fileField.getText().equalsIgnoreCase("Click 'Browse' and select the file..."))
        		fileField.setText("");
        	}
        });
        fileField.getDocument().addDocumentListener(new DocumentListener() {
        	public void changedUpdate(DocumentEvent e) {
        		changed();
        	}
        	public void removeUpdate(DocumentEvent e) {
        		changed();
        	}
        	public void insertUpdate(DocumentEvent e) {
        		changed();
        	}

        	public void changed() {
        		if (fileField.getText().equals("")){
        	    	executeButton.setEnabled(false);
        	    }
        	    else {
        	    	executeButton.setEnabled(true);
        	    }
        	}
        });
        PNLabel = new JLabel("Part Number : ");
        SNLabel = new JLabel("Serial Number : ");
        PNField = new JTextField("",15);
        SNField = new JTextField("",15);
        		
        SNField.addMouseListener(new MouseAdapter() {
      	  public void mouseClicked(MouseEvent e) {
      		  if (SNField.getText().equalsIgnoreCase(""))
      		  SNField.setText("");
      	  }
      	});
        SNField.getDocument().addDocumentListener(new DocumentListener() {
			public void changedUpdate(DocumentEvent e) {
				changed();
			}
			public void removeUpdate(DocumentEvent e) {
				changed();
			}
			public void insertUpdate(DocumentEvent e) {
				changed();
			}
			public void changed() {
				if (SNField.getText().equals("")){
					getAssembliesButton.setEnabled(false);
				}else{
					getAssembliesButton.setEnabled(true);
				}
			}
      	});
        toolLabel = new JLabel ("Tool Selection: ");
        fileLabel = new JLabel ("File Path : ");
        inputLabel = new JLabel ("Input Type  : ");
        //inputLabel.setBorder(BorderFactory.createEtchedBorder());
        //fileLabel.setBorder(BorderFactory.createEtchedBorder());
        //toolLabel.setBorder(BorderFactory.createEtchedBorder());
        
        //Create the Browse File button.  
        openButton = new JButton("Browse");
        openButton.addActionListener(this);
        
        assemblyChooser.setVisible(false);
        
        DBComponents = new JPanel();
        DBComponents.add(PNLabel);
        DBComponents.add(PNField);
        DBComponents.add(SNLabel);
        DBComponents.add(SNField);
        DBComponents.add(getAssembliesButton);
        DBComponents.add(assemblyChooser);
        
        final JPanel XMLComponents = new JPanel();
        XMLComponents.add(fileLabel);
        XMLComponents.add(fileField);
        XMLComponents.add(openButton);
        XMLComponents.add(toolLabel);
        XMLComponents.add(toolChooser);
        
        JPanel input = new JPanel();
        input.add(inputLabel);
        input.add(inputDBButton);
        input.add(inputXMLButton);
        input.add(inputBatchButton);
        
        filePane = new JPanel();
        filePane.setLayout(new BorderLayout());
        filePane.add(input,BorderLayout.WEST);
        filePane.add(DBComponents, BorderLayout.EAST);
        check.setVisible(false);
        check.addItemListener(new ItemListener() {
            public void itemStateChanged(ItemEvent e) {
              System.out.println("Save Results Seperately " + check.isSelected());
            }
          });
        
        ItemListener itemListener = new ItemListener() {
        	public void itemStateChanged(ItemEvent itemEvent) {
        		AbstractButton aButton = (AbstractButton)itemEvent.getSource();
        		int state = itemEvent.getStateChange();
        		if (state == ItemEvent.SELECTED) {
        			check.setVisible(false);
        			DBComponents.setVisible(false);
        			XMLComponents.setVisible(false);
        			filePane.remove(DBComponents);
        			filePane.remove(XMLComponents);
    				//if select xml mode
        			if (aButton.getText().equals("XML")) {
        				check.setVisible(false);
        				fc.setFileFilter(filter1);
        	        	XMLComponents.add(toolLabel);
        				XMLComponents.add(toolChooser);
        				XMLComponents.setVisible(true);
        				filePane.add(XMLComponents, BorderLayout.EAST);	
        			//if select batch mode
        			}else if(aButton.getText().equals("Batch")){
        				check.setVisible(true);
        				fc.setFileFilter(filter2);
        	        	XMLComponents.remove(toolLabel);
        				XMLComponents.remove(toolChooser);
        				XMLComponents.setVisible(true);
        				filePane.add(XMLComponents, BorderLayout.EAST);	
        			}
        			//if select database mode
        			else{
        				check.setVisible(false);
        				DBComponents.setVisible(true);
        				filePane.add(DBComponents, BorderLayout.EAST);	
        			}
        		}
        	}
        };
        
        inputDBButton.addItemListener(itemListener);
        inputXMLButton.addItemListener(itemListener);
        inputBatchButton.addItemListener(itemListener);
        
        //filePane.add(XMLComponents, BorderLayout.EAST);
        
        //Create a file chooser
        fc = new JFileChooser();
        filter1 = new FileNameExtensionFilter("XML", "xml");
        filter2 = new FileNameExtensionFilter("Text", "txt");
    	
        fc1 = new JFileChooser();
        //fc.setFileSelectionMode(JFileChooser.DIRECTORIES_ONLY); for directories only.
        
      //Create the Execute Single Revision button.
        clearLogButton = new JButton("Clear Table...");
        clearLogButton.addActionListener(this);
        
        exportExcelButton = new JButton("Export to Excel");
        exportExcelButton.addActionListener(this);
        exportExcelButton.setEnabled(false);
        exportExcelButton.setVisible(false);
        
        //Create the Execute Single Revision button.
        executeButton = new JButton("Execute ...");
        executeButton.addActionListener(this);
        //executeButton.setEnabled(false);
        
        //Create the Cancel button.  
        cancelButton = new JButton("Close / Cancel");
        cancelButton.addActionListener(this);

        //For layout purposes, put the buttons in a separate panel
        JPanel buttonPanel = new JPanel(); //use FlowLayout
        
        //Add the buttons and Textfield to the panel.
        buttonPanel.add(check);
        buttonPanel.add(clearLogButton);
        buttonPanel.add(executeButton);
        buttonPanel.add(exportExcelButton);
        buttonPanel.add(cancelButton);
        
        JPanel statusPanel = new JPanel();
        statusPanel.setPreferredSize(new Dimension(getWidth(), 16));
        statusPanel.setLayout(new BoxLayout(statusPanel, BoxLayout.X_AXIS));
        JLabel statusLabel = new JLabel("status");
        statusLabel.setHorizontalAlignment(SwingConstants.LEFT);
        statusPanel.add(statusLabel);
        
        tablePane = new JSplitPane();
        tablePane.setLayout(new BorderLayout());
        tablePane.setBorder(BorderFactory.createLineBorder(Color.black));
        
        listTableModel = new DefaultTableModel(row, columnNames);
        table = new ColorTable(listTableModel);
        table.setFillsViewportHeight(true);
        
        tablePane.add(new JScrollPane(table));
        
        //logPane logPane = new logPane();
        //tablePane.add(logPane);
        //PrintStream ps = System.out;
        //System.setOut(new PrintStream(new StreamCapturer("STDOUT", logPane, ps)));

        //Add all the panels to the frame.
        add(filePane, BorderLayout.PAGE_START);
        add(buttonPanel, BorderLayout.PAGE_END);
        add(tablePane, BorderLayout.CENTER);
    }

    @SuppressWarnings("unchecked")
	public void actionPerformed(ActionEvent e) {
    	//Handle open button action.
    	Inputs.mainPN = PNField.getText().trim();
		Inputs.mainSN = ReplaceCarrats(SNField.getText().trim());
		String folder = new String();
		//String my_userName = System.getProperty("path");
		//String my_userName = System.getenv("ELP_Home");
		
		//create folder and error log file under ELP_Home path
		folder = "\\PN" + Inputs.mainPN + "_SN" + Inputs.mainSN;		
		File file1 = new File(System.getenv("ELP_Home").concat("\\javaError.log"));
		
		try {
			FileOutputStream fos = new FileOutputStream(file1);
			PrintStream ps = new PrintStream(fos);
			System.setErr(ps);
    	}catch(IOException e1){
    		e1.printStackTrace();
    	}
		// Browse File button action
		if (e.getSource() == openButton) {
        	
            int returnVal = fc.showOpenDialog(fileBrowser.this);
            if (returnVal == JFileChooser.APPROVE_OPTION) {
                File file = fc.getSelectedFile();
                fileField.setText(file.getPath());
                executeButton.setEnabled(true);
            }
        }
        // Cancel button action.
        else if (e.getSource() == cancelButton) {
        	System.exit(0);
        }
        
        else if (e.getSource() == exportExcelButton){
        	FileNameExtensionFilter filter = new FileNameExtensionFilter("Excel", "xls");
        	fc1.setFileFilter(filter);
        	
        	int returnVal = fc1.showSaveDialog(fileBrowser.this);
        	if (returnVal == JFileChooser.APPROVE_OPTION) {
            	toExcel(table,fc1.getSelectedFile());
            }
        }
		//Clear Table button action
        else if (e.getSource() == clearLogButton) {
        	listTableModel.getDataVector().removeAllElements();
        	listTableModel.fireTableDataChanged();
        }
		//Get Assembly button action
        else if (e.getSource() == getAssembliesButton) {
        	
        	try {
				Class.forName("com.microsoft.sqlserver.jdbc.SQLServerDriver");
			} catch (ClassNotFoundException e1) {
				e1.printStackTrace();
			}	
        	
        	//user accound info for connection MaPS database
    		String userName = "elpuser";
    		String pwd = "!M@PS_elp";
    		String url = "jdbc:sqlserver://10.167.38.115;portNumber=5007;DatabaseName=MaPS_Repl";//
    		//String userName = "elpuser";
    		//String pwd = "eLpUSeR_Qa_16";
    		//String url = "jdbc:sqlserver://10.167.59.33;portNumber=5007;DatabaseName=MAPS_REPL";//
    		Connection conn;
    		Statement sta;
    		List<String> resultsList = new ArrayList<String>();
    		List<String> valuesList = new ArrayList<String>();
			try {
				conn = DriverManager.getConnection(url,userName,pwd);
				sta = conn.createStatement();
				String SQLstatement = "select convert(varchar(10),ai.assemblydate,121) + ' - ' + case when AssyComplete = 1 then '' ";   
				SQLstatement = SQLstatement + "else convert(varchar(10),isnull(ai.disassemblydate,''),121) end as label,";  
				SQLstatement = SQLstatement + "ai.id as value ";   
				SQLstatement = SQLstatement + "from assemblyInfo as ai join serializedComponents as sc ";   
				SQLstatement = SQLstatement + "on (sc.[id] = ai.serializedComponentId)";   
				SQLstatement = SQLstatement + "where (case when len(sc.SAPEquipmentNo) > 0 then sc.SAPEquipmentNo else '<>' + sc.trackingId end)='";
				SQLstatement = SQLstatement + Inputs.mainSN +"' order by ai.assemblyDate DESC" ;
				ResultSet rs1 = sta.executeQuery(SQLstatement);
				while(rs1.next()) {
				    resultsList.add(rs1.getString("label"));
				    valuesList.add(rs1.getString("value"));
				}
						
	    	} catch (SQLException e1) {
				e1.printStackTrace();
			}
			String[] results = resultsList.toArray(new String[resultsList.size()]);
			assemblies = valuesList.toArray(new String[valuesList.size()]);
    		System.out.println("Connected to SQL server..");
    		DBComponents.remove(assemblyChooser);
    		
    		assemblyChooser = new JComboBox(results);
    		assemblyChooser.setVisible(true);
    		DBComponents.add(assemblyChooser);
    		
    		DBComponents.revalidate();
    		DBComponents.repaint();
        }
        // Execute button action.
	    else if (e.getSource() == executeButton) {
	    	//
	    	Inputs.tool = "";
    		try {
    			//if under xml mode
    			if (inputXMLButton.isSelected()){
    				runMode = "xml";
    				
    				if (!(toolChooser.getSelectedIndex() == 0)){	//get product family	
    					Inputs.tool = toolChooser.getSelectedItem().toString().toLowerCase();
    					new ReadXML(fileField.getText()); //get run history data and perform ELP analysis		
    					folder = "\\PN" + Inputs.mainPN.trim() + "_SN" + Inputs.mainSN.trim();
    					excelFile = new File(fc.getSelectedFile().getParent().concat("\\"+ Inputs.mainPN.trim() + "_" + Inputs.mainSN.trim()));
    					// save table to excel file
    		    		toExcel(table,excelFile);
    				}else{ //if no product family is selected, pop-up error message
    					JOptionPane.showMessageDialog(this, "Please Select a Tool from Drop Down .... ",
    							"Missed Something !!!", JOptionPane.WARNING_MESSAGE);
    				}
    			}else if(inputDBButton.isSelected()){ // if under database mode
    				runMode = "db";
    				Inputs.assemblyID ="";
    				if(assemblies!=null)
    				{
    					if(assemblies.length>0)
    					{
    						Inputs.assemblyID = assemblies[assemblyChooser.getSelectedIndex()];
    					}
    				}
    				String tempfile_db = System.getenv("ELP_Home");
    				//call function ConnectMSSQLServer
    				new ConnectMSSQLServer(Inputs.mainPN.trim(), Inputs.mainSN.trim(),tempfile_db);
    				//export the results to Excel file
					excelFile = new File(System.getenv("ELP_Home").concat(folder + "\\"+ Inputs.mainPN.trim() + "_" + Inputs.mainSN.trim()));
					toExcel(table,excelFile);
				//under batch mode	
    			}else if (inputBatchButton.isSelected()){
    				runMode = "batch";
    				final int lhs = 0;
					final int rhs = 1;

					check.setEnabled(true);
					check.setVisible(true);
					BufferedReader  bfr = new BufferedReader(new FileReader(new File(fileField.getText())));
					System.out.println("Connected to 1SQL server..");
					String line;
					
					if(!check.isSelected())
					{
						excelFile = new File(fc.getSelectedFile().getParent().concat("\\FleetRun"));
						CreateFleetFile(excelFile);
					}
										
					while ((line = bfr.readLine()) != null) {
						if (!line.startsWith("#") && !line.isEmpty()) {
							String[] pair = line.trim().split(",");
							try{
								Inputs.mainPN = pair[lhs].trim().toUpperCase();
								Inputs.mainSN = ReplaceCarrats(pair[rhs].trim().toUpperCase());
							}catch(ArrayIndexOutOfBoundsException e1){
								System.out.println(e1);}
							
							String tempfile_batch = fc.getSelectedFile().getParent();
							new ConnectMSSQLServer(Inputs.mainPN, Inputs.mainSN,tempfile_batch);
							
							if(check.isSelected()){
								folder = "\\PN" + Inputs.mainPN + "_SN" + Inputs.mainSN;
								//File excelFile_akae = new File(fc.getSelectedFile().getParent().concat("\\"+ Inputs.mainPN + "_" + Inputs.mainSN));
								//excelFile = new File(System.getenv("ELP_Home").concat(folder + "\\"+ Inputs.mainPN + "_" + Inputs.mainSN));
								excelFile = new File(fc.getSelectedFile().getParent().concat(folder + "\\"+ Inputs.mainPN + "_" + Inputs.mainSN));
								toExcel(table,excelFile);
								clearLogButton.doClick();
							}
							else
							{
								toExcelFleet(table);								
								clearLogButton.doClick();
							}
						}
					}
					bfr.close();
					if(!(check.isSelected())){
						CloseFleetFile();					
					}
    			}
			} catch (IOException | ClassNotFoundException | SQLException e1) {
				e1.printStackTrace();
			}
    		
	    }
		
    }

    private static String ReplaceCarrats(String This_SN)
    {
    	String This_SNOld = This_SN;
    	This_SN = This_SN.replaceAll("<|>", "");
    	if(This_SNOld.length()==This_SN.length())
    	{
    		Inputs.CarrateReplaceSTR = "";
    	}
    	else
    	{
    		Inputs.CarrateReplaceSTR = "<>";
    	}
    	return This_SN;
    }
    /**
     * Create the GUI and show it.  
     * @throws UnknownHostException 
     */
    private static void createAndShowGUI() throws UnknownHostException {
        //Create and set up the window.
    	
    	String hostNameCanonical = InetAddress.getLocalHost().getCanonicalHostName();
        String hostName = InetAddress.getLocalHost().getHostName();
        String sn;
        sn  = notApplicFlag.concat("me");
    	if (hostName.toLowerCase().contains("bhi") && GetBHILicense(flagtemp,licen1,detmactype,sn,".") && hostNameCanonical.toLowerCase().contains("ent.bhicorp.com")){
    	//if (hostName.toLowerCase().contains("bhi") && hostNameCanonical.toLowerCase().contains("ent.bhicorp.com")){
	        JFrame frame = new JFrame("Electronics Lifetime Prediction - Contact Dan Zhang, Timm Schlosser, and Gulshan Singh for startup problems or questions");
	        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
            
	        frame.add(new fileBrowser());
	        frame.setPreferredSize(new Dimension(1400,450));
	        frame.getLayeredPane();
	        //Display the window.
	        frame.pack();
	        frame.setVisible(true);
    	}
    }

    public void toExcel(JTable table, File file){
        try{
            TableModel model = table.getModel();
            String timestamp = 
            	    new java.text.SimpleDateFormat("MMddHHmmss").format(new Date());
            String datestamp = 
            	    new java.text.SimpleDateFormat("MM/dd/yyyy").format(new Date());
            
            FileWriter excel = new FileWriter(file +"_" + timestamp+ ".xls");
            //Dan changed on 09/23/2016 try to add date stamp and version ID to excel out put
            //excel.write(Inputs.mainPN + "\t" + Inputs.mainSN + "\t" + Inputs.productDescription + "\n");
            excel.write(Inputs.mainPN + "\t" + Inputs.mainSN + "\t" + Inputs.productDescription + "\t" + datestamp + "\t" + "ELP_V4_4"+"\n");

            for(int i = 0; i < model.getColumnCount(); i++){
                excel.write(model.getColumnName(i) + "\t");
            }

            excel.write("\n");

            for(int i=0; i< model.getRowCount(); i++) {
                for(int j=0; j < model.getColumnCount(); j++) {
                    excel.write(model.getValueAt(i,j).toString()+"\t");
                }
                excel.write("\n");
            }

            excel.close();

        }catch(IOException e){ System.out.println(e); }
    }

    public void toExcelFleet(JTable table)
    {
        try
        {
        	String datestamp = 
            	    new java.text.SimpleDateFormat("MM/dd/yyyy").format(new Date());
        	
        	TableModel model = table.getModel();
        	
        	//Dan changed on 09/26/2016 try to add date stamp and version ID to excel out put
            //FleetexcelFile.write(Inputs.mainPN + "\t" + Inputs.mainSN + "\t" + Inputs.productDescription + "\n");
        	FleetexcelFile.write(Inputs.mainPN + "\t" + Inputs.mainSN + "\t" + Inputs.productDescription + "\t" + datestamp + "\t" + "ELP_V4_4" + "\n");

            for(int i = 0; i < model.getColumnCount(); i++) 
            {
            	FleetexcelFile.write(model.getColumnName(i) + "\t");
            }

            FleetexcelFile.write("\n");

            for(int i=0; i< model.getRowCount(); i++) 
            {
                for(int j=0; j < model.getColumnCount(); j++) 
                {
                	FleetexcelFile.write(model.getValueAt(i,j).toString()+"\t");
                }
                FleetexcelFile.write("\n");
            }
        }
        catch(IOException e)
        {
        	System.out.println(e); 
        }
    }
    
    public void CreateFleetFile(File file)
    {
        try
        {
        	String timestamp = 
            	    new java.text.SimpleDateFormat("MMddHHmmss").format(new Date());            
        	FleetexcelFile = new FileWriter(file +"_" + timestamp+ ".xls");   
        }
        catch(IOException e)
        {
        	System.out.println(e); 
        }
    }
    
    public void CloseFleetFile()
    {
        try
        {
        	FleetexcelFile.close();
        }
        catch(IOException e)
        {
        	System.out.println(e); 
        }
    }
    
    public static boolean GetBHILicense(int x1, int y1, int z1,String nme1,String str_token) {
        
        String s;
        String propert_1;
        s = utype;
        s=s.concat(Err1codeFlag);
        s=s.concat(str_token);
        boolean before = true;  
        boolean before2 = true;  
        Random rBHI_IPaddress = new Random();
        double thisComputer_IP = rBHI_IPaddress.nextDouble();
        s = s.concat(nme1);     
        propert_1 = System.getProperty(s);        
        return before;
     }
    
    
    public static void main(String[] args) {
        //Schedule a job for the event dispatch thread:
        //creating and showing this application's GUI.
    	flagtemp = flagtemp-flagtempscaler + 100+1;
        detmactype = detmactype+detmactypescaler+15;
        licen1 = licen1 - 1;
        SwingUtilities.invokeLater(new Runnable() {
            public void run() {
                //Turn on metal's use of bold fonts
                UIManager.put("swing.boldMetal", Boolean.TRUE); 
                try {
					createAndShowGUI();
				} catch (UnknownHostException e) {
					e.printStackTrace();
				}
            }
        });
    }
}