package elp;

import java.io.IOException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import org.apache.commons.math3.distribution.NormalDistribution;

import elp.utils.*;

public class runSinglePart {
	public static int NumMCSRuns = 500;
	public static int MCS_Run_Index = 0;
	public static int failures =0;
	
    double minOperatingTime = 1;
    double Per_025;
    double Per_25;
    double Per_5 ;
    double Per_75 ;
    double Per_975 ;
    
    double tempDistMean[][];
	double tempDistAll[];
	double tempDistLB[];
	double tempDistUB[];
	
	double yeta;
	double lifeMean;
	double Pf;
	double varDistributionRand_25Tot;
	double varDistributionRand_75Tot;
	double varDistributionRand_95Tot;
	
	//////kaleami 06/18/2015//////////////////////////
	double Var_Distribution_Rand_25Tot_max;
    double Var_Distribution_Rand_95Tot_max;
    double Var_Distribution_Rand_25Tot_min;
    double Var_Distribution_Rand_95Tot_min;
    double min_pred_temp;
    double max_pred_temp;
    //////kaleami 06/18/2015//////////////////////////
	
    public static boolean GenerateRandomMatFlag;
    public static Object[] rowData = {new String(), new String(), new Double(0), new Double(0),  new Double(0), new Double(0), new Double(0),   
    	new Double(0), new Double(0), new Double(0), new Double(0), new Integer(0), new String(), new String(), new String()};
    
    String fileName;
    NormalDistribution normalDist;
    
	public runSinglePart() throws IOException{
		/* this function is equivalent to the PfCommandButton1_ClickLastRun function in VB
		 * 
		 */
		double CalculatedRisk = 0; 
	    GenerateRandomMatFlag = false;
	    
	    runSinglePartUtil.Random_Matrix = new double[NumMCSRuns][10];
	    for (int i = 0; i < NumMCSRuns; i++)
			Arrays.fill(runSinglePartUtil.Random_Matrix[i], 0);
	    
	    
		if ((Inputs.TotaldrillingHours > 0) ){//&& (Inputs.lateral1 > 0) && (Inputs.temperature1 > 0)) {
			
		    int Countfailures = 0;
	        double Ave_Erro = 0;
	        
	        new ModelWeight();
	        
	        Inputs.lifeMultFactor = 1;
	        ModelWeight.meanLifeUnRepairedParts = 0;
	        int Countfailure = 0;
	        //Thought Inputs.numDataSets should have been used but in vba, ComprehensiveExtract_Click() function this value is hardcoded with following statement
	        //Call PfCommandButton1_ClickLastRun(2, 0)
	        int EvaluateRun_Row = 1;
	        
	        for (int i = 0; i < EvaluateRun_Row; i++){
	        	ModelWeight.yetaPfLife();
	        	
	            if((ModelWeight.lifeMean <= Inputs.maxOperatingTime) && (ModelWeight.lifeMean >= minOperatingTime)){
	            	// generate random numbers moved inside getProbabilityMCS() ->.... getLifeSingleRevision()
	            	CalculatedRisk = GetProbabilityMCS(i);
	            }else{
	                 System.out.println("Life is Out Of bounds");
	            }
	            Countfailures = Countfailures + 1;
	        }
	        String tabs = "\t\t";
	        if (Inputs.SN.length() >13) tabs = "\t";
	        System.out.print(Inputs.PN + "\t"); 
	        System.out.print( Inputs.SN + tabs);
	        System.out.printf("%1$.2f", Inputs.TotaldrillingHours ); System.out.print("\t");
	        System.out.printf("%1$.2f", Per_025 ); System.out.print("\t");
	        System.out.printf("%1$.2f", Per_25 ); System.out.print("\t");
	        System.out.printf("%1$.2f", Per_5 ); System.out.print("\t");
	        System.out.printf("%1$.2f", Per_75 ); System.out.print("\t");
	        System.out.printf("%1$.2f", Per_975 ); System.out.print("\t");
	        System.out.println((int)(Math.round(CalculatedRisk*100)) +"%");
	        System.out.printf("%d", Inputs.numDataSets ); System.out.print("\t");
	        
	        rowData[0] = Inputs.PN;
	        rowData[1] = Inputs.SN;
	        rowData[2] = (double)Math.round(ModelWeight.cumulativeTemp * 100) / 100;
	        rowData[3] = (double)Math.round(ModelWeight.cumulativeStSlip * 100) / 100;
	        rowData[4] = (double)Math.round(ModelWeight.cumulativeLat * 100) / 100;
	        rowData[5] = (double)Math.round((Inputs.TotaldrillingHours + Inputs.drillingHrsBeforeRepair) * 1000) / 1000;
	        rowData[6] = (double)Math.round((Per_025 + Inputs.drillingHrsBeforeRepair) * 1000) / 1000;
	        rowData[7] = (double)Math.round((Per_25 + Inputs.drillingHrsBeforeRepair) * 1000) / 1000;
	        rowData[8] = (double)Math.round((Per_5 + Inputs.drillingHrsBeforeRepair) * 1000) / 1000;
	        rowData[9] = (double)Math.round((Per_75 + Inputs.drillingHrsBeforeRepair) * 1000) / 1000;
	        rowData[10] = (double)Math.round((Per_975 + Inputs.drillingHrsBeforeRepair) * 1000) / 1000;
	        rowData[11] = (int)(Math.round(CalculatedRisk*100));
	        rowData[12] = Inputs.partDescription;
	        rowData[13] = "";
	        
	        //Dan 2017/06/09 validating model for 10282145
	        //String[] notEnoughFailureData = {"10160257","10170967", "10074526", "10246547", "10160282", "10246544", "10282145"};
	        //PN 10160257, "10170967", "10246547"updated on Aug 2016 
	        //PN"10160282" updated on jun 2016
	        //PN 10074526 Silenced since it's a battery
	        String[] notEnoughFailureData = {"10246544"};
	        List<String> NotEnoughFailureData = new ArrayList<String>(Arrays.asList(notEnoughFailureData));
	        if(NotEnoughFailureData.contains(Inputs.PN)){
	        	rowData[13] = "Not Enough failure Data To Build Model";
	        }else{
	        	
		        if (Inputs.numEmptyData > 0)
		        	rowData[13] = "(1) Missing Data For " + Inputs.numEmptyData + " Runs.." + "(" + Math.round(Inputs.CalcPMD*100) + "%)";
		        if (Inputs.repairFlag && (Inputs.PN.equalsIgnoreCase("A1000888000")|| Inputs.PN.equalsIgnoreCase("10079662")|| Inputs.partDescription.startsWith("TRANSFORMER")
	    				|| Inputs.partDescription.startsWith("ALTERNATOR") || Inputs.partDescription.startsWith("PUMP") || Inputs.partDescription.startsWith("HYDRAULIC") ))
		        	rowData[13] = rowData[13] + " (2) This Serial Number underwent repairs and/or revision upgrades..";
		        if(Inputs.multiplePN)
		        	rowData[13] = rowData[13] + " (3) This Serial Number underwent multiple part number changes..";
	        }
	        
			if (Countfailure > 0) {
	            Ave_Erro = Ave_Erro / Countfailures;
	        }
		}
	}

	private void FindMaxi_Min_Hrs(double lifemean_temp,double Cumulative_DrillHrs_temp,double Var_Distribution_Rand_25Tot, double Var_Distribution_Rand_95Tot)
	{
	    min_pred_temp = lifemean_temp;
	    max_pred_temp = Cumulative_DrillHrs_temp;
	    double Var_25Tot_ratio = Var_Distribution_Rand_25Tot / lifemean_temp;
	    double Var_95Tot_ratio = Var_Distribution_Rand_95Tot / lifemean_temp;
	    Var_Distribution_Rand_25Tot_min = Var_Distribution_Rand_25Tot;
	    Var_Distribution_Rand_95Tot_min = Var_Distribution_Rand_95Tot;
	    Var_Distribution_Rand_25Tot_max = Cumulative_DrillHrs_temp * Var_25Tot_ratio;
	    Var_Distribution_Rand_95Tot_max = Cumulative_DrillHrs_temp * Var_95Tot_ratio;
	    
	    if (Cumulative_DrillHrs_temp < lifemean_temp)
	    {
	        min_pred_temp = Cumulative_DrillHrs_temp;
	        max_pred_temp = lifemean_temp;
	        Var_Distribution_Rand_25Tot_min = Cumulative_DrillHrs_temp * Var_25Tot_ratio;
	        Var_Distribution_Rand_95Tot_min = Cumulative_DrillHrs_temp * Var_95Tot_ratio;
	        Var_Distribution_Rand_25Tot_max = Var_Distribution_Rand_25Tot;
	        Var_Distribution_Rand_95Tot_max = Var_Distribution_Rand_95Tot;
	    }
	}

	private double GetProbabilityMCS(int rowID) {
		
		@SuppressWarnings("unused")
		double PivotForOutliers ,adderLifeCorrection=0;
		int validLifeBounded = 0;
  
		tempDistMean = new double[NumMCSRuns][3];
		tempDistLB = new double[NumMCSRuns];
		tempDistUB = new double[NumMCSRuns];
		tempDistAll = new double[NumMCSRuns*4];
		
		for (int i=0;i<NumMCSRuns;i++){
			Arrays.fill(tempDistMean[i],0);
		}
			Arrays.fill(tempDistLB,0);
			Arrays.fill(tempDistUB,0);
			Arrays.fill(tempDistAll,0);
		
		int TotalDataInHistogram;
		double MeanPf = 0;
	    double MeanLife = 0;
	    double MeanLife25 = 0;
	    double MeanLife975 = 0;
 		double modelBasedDrillHoursDiff = Math.abs(ModelWeight.lifeMean - Inputs.TotaldrillingHours);
		double cumulativeDrillHours = (ModelWeightUtil.multFactor)*runSinglePartUtil.ComputeLifeMult();
	    double CumulativeBasedDrillHrs_Diff = Math.abs(cumulativeDrillHours - Inputs.TotaldrillingHours);
	    
	    if (Inputs.TotaldrillingHours > Inputs.maxFailureTime) {
	        PivotForOutliers = (Inputs.maxFailureTime + Inputs.maxOperatingTime) / 2;
	    }else{
	        PivotForOutliers = Inputs.maxFailureTime;
	    }
	    
	    //////////kaleami 06/08/2015////////////////
	    
	    double Delta_glb_sum = Inputs.Delta_temp_glb + Inputs.Delta_lat_glb + Inputs.Delta_stsl_glb + Inputs.Delta_jarr_glb + Inputs.Delta_Hrs_glb + Inputs.Delta_axial_glb;
	    //////////kaleami 06/08/2015////////////////
	    		
	    int i=0;
	    while(i < NumMCSRuns){
	    	MCS_Run_Index =i;
	    	
			try {
				validLifeBounded = GetRandLifeAndPF_MCS(i);
				FindMaxi_Min_Hrs(lifeMean, cumulativeDrillHours, varDistributionRand_25Tot, varDistributionRand_95Tot);
			} catch (IOException e) {
				e.printStackTrace();
			}
			if (validLifeBounded == 1) 
			{					
				if (Inputs.failureStatus == true && (Delta_glb_sum >= 2)) {
					tempDistMean[i][0] = ((4.0 / 5.0) * min_pred_temp + (1.0 / 5.0) * max_pred_temp);
					tempDistMean[i][1] = ((4.0 / 5.0) * Var_Distribution_Rand_25Tot_min +(1.0 / 5.0)* Var_Distribution_Rand_25Tot_max);
					tempDistMean[i][2] = ((4.0 / 5.0) * Var_Distribution_Rand_95Tot_min + (1.0 / 5.0) * Var_Distribution_Rand_95Tot_max);
				}
				else if ((Inputs.failureStatus == false && Delta_glb_sum >= 2) || (Inputs.Check_Incident_History == 1 && Delta_glb_sum >= 1))
				{
					tempDistMean[i][0] = ((7.0 / 10.0) * min_pred_temp + (3.0 / 10.0) * max_pred_temp);
					tempDistMean[i][1]  = ((7.0 / 10.0) * Var_Distribution_Rand_25Tot_min + (3.0 / 10.0) * Var_Distribution_Rand_25Tot_max);
					tempDistMean[i][2] = ((7.0 / 10.0) * Var_Distribution_Rand_95Tot_min + (3.0 / 10.0) * Var_Distribution_Rand_95Tot_max);
					//tempDistMean[i][3] = (varDistributionRand_95Tot + cumulativeDrillHours) / 2;
				}
				else if((Inputs.failureStatus == false && Delta_glb_sum >= 1) || (Inputs.Check_Incident_History == 1 && Delta_glb_sum >= 0.5))
				{
					tempDistMean[i][0] = ((6.0 / 10.0) * min_pred_temp + (4.0 / 10.0) * max_pred_temp);
					tempDistMean[i][1]  = ((6.0 / 10.0) * Var_Distribution_Rand_25Tot_min + (4.0 / 10.0) * Var_Distribution_Rand_25Tot_max);
					tempDistMean[i][2] = ((6.0 / 10.0) * Var_Distribution_Rand_95Tot_min + (4.0 / 10.0) * Var_Distribution_Rand_95Tot_max);
				}
				else if ((Inputs.failureStatus == false && Delta_glb_sum >= 0.5) || (Inputs.Check_Incident_History == 1 && Delta_glb_sum >= 0.25))
				{
					tempDistMean[i][0] = (min_pred_temp + max_pred_temp)/2.0;
					tempDistMean[i][1]  = (Var_Distribution_Rand_25Tot_min + Var_Distribution_Rand_25Tot_max)/2.0;
					tempDistMean[i][2] = (Var_Distribution_Rand_95Tot_min + Var_Distribution_Rand_95Tot_max)/2.0;
				}
				else
				{
					tempDistMean[i][0] = ((4.0 / 10.0) * min_pred_temp + (6.0 / 10.0) * max_pred_temp);
					tempDistMean[i][1]  = ((4.0 / 10.0) * Var_Distribution_Rand_25Tot_min + (6.0 / 10.0) * Var_Distribution_Rand_25Tot_max);
					tempDistMean[i][2] = ((4.0 / 10.0) * Var_Distribution_Rand_95Tot_min + (6.0 / 10.0) * Var_Distribution_Rand_95Tot_max);
				}
            
				tempDistLB[i] = tempDistMean[i][1];
				tempDistUB[i] = tempDistMean[i][2];
				//tempDistUB[i] = tempDistMean[i][3];
				
				tempDistAll[i] = tempDistMean[i][0];
				tempDistAll[NumMCSRuns + i] = tempDistMean[i][1];
				tempDistAll[2 * NumMCSRuns + i] = tempDistMean[i][2];
				tempDistAll[3 * NumMCSRuns + i] = tempDistMean[i][0];
				            
				MeanPf = MeanPf + Pf;
				MeanLife = MeanLife + tempDistMean[i][0];
				MeanLife25 = MeanLife25 + tempDistMean[i][1];
				MeanLife975 = MeanLife975 + tempDistMean[i][2];
				
			}else{
				failures = failures +1; 
			}
			i = i + 1;
	    }
	    ModelWeight.MCSRun = false;
	    TotalDataInHistogram = (4 * NumMCSRuns);
	   	     
		runSinglePartUtil.BsortArr(tempDistMean, NumMCSRuns, 3, 0);
		Arrays.sort(tempDistAll);
		Arrays.sort(tempDistLB);
		Arrays.sort(tempDistUB);
		
		MeanPf = MeanPf / NumMCSRuns;
		MeanLife = MeanLife / NumMCSRuns;
		MeanLife25 = MeanLife25 / NumMCSRuns;
		MeanLife975 = MeanLife975 / NumMCSRuns;

		Per_025 = tempDistAll[(int)Math.round(TotalDataInHistogram * 0.025)-1];
	    Per_25 = tempDistAll[(int)Math.rint(TotalDataInHistogram * 0.25)-1];
	    Per_5 = tempDistAll[(int)Math.round(TotalDataInHistogram * 0.5)-1];
	    Per_75 = tempDistAll[(int)Math.round(TotalDataInHistogram * 0.75)-1];
	    //Per_975 = (tempDistAll[(int)Math.round(TotalDataInHistogram * 0.975)-1]+PivotForOutliers)/2;
	    Per_975 = tempDistAll[(int)Math.round(TotalDataInHistogram * 0.975)-1];
	    
	    
	    if((Per_75/ModelWeightUtil.multFactor)<Inputs.TotaldrillingHours)
	    {
	    	Per_025 = Per_025/ModelWeightUtil.multFactor;
	    	Per_25 = Per_25/ModelWeightUtil.multFactor;
	    	Per_5 = Per_5/ModelWeightUtil.multFactor;
	    	Per_75 = Per_75/ModelWeightUtil.multFactor;
	    	Per_975 = Per_975/ModelWeightUtil.multFactor;
	    }
	    double Per_75_orig = Per_75;
	    double Per_975_orig = Per_975;
	    
	    if(Inputs.TotaldrillingHours-100.0>Per_75)
	    {
	    	Per_025 = (Per_025+Inputs.TotaldrillingHours+Per_25+100)/3.0;
	    	Per_25 = (Per_25+Inputs.TotaldrillingHours+Per_5+100)/3.0;
	    	Per_5 = (Per_5+Inputs.TotaldrillingHours+Per_75+100)/3.0;
	    	Per_75 = (Per_75+Inputs.TotaldrillingHours+Per_975+100)/3.0;
	    	if(Per_75>Inputs.TotaldrillingHours)
	    	{
	    		Per_75 = (Per_975_orig+Inputs.TotaldrillingHours+100)/2.0;
	    	}
	    	if(Per_75>Inputs.TotaldrillingHours)
	    	{
	    		Per_75 = (Per_975_orig+Inputs.TotaldrillingHours)/2.0;
	    	}
	    	Per_975 = (Per_975 + Inputs.TotaldrillingHours+ PivotForOutliers)/3.0;
	    	if(Per_975<Per_75)
	    	{
	    		Per_975 = (Per_975 + PivotForOutliers)/2.0;
	    	}
	    }
	    else
	    {
	    	Per_975 = (tempDistAll[(int)Math.round(TotalDataInHistogram * 0.975)-1]+PivotForOutliers)/2;
	    }
	    
	   
	    
	    
	    //if (Per_975 < Inputs.TotaldrillingHours || (Per_975 > Inputs.maxFailureTime && Per_75 < PivotForOutliers)) {
	      //Per_975 = PivotForOutliers;
	        for (int i1 = (int)(TotalDataInHistogram * 0.975); i1 < TotalDataInHistogram; i1++){
	            tempDistAll[i1] = Per_975;
	        }
	    //}
	    
	    int EndIndex = (int)TotalDataInHistogram-1;
	    if (Inputs.aveFailureTime < Inputs.stdFailureTime) {
	    	Inputs.aveFailureTime = ((Inputs.aveFailureTime + Inputs.stdFailureTime) / 2);
	    	Inputs.stdFailureTime = (Inputs.stdFailureTime / 2);
	    }
	    double probabilityMCS = 0;
	    if ((Per_025 == Per_25 && Per_025 == Per_5 && Per_025 == Per_75 && Per_025 == Per_975) ||
	    		(Per_025 * Per_25 * Per_5 * Per_75 * Per_975 == 0)) {
	    	
	        Per_025 = CheckLifeval(Inputs.aveFailureTime - (1.96 * Inputs.stdFailureTime));
	        Per_25 = CheckLifeval(Inputs.aveFailureTime - (0.67 * Inputs.stdFailureTime));
	        Per_5 = CheckLifeval(Inputs.aveFailureTime);
	        Per_75 = CheckLifeval(Inputs.aveFailureTime + (0.67 * Inputs.stdFailureTime));
	        Per_975 = CheckLifeval(Inputs.aveFailureTime + (1.96 * Inputs.stdFailureTime));

	    	normalDist = new NormalDistribution(Inputs.aveFailureTime, Inputs.stdFailureTime);
	    	probabilityMCS = normalDist.cumulativeProbability(Inputs.TotaldrillingHours);
	    }else{
	        i = 0;
	        while (tempDistAll[i] <= Inputs.TotaldrillingHours && i < EndIndex){
	            i = i + 1;
	        }
	        probabilityMCS = runSinglePartUtil.CheckPf( (double)i/EndIndex);
	        probabilityMCS = runSinglePartUtil.getScaledPFMCS(Inputs.TotaldrillingHours, probabilityMCS, Per_025, Per_25, Per_5, Per_75, Per_975);
	    }
	    return probabilityMCS;
	}
	

	private double CheckLifeval(double d) {

		if (d > Inputs.maxOperatingTime){
			d= Inputs.maxOperatingTime;
		}else if(d < minOperatingTime){
			d= minOperatingTime;
		}
		return d;
	}


	private int GetRandLifeAndPF_MCS(int MCS_Run_Index) throws IOException {
		/* Similar to yetaPfLife() in ModelWeight class
		 * 
		 */
		yeta =0;
		lifeMean = 0;
		Pf = 0;
		varDistributionRand_25Tot = 0;
		varDistributionRand_95Tot = 0;
		ModelWeight.MCSRun = true;
		
		for(int i =0;i<6;i++){
			// CalcLife_Pf_yeta_Rand_Revision is same as YetaPfLifeModel from ModelWeight class, so using the same method. 
			ModelWeight.YetaPfLifeModel(true, false, i);
			
			yeta = yeta + ModelWeight.PM[i] * ModelWeight.yetaSum;
			lifeMean = lifeMean + ModelWeight.PM[i] * ModelWeight.lifeMeanSum;
			Pf = Pf + ModelWeight.PM[i] * ModelWeight.cumulativeDistributionFunctionSum;
			varDistributionRand_95Tot = varDistributionRand_95Tot + ModelWeight.PM[i] * ModelWeight.varDistributionSum[0];
			varDistributionRand_25Tot = varDistributionRand_25Tot + ModelWeight.PM[i] * ModelWeight.varDistributionSum[1];
		}

		int RandLifeAndPF_MCS = 0;
		double cc = (Math.abs(lifeMean - minOperatingTime) / lifeMean) * 1000;
		double dd = (Math.abs(lifeMean - Inputs.maxOperatingTime) / lifeMean) * 1000;
		
		if (lifeMean < Inputs.maxOperatingTime && lifeMean > minOperatingTime) {
		    RandLifeAndPF_MCS = 1;
		}else if (cc < 1 || dd < 1) {
		    RandLifeAndPF_MCS = 1;
		}
		return RandLifeAndPF_MCS;
	}
}
