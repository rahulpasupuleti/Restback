package elp.utils;

import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

import org.apache.commons.lang3.ArrayUtils;
import org.apache.poi.hssf.usermodel.HSSFSheet;
import org.apache.poi.hssf.usermodel.HSSFWorkbook;
import org.apache.poi.ss.usermodel.Cell;

/*import jxl.Sheet;
import jxl.Workbook;
import jxl.read.biff.BiffException;*/
public class ReadCummulativeDamageBucket{
	public static String[][] cell ;

	/*public ReadCummulativeDamageBucket() throws BiffException, IOException{
		
		String inputFile = "C:\\work\\java\\excelModels\\BCPM.xls";
		ArrayList<String> rowValues = new ArrayList<String>();
		List<String> modelType = new ArrayList<String>();
		
		List<Double> alpha1 = new ArrayList<Double>();
		List<Double> alpha2 = new ArrayList<Double>();
		List<Double> alpha3 = new ArrayList<Double>();
		
		Sheet sheet1;
		File modelWorkbook = new File(inputFile);
		Workbook modelWB = Workbook.getWorkbook(modelWorkbook);
		sheet1 = modelWB.getSheet("CumulativeDamageBucket");
		
		if (sheet1 != null){
			String[][] cell = new String [sheet1.getRows()][];
			for (int j = 1; j < 7; j++){
				for (int k = 4; k < 8; k++){
					rowValues.add(sheet1.getCell(k,j).getContents());
				}
				cell[j] = rowValues.toArray(new String[rowValues.size()]);
				rowValues.clear();
			}
			for (int i = 1; i < 7; i++){
				modelType.add(cell[i][0]);
				alpha1.add (Double.parseDouble(cell[i][1]));
				alpha2.add (Double.parseDouble(cell[i][2]));
				alpha3.add (Double.parseDouble(cell[i][3]));
			}
			Inputs.modelType = modelType.toArray(new String[modelType.size()]);
			/*Commenting the following as the accuracy is 3 decimal which is causing lot a variation in results
			 * The values are hardcoded now in Inputs.java file.
			 * need to change decimal accuracy and then activate the code below.
			 * till then the hardcoded value remain.
			 * 
			 * 
			Inputs.alpha1 = ArrayUtils.toPrimitive(alpha1.toArray(new Double[alpha1.size()]));
			Inputs.alpha2 = ArrayUtils.toPrimitive(alpha2.toArray(new Double[alpha2.size()]));
			Inputs.alpha3 = ArrayUtils.toPrimitive(alpha3.toArray(new Double[alpha3.size()]));
		}
		
		//set values for aveFailureTmie and stdFailureTime
		cell = new String [sheet1.getRows()][];
		for (int j = 1; j < sheet1.getRows(); j++){
			for (int k = 9; k < 12; k++){
				rowValues.add(sheet1.getCell(k,j).getContents());
			}
			cell[j] = rowValues.toArray(new String[rowValues.size()]);
			rowValues.clear();
		}
	}*/
	/* This below constructor is written using POI Api from Apache to read the Cumulative Damage Bucket
	 *  
	 */
	
	public void InitializeBuckets()
	{
		Inputs.aveFailureTime = 0;
        Inputs.stdFailureTime = 0;
        Inputs.aveTemperature = 0;
        Inputs.stdTemperature = 0;
        Inputs.aveLateral = 0;
        Inputs.stdLateral = 0;
        Inputs.aveStickSlip = 0;
        Inputs.stdStickSlip = 0;
        Inputs.aveDistanceDrilled = 0;
        Inputs.stdDistanceDrilled = 0;
        Inputs.aveFailureHrsSus = 0;
        Inputs.stdFailureHrsSus = 0;
        Inputs.negativeSusScaleFactor =0.0;	
        Inputs.aveFailureHoursSus = 0.0;
        Inputs.stdevFailureHoursSus =0.0;
        Inputs.negativeScaleFactor = 0.0;
	}
	
	public ReadCummulativeDamageBucket() throws IOException{
		List<String> modelType = new ArrayList<String>();
		List<Double> alpha1 = new ArrayList<Double>();
		List<Double> alpha2 = new ArrayList<Double>();
		List<Double> alpha3 = new ArrayList<Double>();
		String modelFile = new String();
		// Initialize random number generation, 8 VSS buckets times 4 variables Temp, StickSl, Lat, Ax, times 3 level per variable
		int TotNumRandomSeeds = 8*4*3;
		int RandomSeedStartIndex = 1;
		InitializeBuckets();
		
		switch(Inputs.tool.toLowerCase()){
			case "bcpm": 
				modelFile = System.getProperty("user.dir")+"\\BCPM.xls";
				break;
			case "ass": 
				modelFile = System.getProperty("user.dir")+"\\ASS.xls";
				break;
			case "ontrak": 
				modelFile = System.getProperty("user.dir")+"\\ONTRAK.xls";
				break;
			case "atcurve": 
				modelFile = System.getProperty("user.dir")+"\\ATCURVE.xls";
				break;
			case "probe": 
				modelFile = System.getProperty("user.dir")+"\\ONTRAK.xls";
				break;
			case "coiltrak": 
				modelFile = System.getProperty("user.dir")+"\\COILTRAK.xls";
				break;
			case "lithotrak":
				modelFile = System.getProperty("user.dir")+"\\LITHOTRAK.xls";
				break;
			//dan added 06/22/2016--------------
			case "hydraulicunit": 
				modelFile = System.getProperty("user.dir")+"\\HYDRAULICUNIT.xls";
				break;
			//dan added 06/22/2016--------------
		    //Dan 05/04/2017
			//case "test":
            //modelFile = System.getProperty("user.dir")+"\\TEST.xls";                                                                           
            //break;
		}
		
		HSSFSheet sheet;
        FileInputStream inputFile = new FileInputStream(new File(modelFile));
        HSSFWorkbook workbook = new HSSFWorkbook(inputFile);
        
        sheet = workbook.getSheet("CumulativeDamageBucket");
        
        //stSlipSeverityModel = sheet.getRow(1).getCell(5).getStringCellValue();
        //random seed is used for initializing the random number generation, default is generated by function rand() if empty        
        
		//minDistDrillSeverity = sheet.getRow(1).getCell(15).getNumericCellValue();
        if (sheet != null){
			for (int i = 1; i < 7; i++){
				modelType.add(sheet.getRow(i).getCell(4).getStringCellValue());
				alpha1.add(sheet.getRow(i).getCell(5).getNumericCellValue());
				alpha2.add(sheet.getRow(i).getCell(6).getNumericCellValue());
				alpha3.add(sheet.getRow(i).getCell(7).getNumericCellValue());
			}
			Inputs.modelType = modelType.toArray(new String[modelType.size()]);
			Inputs.alpha1 = ArrayUtils.toPrimitive(alpha1.toArray(new Double[alpha1.size()]));
			Inputs.alpha2 = ArrayUtils.toPrimitive(alpha2.toArray(new Double[alpha2.size()]));
			Inputs.alpha3 = ArrayUtils.toPrimitive(alpha3.toArray(new Double[alpha3.size()]));
		}
        // 
        
        
        int RevFoundFlag = 0;
        for (int j = 1; j<= sheet.getLastRowNum();j++){
        	//sheet.getRow(j).getCell(9).getStringCellValue();
        	sheet.getRow(j).getCell(9).setCellType(Cell.CELL_TYPE_STRING);
        	sheet.getRow(j).getCell(37).setCellType(Cell.CELL_TYPE_STRING);
        	if ((Inputs.PN.equalsIgnoreCase(sheet.getRow(j).getCell(9).getStringCellValue())))
        	{
        		for (int i = 0; i < Inputs.proportionDrill.length; i++){
        			//System.out.println(i);
        			//System.out.println(j);
        			//Check for matching PN and revision values to get their corresponding values in CumulativeDamageBucket sheet . 
        			if (Inputs.revision[i].equalsIgnoreCase(sheet.getRow(j).getCell(37).getStringCellValue())){
        				RevFoundFlag = 1;
        				//total model values for this PN in current quarry = proportionalDrihr for each contained Rev *values for each contained Rev accordingly
        				Inputs.aveFailureTime += Inputs.proportionDrill[i] * (sheet.getRow(j).getCell(10).getNumericCellValue());
        				Inputs.stdFailureTime += Inputs.proportionDrill[i] * sheet.getRow(j).getCell(11).getNumericCellValue();
						Inputs.aveTemperature += Inputs.proportionDrill[i] * sheet.getRow(j).getCell(12).getNumericCellValue();
						Inputs.stdTemperature += Inputs.proportionDrill[i] * sheet.getRow(j).getCell(13).getNumericCellValue();
						Inputs.aveLateral += Inputs.proportionDrill[i] * sheet.getRow(j).getCell(14).getNumericCellValue();
						Inputs.stdLateral += Inputs.proportionDrill[i] * sheet.getRow(j).getCell(15).getNumericCellValue();
						Inputs.aveStickSlip += Inputs.proportionDrill[i] * sheet.getRow(j).getCell(16).getNumericCellValue();
						Inputs.stdStickSlip += Inputs.proportionDrill[i] * sheet.getRow(j).getCell(17).getNumericCellValue();
						Inputs.aveDistanceDrilled += Inputs.proportionDrill[i] * sheet.getRow(j).getCell(18).getNumericCellValue();
						Inputs.stdDistanceDrilled += Inputs.proportionDrill[i] * sheet.getRow(j).getCell(19).getNumericCellValue();
						Inputs.aveFailureHrsSus += Inputs.proportionDrill[i] * sheet.getRow(j).getCell(24).getNumericCellValue();
						Inputs.stdFailureHrsSus += Inputs.proportionDrill[i] * sheet.getRow(j).getCell(25).getNumericCellValue();
						Inputs.negativeScaleFactor += Inputs.proportionDrill[i] * sheet.getRow(j).getCell(21).getNumericCellValue();
						Inputs.negativeSusScaleFactor += Inputs.proportionDrill[i] * sheet.getRow(j).getCell(35).getNumericCellValue();
						Inputs.aveFailureHoursSus += Inputs.proportionDrill[i] * sheet.getRow(j).getCell(24).getNumericCellValue();
						Inputs.stdevFailureHoursSus += Inputs.proportionDrill[i] * sheet.getRow(j).getCell(25).getNumericCellValue();										
        			}
        		}
        	}
		}
        if(RevFoundFlag < 1)
        {
            /////Amit Added Initialize            
            int CountPN = 0;
            for (int j = 1; j<= sheet.getLastRowNum();j++)
            {
            	sheet.getRow(j).getCell(9).setCellType(Cell.CELL_TYPE_STRING);
            	//System.out.println(j);
            	//Check for matching PN and revision values to get their corresponding values.
            	if (Inputs.PN.equalsIgnoreCase(sheet.getRow(j).getCell(9).getStringCellValue()))
            	{
            		CountPN = CountPN+1;
            		Inputs.aveFailureTime += (sheet.getRow(j).getCell(10).getNumericCellValue());
    				Inputs.stdFailureTime += sheet.getRow(j).getCell(11).getNumericCellValue();
    				Inputs.aveTemperature += sheet.getRow(j).getCell(12).getNumericCellValue();
    				Inputs.stdTemperature += sheet.getRow(j).getCell(13).getNumericCellValue();
    				Inputs.aveLateral += sheet.getRow(j).getCell(14).getNumericCellValue();
    				Inputs.stdLateral += sheet.getRow(j).getCell(15).getNumericCellValue();
    				Inputs.aveStickSlip += sheet.getRow(j).getCell(16).getNumericCellValue();
    				Inputs.stdStickSlip += sheet.getRow(j).getCell(17).getNumericCellValue();
    				Inputs.aveDistanceDrilled += sheet.getRow(j).getCell(18).getNumericCellValue();
    				Inputs.stdDistanceDrilled += sheet.getRow(j).getCell(19).getNumericCellValue();
    				Inputs.aveFailureHrsSus += sheet.getRow(j).getCell(24).getNumericCellValue();
    				Inputs.stdFailureHrsSus += sheet.getRow(j).getCell(25).getNumericCellValue();
    				Inputs.negativeScaleFactor += sheet.getRow(j).getCell(21).getNumericCellValue();			
    				Inputs.negativeSusScaleFactor += sheet.getRow(j).getCell(35).getNumericCellValue();
    				Inputs.aveFailureHoursSus += sheet.getRow(j).getCell(24).getNumericCellValue();
    				Inputs.stdevFailureHoursSus += sheet.getRow(j).getCell(25).getNumericCellValue();								
            	}
            }
            Inputs.aveFailureTime = Inputs.aveFailureTime/CountPN;
            Inputs.stdFailureTime = Inputs.stdFailureTime/CountPN;
            Inputs.aveTemperature = Inputs.aveTemperature/CountPN;
            Inputs.stdTemperature = Inputs.stdTemperature/CountPN;
            Inputs.aveLateral = Inputs.aveLateral/CountPN;
            Inputs.stdLateral = Inputs.stdLateral/CountPN;
            Inputs.aveStickSlip = Inputs.aveStickSlip/CountPN;
            Inputs.stdStickSlip = Inputs.stdStickSlip/CountPN;
            Inputs.aveDistanceDrilled = Inputs.aveDistanceDrilled/CountPN;
            Inputs.stdDistanceDrilled = Inputs.stdDistanceDrilled/CountPN;
            Inputs.aveFailureHrsSus = Inputs.aveFailureHrsSus/CountPN;
            Inputs.stdFailureHrsSus = Inputs.stdFailureHrsSus/CountPN;
            Inputs.negativeSusScaleFactor = Inputs.negativeSusScaleFactor/CountPN;          
            Inputs.aveFailureHoursSus = Inputs.aveFailureHoursSus/CountPN;
            Inputs.stdevFailureHoursSus = Inputs.stdevFailureHoursSus/CountPN;
            
            
            ////Amit Added Initialize        
        }
        if(Inputs.aveFailureHoursSus<Inputs.aveFailureTime)
        {
        	Inputs.aveFailureHoursSus = Inputs.aveFailureTime;
        	Inputs.aveFailureHrsSus = Inputs.aveFailureTime;
        }
	}
}