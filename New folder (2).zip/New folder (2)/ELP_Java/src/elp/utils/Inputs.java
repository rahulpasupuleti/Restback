package elp.utils;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

import org.apache.commons.lang3.ArrayUtils;

public class Inputs {
	static HashMap<String, String> inputs;
	public static double[] temperature = {0,0,0,0,0,0,0,0};
	public static double[] stickSlip = {0,0,0,0,0,0,0,0};
	public static double[] lateral = {0,0,0,0,0,0,0,0};
	// Amit added
	public static double[] axial = {0,0,0,0,0,0,0,0};
	// Amit added
	static double[] alpha1 = {-9.6386,-6.2147,-4.5804,-9.0516,-5.3935,-4.2827};
	static double[] alpha2 = {0.95148,1.0816,0.76348,0.9279,1.04,0.79627};
	static double[] alpha3 = {-0.0018916,-0.0025936,-0.0016518,-0.0029181,-0.0045538,-0.0025057};
	static String[] modelType;
	
	private static String fileName;
	
	public static int numDataSets;
	public static double temperature1;
	public static double stickSlip1;
	public static double lateral1;
	//Amit added
	public static double axial1;
	public static int jarringCount;
	//Amit added
	public static double DistanceDrilledSeverity1;
	public static double temperatureStickSlip1;
	public static double temperatureLateral1;
	public static double stickSlipLateral1;
	public static double lifeMultFactor = 1;
	protected static double ModelMultFactorForRevision = 1;
	public static double circHours;
	public static double TotaldrillingHours;
	public static double prevDrillHrs;
	public static HashMap <String, String> distributionType = new HashMap<String, String>();;
	protected static String circDrillRelation;
	protected static double p1, p2;//coef of linear relation
	protected static String partNumber;
	protected static String serialNumber;
	
	public static double maxOperatingTime ;
	public static double maxFailureTime ;
	public static double aveFailureTime ;
	public static double stdFailureTime ;
	public static double drillHrsForModelUpdate ;
	
	// Amit changed protected -> to public
	public static double aveTemperature;
	public static double aveLateral;
	public static double aveStickSlip;
	public static double aveDistanceDrilled;
	public static double stdTemperature;
	public static double stdLateral;
	public static double stdStickSlip;
	public static double stdDistanceDrilled;
	public static double aveFailureHrsSus;
	public static double stdFailureHrsSus;
	// Amit changed protected -> to public
	
	public static String PN;
	public static String SN;
	
	protected static double CumulativeStickSlip_prev;
	protected static double CumulativeTemperature_prev;
	protected static double CumulativeLateral_prev;
	protected static double severityBucketThreshold;
	
	public static double latSeverityLogC = 0.3772706;
	public static double latSeverityExpC = 0.0974;
	public static double latSeverityLinC = 0.08988764;
	
	public static double latSeverityLogA = 0.200008459;
	public static double latSeverityExpA = 0.1035;
	public static double latSeverityLinA = 0.040449438;
	
	public static double tempSeverityLogC = 0.598373463;
	public static double tempSeverityExpC = 0.0517;
	public static double tempSeverityLinC = -0.15714;
	
	public static double tempSeverityLogA = -2.240850752;
	public static double tempSeverityExpA = 0.0132;
	public static double tempSeverityLinA = 0.005143;
	
	public static double stSlSeverityLogC = 0.709293243275961;
	public static double stSlSeverityExpC = 0.0924;
	public static double stSlSeverityLinC = 0.068966;
	
	public static double stSlSeverityLogA = 0.264612693415685;
	public static double stSlSeverityExpA = 0.794;
	public static double stSlSeverityLinA = 0.310344828;
	
	public static double[] estimateCirc;
	public static double[][] estimateStdDev = new double[6][];
	public static double[][] estimateUB = new double[6][];
	public static double[][] estimateLB = new double[6][];
	public static double[][] estimateMean = new double[8][];
	public static double drillHrs;
	public static String[] revision ;
	public static boolean modelUpdate;
	public static double[] proportionDrill;
	public static double minOperatingTime;
	public static boolean failureStatus = false;
	public static double[][] MinOperVarBound = {{0,0,0,0},{0,0,0,0},{0,0,0,0},{0,0,0,0}};
	public static double[][] MaxOperVarBound = {{0,0,0,0},{0,0,0,0},{0,0,0,0},{0,0,0,0}};
	public static double negativeScaleFactor;
	public static double negativeSusScaleFactor;
	public static double stdevFailureHoursSus;
	public static double aveFailureHoursSus;
	public static boolean multiplePN;
	public static double CalcPMD;
	public static double drillingHrsBeforeRepair;
	public static double totalDistDrilled;
	public static HashMap <String, Double> propDrillHrs ;
	public static String tool;
	public static String[] rev;
	public static int rev_count;
	public static String partDescription;
	//Amit Insert
	public static String PNDuplicate;
	public static String RunDescription_;
	public static String IncidentDescription_;
	public static String Prev_Maint_Level_;
	public static String Prev_Prev_Maint_Level_;
	public static String Assembly_Level_;
	public static String Maint_Level_0;
	public static String Maint_Level_1;
	public static String Assembly_Level_PN;
	public static String Maint_Level_PN;
	public static String Maint_Level_PN_1;
	public static double HoursSinceLastMaint;
	public static int Diff_DateSinceLastAction_Flag;
	
	public static double Delta_temp_glb;
	public static double Delta_lat_glb;
	public static double Delta_stsl_glb;
	public static double Delta_jarr_glb;
	public static double Delta_Hrs_glb;
	public static double Delta_axial_glb;
	
	public static int Check_Incident_History;
	public static double ModelWeightSincelastMaint;
	public static double ModelWeight_FoundTargetPart;
	public static double HoursSinceLastRun;
	public static int failureSeverity;
	public static String CarrateReplaceSTR;
	public static double randomseed1;
	public static double randomseed2;
	public static double randomseed3;
	public static double randomseed4;
	public static double LastRunInformationData;
	public static double randomGeneratorConstant = 25569;
	//Amit Insert
	public static int numEmptyData;
	public static boolean repairFlag;
	public static boolean fStatus;
	public static String assemblyID;
	public static String mainPN;
	public static String mainSN;
	public static String productDescription;
	
	public static double getVal(String str){
		return Double.parseDouble(str);
	}
    
	// Reading Input file as key-value pair (hashs) 
	public static HashMap<String, String> getKeyValuePair() throws IOException {
    	final int lhs = 0;
		final int rhs = 1;

		HashMap<String, String> map = new HashMap<String, String>();
		BufferedReader  bfr = new BufferedReader(new FileReader(new File(fileName)));

		String line;
		while ((line = bfr.readLine()) != null) {
			if (!line.startsWith("#") && !line.isEmpty()) {
				String[] pair = line.trim().split("=");
				try{
					map.put(pair[lhs].trim().toUpperCase(), pair[rhs].trim());
				}
				catch(ArrayIndexOutOfBoundsException e1)
				{
					System.out.println(e1);
				}
			}
		}
		//System.out.println(map);
		bfr.close();
		return(map);
    }
	
	// Getting inputs from text file, need to write DB connection and SQL code once we start getting values directly from MAP
	public static void getInputValues() throws IOException{
	 	
		inputs = getKeyValuePair();
		
		//numDataSets = (int) getVal(inputs.get("NUMDATASETS"));
		// Inputs coming from History file
		partNumber = (inputs.get("PARTNUMBER"));
		serialNumber = (inputs.get("SERIALNUMBER"));
		circHours = (getVal(inputs.get("CIRCHOURS")));
		//distributionType = (inputs.get("DISTRIBUTIONTYPE"));
		TotaldrillingHours = (getVal(inputs.get("DRILLINGHOURS")));
		TotaldrillingHours = (getVal(inputs.get("DRILLINGHOURS")));
		prevDrillHrs = (getVal(inputs.get("PREVDRILLINGHOURS")));

		temperature = getArr(inputs.get("TEMPERATURE").split(","));
		lateral = getArr(inputs.get("LATERAL").split(","));
		// Amit Added
		axial = getArr(inputs.get("AXIAL").split(","));
		// Amit Added
		stickSlip = getArr(inputs.get("STICKSLIP").split(","));
		

		//Calculated Input
		temperature1 = (getVal(inputs.get("TEMPERATURE_1")));	
		stickSlip1 = (getVal(inputs.get("STICKSLIP_1")));	
		lateral1 = (getVal(inputs.get("LATERAL_1")));	
		// Amit Added
		axial1 = (getVal(inputs.get("axial_1")));	
		// Amit Added
		DistanceDrilledSeverity1 = (getVal(inputs.get("DISTANCEDRILLEDSEVERITY_1")));	
		temperatureStickSlip1 = (getVal(inputs.get("TEMPERATURE_STSLIP_1")));	
		temperatureLateral1 = (getVal(inputs.get("TEMPERATURE_LATERAL_1")));
		stickSlipLateral1 = (getVal(inputs.get("STSLIP_LATERAL_1")));			

		//Model file Input
		ModelMultFactorForRevision = (getVal(inputs.get("MODELMULTFACTOR_FORAREVISION")));		
		lifeMultFactor = (getVal(inputs.get("LIFEMULTFACTOR")));
		circDrillRelation = (inputs.get("DRILL_CIRC_RELATION"));
		p1 = (getVal(inputs.get("P_1")));
		p2 = (getVal(inputs.get("P_2")));
		maxOperatingTime = (getVal(inputs.get("MAXOPERATINGTIME")));
		maxFailureTime = (getVal(inputs.get("MAXFAILURETIME")));
		
		if(maxOperatingTime<maxFailureTime)
		{
			maxOperatingTime = maxFailureTime;
		}
		
		
		aveFailureTime = (getVal(inputs.get("AVEFAILURETIME")));
		stdFailureTime = (getVal(inputs.get("STDFAILURETIME")));
		
		CumulativeStickSlip_prev = (getVal(inputs.get("PREVCUMULATIVESTICKSLIP")));
		CumulativeTemperature_prev = (getVal(inputs.get("PREVCUMULATIVETEMPERATURE")));
		CumulativeLateral_prev = (getVal(inputs.get("PREVCUMULATIVELATERAL")));
		
		severityBucketThreshold = getVal(inputs.get("SEVERITYBUCKETTHRESHOLD"));
		
		double[] stSlSeverityArr = getArr(inputs.get("STSLSEVERITY").split(","));
		double[] tempSeverityArr = getArr(inputs.get("TEMPSEVERITY").split(","));
		double[] latSeverityArr = getArr(inputs.get("LATSEVERITY").split(","));

		latSeverityLogC = (latSeverityArr[0]);
		latSeverityExpC = (latSeverityArr[1]);
		latSeverityLinC = (latSeverityArr[2]);
		
		latSeverityLogA = (latSeverityArr[3]);
		latSeverityExpA = (latSeverityArr[4]);
		latSeverityLinA = (latSeverityArr[5]);
		
		tempSeverityLogC = (tempSeverityArr[0]);
		tempSeverityExpC = (tempSeverityArr[1]);
		tempSeverityLinC = (tempSeverityArr[2]);
		
		tempSeverityLogA = (tempSeverityArr[3]);
		tempSeverityExpA = (tempSeverityArr[4]);
		tempSeverityLinA = (tempSeverityArr[5]);
		
		stSlSeverityLogC = (stSlSeverityArr[0]);
		stSlSeverityExpC = (stSlSeverityArr[1]);
		stSlSeverityLinC = (stSlSeverityArr[2]);
		
		stSlSeverityLogA = (stSlSeverityArr[3]);
		stSlSeverityExpA = (stSlSeverityArr[4]);
		stSlSeverityLinA = (stSlSeverityArr[5]);
		
		estimateCirc = getArr(inputs.get("ESTIMATEMEAN_CIRC").split(","));
		
		alpha1 = getArr(inputs.get("ALPHA1").split(","));
		alpha2 = getArr(inputs.get("ALPHA2").split(","));
		alpha3 = getArr(inputs.get("ALPHA3").split(","));
		modelType = inputs.get("MODELTYPE").split(",");
		
		estimateMean = getDoubleArr(inputs.get("ESTIMATEMEAN").split("\\|"));
		estimateStdDev = getDoubleArr(inputs.get("ESTIMATESTDDEV").split("\\|"));
		estimateUB = getDoubleArr(inputs.get("ESTIMATEUB").split("\\|"));
		estimateLB = getDoubleArr(inputs.get("ESTIMATELB").split("\\|"));
	}
	
	private static double[] getArr(String[] strgs) {

		List<Double> retList = new ArrayList<>();
		for(int i=0; i<strgs.length;i++ ){
			retList.add(Double.parseDouble(strgs[i]));
		}
		Double[] retArray = new Double[retList.size()] ;
		return ArrayUtils.toPrimitive(retList.toArray(retArray));
	}
	
	private static double[][] getDoubleArr(String[] rows){
		
		double matrix[][] = {{0,0,0,0,0,0,0,0,0},{0,0,0,0,0,0,0,0,0},{0,0,0,0,0,0,0,0,0},{0,0,0,0,0,0,0,0,0},{0,0,0,0,0,0,0,0,0},{0,0,0,0,0,0,0,0,0}};
		String[] temp = {"","","","","","","","",""};
	    int r = 0;
	    for (String row : rows) {
	        temp = row.split(",");
	        int j =0;
	        for (String val:temp){
	        	matrix[r][j++]=Double.parseDouble(val);
	        }
	        r++;
	    }
		return matrix;
	}

}
