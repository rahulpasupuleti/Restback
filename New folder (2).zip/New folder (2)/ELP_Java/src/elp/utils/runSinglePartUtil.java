package elp.utils;

import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Random;
import java.util.Scanner;

import elp.getLifeSingleRevision;
import elp.runSinglePart;
import elp.utils.Inputs;








//import JSci.maths.statistics.NormalDistribution;
import org.apache.commons.math3.distribution.NormalDistribution;
import org.apache.poi.hssf.usermodel.HSSFSheet;
import org.apache.poi.hssf.usermodel.HSSFWorkbook;

public class runSinglePartUtil{	
	public static double[][] Random_Matrix;
	public static double[] R1_Rand = {0,0,0,0,0,0,0,0,0};
	static getLifeSingleRevision singleRevision;
	static NormalDistribution normalDist;
	
	public static double getScaledPFMCS(double drillingHours, double probabilityMCS,
			double per_025, double per_25, double per_5, double per_75,
			double per_975) {
		
	    double ScaledPFMCS = probabilityMCS;
	    double LB_x = 0, UB_x = 0, LB_y = 0, UB_y = 0, m, C;
		if (drillingHours > per_025 && drillingHours < per_975) {
		    if (drillingHours > per_025 && drillingHours < per_25) {
		        LB_x = per_025;
		        UB_x = per_25;
		        LB_y = 0.025;
		        UB_y = 0.25;
		    }else if (drillingHours > per_25 && drillingHours < per_5) {
		        LB_x = per_25;
		        UB_x = per_5;
		        LB_y = 0.25;
		        UB_y = 0.5;
		    }else if (drillingHours > per_5 && drillingHours < per_75) {
		        LB_x = per_5;
		        UB_x = per_75;
		        LB_y = 0.5;
		        UB_y = 0.75;
		    }else if (drillingHours > per_75 && drillingHours < per_975) {
		        LB_x = per_75;
		        UB_x = per_975;
		        LB_y = 0.75;
		        UB_y = 0.975;
		    }
		    m = (UB_y - LB_y) / (UB_x - LB_x);
		    C = UB_y - m * UB_x;
		    ScaledPFMCS = m * drillingHours + C;
		}
		return ScaledPFMCS;
	}
	
	public static double CheckPf(double pf) {
		if(pf > 1) pf=1;
		if(pf < 0) pf=0;
		return pf;
	}
	
	public static void BsortArr(double[][] InpArr, int numMCSRuns,
			int NumCol, int SortIndex) {
	    for (int j = 0; j < numMCSRuns - 1;j++){
			for (int i = 0; i < numMCSRuns - j-1; i++){
			    if (InpArr[i][SortIndex] > InpArr[i + 1][SortIndex]) {
			        for (int k = 0; k < NumCol; k++){
			            double temp = InpArr[i + 1][k];
			            InpArr[i + 1][k] = InpArr[i][k];
			            InpArr[i][k] = temp;
			        }
			    }
			}
	    }
	}
	
	public static double ComputeLifeMult() {
	    int iter = 1;
	    double computeLifeMult;
	    double x_L = Inputs.TotaldrillingHours / 2.0;
	    double x_U = 10000;
	    double fval_L = ComputeLifeMultDrillHrs(x_L);
	    double fval_U = ComputeLifeMultDrillHrs(x_U);
	    
		if (fval_U >= 1) {
			computeLifeMult = x_U;
		}
	    if (fval_L <= 1) {
		    computeLifeMult = x_L;
		}else{
			double x_mid = (x_L + x_U) / 2;
			double fval_mid = ComputeLifeMultDrillHrs(x_mid);
			
			while (Math.abs(1 - fval_mid) > 0.0001 || Math.abs(x_L - x_U) > 0.1){
				
				if (fval_mid > 1) {
					x_L = x_mid;
				}else if (fval_mid < 1) {
					x_U = x_mid;
				}
				x_mid = (x_L + x_U) / 2;
				fval_mid = ComputeLifeMultDrillHrs(x_mid);
				iter = iter + 1;
				//Dan change on 06/22/2016 to avoid dead loop
				if (Math.abs(x_L-x_U)<=0.1) break;
			}
		computeLifeMult = x_mid;
		}
		return computeLifeMult;
	}

	public static double ComputeLifeMultDrillHrs(double drillHrs) {
		
		double[] Ave_temp = {50, 105, 137.5, 157.5, 170, 180, 192.5, 225};
		double[] Ave_lat = {0.25, 0.75, 1.5, 2.5, 4, 6.5, 11.5, 22.5};
		double[] Ave_stickslip = {0.1, 0.3, 0.5, 0.7, 0.9, 1.1, 1.6, 3};
		
		double TempPercentage = GetPercentConsumed(Inputs.temperature, Ave_temp,drillHrs,0);
		double LatPercentage = GetPercentConsumed(Inputs.lateral, Ave_lat,drillHrs,1);
		double StSlPercentage = GetPercentConsumed(Inputs.stickSlip, Ave_stickslip,drillHrs,2);
		return (LatPercentage + TempPercentage + StSlPercentage);
	}
	
	public static void GenerateNormalRandomArrays() {
	    @SuppressWarnings("unused")
		double Amat,temp;
	    @SuppressWarnings("unused")
		int NumValidCoeff;
	    
		if (runSinglePart.GenerateRandomMatFlag == false) {
	        Amat = Math.random();
	        
	        for (int i = 0; i < runSinglePart.NumMCSRuns; i++){
        		for (int j = 0;j < 9; j++){
        	        Random_Matrix[i][j] = Math.random();
	            }
	        }
	        runSinglePart.GenerateRandomMatFlag = true;
	    }
	    temp = 1;
	}
	
	public static double GetPercentConsumed(double[] temperature, double[] SeverityArr, double drillHours, int count){
	     
		double[] DrillHrs_perBucket = new double[temperature.length];
		double[] Severity_perBucket = new double[temperature.length];
		
		double SumVal = 0;
		for (int i = 0; i < DrillHrs_perBucket.length; i++){
		    SumVal = SumVal + temperature[i];
		}
		
		for (int i = 0; i < DrillHrs_perBucket.length; i++){
		    if (SumVal > 0){
		        DrillHrs_perBucket[i] = (Inputs.TotaldrillingHours * temperature[i] / SumVal);
		    }else{
		        DrillHrs_perBucket[i] = (1 / 8) * temperature[i];
		    }
		}
    /*
	 * Need to find a way to get inputs for each PN
	PN = Trim(Worksheets("FilteringInputs").Cells(2, 20).Value)
    PartNumRow = SearchPNCumulativeDamageSheet(PN)
    */
		double TotalPercentConsumed = 0;
		String[] nonPcba = {"10075534", "10079869", "10114260", "10168964", "N917600002","10220391","N919103048","10079371",
			"10240511","10154684","N919103049","10079551","10169147","10188550","10193241","10229373","10252673","10256484",
			"10257514","10261693","10317652","10319821","10075534","10079869","10114260","10168964","N917600002"};
		
		List<String> nonPCBA = new ArrayList<String>(Arrays.asList(nonPcba));
		
		if (!(Inputs.tool.equalsIgnoreCase("ontrak") || Inputs.tool.equalsIgnoreCase("probe"))){
			if(nonPCBA.contains(Inputs.PN)) count = count + 3;
		}
		for (int i = 0; i < DrillHrs_perBucket.length; i++){
		    Severity_perBucket[i] = DrillHrs_perBucket[i] * SeverityArr[i];
		    TotalPercentConsumed = TotalPercentConsumed + ConsumedPercentLife(   
		    		Severity_perBucket[i], DrillHrs_perBucket[i], drillHours, Inputs.modelType[count], 
		    				Inputs.alpha1[count], Inputs.alpha2[count], Inputs.alpha3[count]);
		}
		return TotalPercentConsumed;
	}

    
    private static double ConsumedPercentLife(double Severity_perBucket, double DrillHrs_perBucket, double drillhours, String modelType, double alpha1,
			double alpha2, double alpha3) {
    	
        double Drill_Hrs_Diff = (drillhours - DrillHrs_perBucket);
        double returnVal; 
        
        if (Drill_Hrs_Diff < 0) {
            Drill_Hrs_Diff = 0;
       }
        
        if (Severity_perBucket >= 1){ 
        	if (modelType.equalsIgnoreCase("power")) {
                returnVal = Math.exp(alpha1 + alpha2 * Math.log(Severity_perBucket) + alpha3 * Drill_Hrs_Diff);
            }else{
                returnVal = alpha1 + alpha2 * Severity_perBucket + alpha3 * Drill_Hrs_Diff;
            }
        }else{
            returnVal = 0;
        }
        
        if (returnVal > 1) {
            returnVal = 1;
        }
        
        if (returnVal < 0) {
            returnVal = 0;
        }
		return returnVal;
	}
    
    public static double[][] doubleValue = new double[500][9];
    public static boolean readFile = true;
	
    public static void GenerateMCSModel(int rowIndex){
    	double RandomSeedMult = 1.0;
		if (runSinglePart.MCS_Run_Index == 0 && readFile){
			try 
	    	{   
	        	@SuppressWarnings("resource")
	        	String fname = System.getProperty("user.dir");
	        	String modelFile = System.getProperty("user.dir")+"\\Random_input.xls";
	        	
	        	HSSFSheet sheet;
	            FileInputStream inputFile = new FileInputStream(new File(modelFile));
	            HSSFWorkbook workbook = new HSSFWorkbook(inputFile);        
	            sheet = workbook.getSheet("random_number");
	            int i = 0;
	        	for (i = 0 ; i < 500; i++)
	        	{
	        		for (int j = 0 ; j < 9; j++)
	        		{
	        			doubleValue[i][j] =sheet.getRow(i).getCell(j).getNumericCellValue();
	    			}	    			
	    		}	    	
	        	//random seed is used for initializing the random number generation, default is generated by function rand() if empty        
	        	
	        	//RandomSeedMult = GenerateSeeded_RandomNumbers();
	    		readFile = false;
	    	}
	    	catch(IOException ioe){
	    		System.out.println("Trouble Reading Random Numbers...");
	    		System.exit(0);
	    	}
	    }

		for (int i = 0 ; i < 9; i++){
			boolean k;
			if (i==0||i==7) k=true;
			else k = false;
			R1_Rand[i] = GenerateRandNumbers(rowIndex,i,k,doubleValue[runSinglePart.MCS_Run_Index][i]);
		}   
		
    }
    
    public static double GenerateSeeded_RandomNumbers()
    {	
    	double RandomSeedMult = 1.0;
    	double TargetSeed = 0.0;
    	if(Inputs.randomseed2>0)
    	{
    		TargetSeed = Inputs.randomseed2;
    	}
    	else if(Inputs.randomseed4>0)
    	{
    		TargetSeed = Inputs.randomseed4;
    	}
    	    	
    	double SourceSeed = 0.0;
    	if(Inputs.randomseed1>0)
    	{
    		SourceSeed = Inputs.randomseed1;
    	}
    	else if(Inputs.randomseed3>0)
    	{
    		SourceSeed = Inputs.randomseed3;
    	}else
    	{
    		SourceSeed = Inputs.LastRunInformationData + Inputs.randomGeneratorConstant;
    	}    	
    	
    	if(TargetSeed<SourceSeed)
    	{
    		RandomSeedMult = -(SourceSeed - TargetSeed)/TargetSeed;
    		///initialize seed
    		 Random temp = new Random();
    	     double newSeed = temp.nextDouble()/Inputs.randomGeneratorConstant;
    		 return 0.0;
    	}
    	
    	return RandomSeedMult;
    }
    
    /*public static void GenerateMCSModel(int rowIndex){

		if (runSinglePart.MCS_Run_Index == 0 && readFile){
			try 
	    	{   
	        	@SuppressWarnings("resource")
	        	Scanner inputStream = new Scanner(new File(System.getProperty("user.dir")+"\\random_input.txt"));;
	        	
	        	while (inputStream.hasNext()){
	    			for (int i = 0 ; i < 500; i++){
	    				
	    				for (int j = 0 ; j < 9; j++){
	    					doubleValue[i][j] = inputStream.nextDouble();//quantile generated based random numbers
	    				}
	    				inputStream.nextLine();
	    			}
	    		}
	    		readFile = false;
	    	}
	    	catch(IOException ioe){
	    		System.out.println("Trouble Reading Random Numbers...");
	    		System.exit(0);
	    	}
	    }

		for (int i = 0 ; i < 9; i++){
			boolean k;
			if (i==0||i==7) k=true;
			else k = false;
			R1_Rand[i] = GenerateRandNumbers(rowIndex,i,k,doubleValue[runSinglePart.MCS_Run_Index][i]);
		}	
		
    }*/
    
    

	//public static double GenerateRandNumbers(int RowIndex , int VarIndex , boolean CheckPosVal ){
	public static double GenerateRandNumbers(int RowIndex , int VarIndex , boolean CheckPosVal, double rand){
		
	    double Rtemp = 0;
	    int flag = 1;
	    double temp = rand;
	    //double temp = Math.random();//Random_Matrix[MCS_Run_Index][VarIndex];
	    while (flag == 1){
	    	
	        if (temp > 0 && temp < 1) {
	            if (Inputs.estimateStdDev[RowIndex][VarIndex] > 0) {
	            	//GET inverse normal cumulative distribution,
	                normalDist = new NormalDistribution(Inputs.estimateMean[RowIndex][VarIndex], Inputs.estimateStdDev[RowIndex][VarIndex]);
	            	Rtemp = normalDist.inverseCumulativeProbability(temp);
	            	if (!CheckPosVal) {
	                    if (Rtemp > 0) {
	                        Rtemp = Inputs.estimateMean[RowIndex][VarIndex];
	                    }
	                }
	                else {
	                    if (Rtemp <= 0) {
	                        Rtemp = Inputs.estimateMean[RowIndex][VarIndex];
	                    }
	                }
	            }else{
	                Rtemp = Inputs.estimateMean[RowIndex][VarIndex];
	            }
	            
	            if (Rtemp <= Inputs.estimateUB[RowIndex][VarIndex] && Rtemp >= Inputs.estimateLB[RowIndex][VarIndex]) {
	                //flag = 0;
	            }else{
	            	//temp = Math.random();
	            	Rtemp = Inputs.estimateMean[RowIndex][VarIndex];
	            }
	            flag = 0;
	        }
	    }
	    return(Rtemp);
	}
}