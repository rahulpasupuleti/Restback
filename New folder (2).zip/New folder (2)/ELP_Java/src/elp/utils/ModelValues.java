package elp.utils;

import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.math.BigInteger;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import org.apache.poi.hssf.usermodel.HSSFSheet;
import org.apache.poi.hssf.usermodel.HSSFWorkbook;

public class ModelValues {
	public String Revision = "";
	public String PN = "";
	public String SN = "";
	
	public static double minDistDrillSeverity = 0;
	public static double maxDistDrillSeverity = 0;
	public static String tempSeverityModel ;
	public static String latSeverityModel ;
	public static String axialSeverityModel ;
	public static String stSlipSeverityModel ;
	
	public static RevisionValues[] revValues;
	public static String distributionType;
	public static String rev;
	
	/*    ' Copy Severity Model for Temperature, Lateral, Axial, and StSlip(Linear, Exponential, Log)
	 * 
	 */ 
	public ModelValues(String PN) throws IOException {
		
		String modelFile = new String();
		switch(Inputs.tool.toLowerCase()){
			case "bcpm": 
				modelFile = System.getProperty("user.dir")+"\\BCPM.xls";
				break;
			case "ass": 
				modelFile = System.getProperty("user.dir")+"\\ASS.xls";
				break;
			case "ontrak": 
				modelFile = System.getProperty("user.dir")+"\\ONTRAK.xls";
				break;
			case "atcurve": 
				modelFile = System.getProperty("user.dir")+"\\ATCURVE.xls";
				break;
			case "probe": 
				modelFile = System.getProperty("user.dir")+"\\ONTRAK.xls";
				break;
			case "coiltrak": 
				modelFile = System.getProperty("user.dir")+"\\COILTRAK.xls";
				break;
			case "lithotrak": 
				modelFile = System.getProperty("user.dir")+"\\LITHOTRAK.xls";
				break;
			//Dan add for motors
			case "hydraulicunit": 
				modelFile = System.getProperty("user.dir")+"\\HYDRAULICUNIT.xls";
				break;
		    //Dan 05/04/2017
			//case "test":
               // modelFile = System.getProperty("user.dir")+"\\TEST.xls";                                                                           
            //break;

		} 
		//ReadExcel excel = new ReadExcel(modelFile,SN);
		
		//ReadModel modelSheet = new ReadModel(modelFile,SN);
		//ReadCumulativeDamageBucket cumulativeDamageBucket = new ReadCumulativeDamageBucket(modelFile,SN);
		/*tempSeverityModel = modelSheet.cell[1][1];
		latSeverityModel = modelSheet.cell[1][2];
		axialSeverityModel = modelSheet.cell[1][3];
		stSlipSeverityModel = modelSheet.cell[1][4];
		*/
		HSSFSheet sheet;
        FileInputStream file = new FileInputStream(new File(modelFile));
   	 
        //Create Workbook instance holding reference to .xls file
        HSSFWorkbook workbook = new HSSFWorkbook(file);

        //Get desired sheet from the workbook
        sheet = workbook.getSheet("ModelData_"+ PN);
		 
        //Model Data same for all Revision
		
        tempSeverityModel = sheet.getRow(1).getCell(2).getStringCellValue();
		latSeverityModel = sheet.getRow(1).getCell(3).getStringCellValue();
		axialSeverityModel = sheet.getRow(1).getCell(4).getStringCellValue();
		stSlipSeverityModel = sheet.getRow(1).getCell(5).getStringCellValue();
		
		maxDistDrillSeverity = sheet.getRow(1).getCell(14).getNumericCellValue();
		minDistDrillSeverity = sheet.getRow(1).getCell(13).getNumericCellValue();
		
		Inputs.maxFailureTime = sheet.getRow(1).getCell(6).getNumericCellValue();
		
		Inputs.maxOperatingTime = sheet.getRow(1).getCell(8).getNumericCellValue();
		Inputs.minOperatingTime = sheet.getRow(1).getCell(9).getNumericCellValue();
		
		//Circ Drill Relation
		Inputs.circDrillRelation = sheet.getRow(3).getCell(2).getStringCellValue();
		
		Inputs.p1 = sheet.getRow(4).getCell(2).getNumericCellValue();
		Inputs.p2 = sheet.getRow(4).getCell(3).getNumericCellValue();
		
		for (int i = 0; i < 4; i++){
			//Temperature
			Inputs.MaxOperVarBound[i][0] = sheet.getRow((i*2)+1).getCell(16).getNumericCellValue();
			Inputs.MinOperVarBound[i][0] = sheet.getRow((i*2)+1).getCell(17).getNumericCellValue();
			//Stickslip
			Inputs.MaxOperVarBound[i][1] = sheet.getRow((i*2)+1).getCell(10).getNumericCellValue();
			Inputs.MinOperVarBound[i][1] = sheet.getRow((i*2)+1).getCell(11).getNumericCellValue();
			//Lateral
			Inputs.MaxOperVarBound[i][2] = sheet.getRow((i*2)+1).getCell(12).getNumericCellValue();
			Inputs.MinOperVarBound[i][2] = sheet.getRow((i*2)+1).getCell(13).getNumericCellValue();
			//Distance Drilled
			Inputs.MaxOperVarBound[i][3] = sheet.getRow((i*2)+1).getCell(14).getNumericCellValue();
			Inputs.MinOperVarBound[i][3] = sheet.getRow((i*2)+1).getCell(15).getNumericCellValue();
		}
		
		
		Inputs.revision = new String[Inputs.rev_count];
		Inputs.proportionDrill = new double[Inputs.rev_count];
		
		List<String> revs = new ArrayList<String>();
		
		// get count of revisions in model files
		int count = 0; 
		for(int i = 0; i<sheet.getLastRowNum();i++){
			try{
				String revision = sheet.getRow(i).getCell(18).getStringCellValue();
				//Dan Added on 6/8/2016 ------------
				revision=revision.replaceAll("\\s", "");
                //Dan Added Ends-------------
				revs.add(revision);
				count++;
			}catch(Exception e){
				break;
			}
		}
		
		// get close match if revision is not present in model file.
		for(int j = 0; j < Inputs.rev_count;j++){
			String closeMatch = Inputs.rev[j];
			//Dan Added on 3/20/2017 ------------
			closeMatch=closeMatch.replaceAll("\\s", "");
			//Dan Added on 3/20/2017 ------------
			if (!revs.contains(closeMatch)){
				
				StringBuilder sb1 = new StringBuilder();
			    
			    for (char c : closeMatch.toCharArray())
			    sb1.append((int)c);
			    BigInteger mInt = new BigInteger(sb1.toString());
		
			    int Diff_asc;
		    	int Diff_min = 1000000;
				for(int i = 1; i < count; i++){
					StringBuilder sb2 = new StringBuilder();
					
					for (char c : sheet.getRow(i).getCell(18).getStringCellValue().toCharArray())
					    sb2.append((int)c);
					
					BigInteger mInt2 = new BigInteger(sb2.toString());
					Diff_asc = Math.abs((mInt.intValue() - mInt2.intValue()));
					if (Diff_min > Diff_asc) {
						Diff_min = Diff_asc;
						closeMatch = sheet.getRow(i).getCell(18).getStringCellValue();
					}
				}
				Inputs.propDrillHrs.put(closeMatch, Inputs.propDrillHrs.get(Inputs.rev[j]));
				Inputs.rev[j] = closeMatch;
			}
		}
		List<String> revList = new ArrayList<String>(Arrays.asList(Inputs.rev));
		
		
		//Gulshan added below while loop on 07/26/2016
		for(int j = 0; j < Inputs.rev_count;j++)
		{
			for(int i = 0; i < count;i++){
				String revision = sheet.getRow(i).getCell(18).getStringCellValue();
				//Dan Added on 6/8/2016 ------------
				revision=revision.replaceAll("\\s", "");
	            //Dan Added Ends-------------
				//if(revList.contains(revision)){ //if current modeled revision is contained in the revision list of data report: 1) get the proportional Drillhrs of current rev and put it in Inputs.Inputs.proportionDrill & Inputs.revision accordingly
				if(revList.get(j).equals(revision)){
					Inputs.proportionDrill[j] = Inputs.propDrillHrs.get(revision);
					Inputs.revision[j] = revision;
					break;
				}	
			}
		}
		
		
		//Gulshan commented below 12 lines on 07/26/2016 
		//	int revCount = 0;
		//for(int i = 0; i < count;i++){
		//	String revision = sheet.getRow(i).getCell(18).getStringCellValue();
		//	//Dan Added on 6/8/2016 ------------
		//	revision=revision.replaceAll("\\s", "");
         //   //Dan Added Ends-------------
		//	if(revList.contains(revision)){ //if current modeled revision is contained in the revision list of data report: 1) get the proportional Drillhrs of current rev and put it in Inputs.Inputs.proportionDrill & Inputs.revision accordingly
		//		Inputs.proportionDrill[revCount] = Inputs.propDrillHrs.get(revision);
		//		Inputs.revision[revCount] = revision;
		//		revCount++;
		//	}
		//}
		
		
		
		revValues = new RevisionValues[Inputs.proportionDrill.length];
		// Model Data related to Revision
		for (int j = 0; j < Inputs.proportionDrill.length; j++){
			revValues[j] = new RevisionValues(sheet, j);
		}
		
		/* EstimatesRepair - Most Conservative Model
		double[] Estimates_Repair = copyModelEstimateData(modelSheet, "EstimatesUsingFailures_FR", rev);
	    // EstimatesRepair_Sus - Most -1 Conservative Model
		double[] Estimates_RepairSus = copyModelEstimateData(modelSheet, "Estimates_FirstRun", rev);
	    */
	}


	
	/*class ReadModel{
		public String[][] cell;
		public ReadModel(String inputFile, String SN) throws IOException, BiffException {
		
			ArrayList<String> rowValues = new ArrayList<String>();
			
			Sheet sheet;
			File modelWorkbook = new File(inputFile);
			Workbook modelWB = Workbook.getWorkbook(modelWorkbook);
			sheet = modelWB.getSheet("ModelData_"+ SN);
			// Model Sheet Values are stored in an 2D array (this.cell)
			
			NumberFormat fivedps = new NumberFormat("#.#####"); 
			WritableCellFormat cellFormat = new WritableCellFormat(fivedps); 
			//cell.setFormat(cellFormat);
			
			if (sheet != null){
				String[][] cell = new String [sheet.getRows()][];
				for (int j = 0; j < (sheet.getRows()); j++){
					for (int k = 1; k < (sheet.getColumns()); k++){
						Cell cellValue = sheet.getCell(k,j);
						if (cellValue.getType() == CellType.NUMBER){
							System.out.println(cellValue.getCellFormat());
							rowValues.add(cellValue.getContents().toString());
						}else{
							rowValues.add(cellValue.getContents());
						}
					}
					cell[j] = rowValues.toArray(new String[rowValues.size()]);
					rowValues.clear();
					//sheetValues.add(rowValues);
				}
				this.cell = cell;//cell = sheetValues.toArray(new String[sheetValues.size()]);
			}
		}
	}*/
	
	
	
}

