package elp.utils;

public class CalculateInputs{
       //*CalcSeverity;

	public static double CalcSeverity (String environParam ){
	    
	    double SumTime = 0;
	    double LateralVibSeverity = 0;
	    double Gap_Circ_Drill = Inputs.circHours - Inputs.TotaldrillingHours;
	    double returnValue = 0;
	    
	    double[] latLin = {0.1,0.120224719,0.150561797,0.191011235,0.251685392,0.352808987,0.555056177,0.999999995};
	    double[] latExp = {0.1,0.120224719,0.150561797,0.191011235,0.251685392,0.352808987,0.555056177,0.999999995};
	    double[] latLog = {0.1,0.319731751,0.458367051,0.560536497,0.654541199,0.751646869,0.865760668,1.};
	    
	    double[] tempLin = {0.10001,0.382875,0.5500225,0.6528825,0.71717,0.7686,0.8328875,1.000035};
	    double[] tempExp = {0.100028764,0.206739135,0.317493638,0.413417419,0.487581659,0.556383487,0.656194856,1.007732243};
	    double[] tempLog = {0.1,0.543955618,0.70531514,0.786575179,0.832274743,0.866476821,0.906651198,1.};
	
	    double[] stSlipLin = {0.100000483,0.162069448,0.224138414,0.28620738,0.348276345,0.410345311,0.565517725,1.000000484};
	    double[] stSlipExp = {0.100035686,0.117252178,0.137431688,0.161084163,0.188807311,0.221301711,0.329154412,1.000371769};
	    double[] stSlipLog = {0.1,0.390706757,0.525877701,0.614912526,0.681413513,0.734513527,0.83366217,1.};
		double[] historyValues = {0,0,0,0,0,0,0,0};
	    String severity; //= ModelWeight.getSeverity(environParam);
	    
	    double[] severityVal = new double[latLin.length] ;
	    
	    switch(environParam.toLowerCase()){
	    case "temperature":
	    	historyValues = Inputs.temperature;
	    	severity = ModelValues.tempSeverityModel.toLowerCase();
	    	switch(severity){
		        case "linear":
		        	severityVal = tempLin;
		        	break;
		        case "exponential":
		        	severityVal = tempExp;
		        	break;
		        case "lognormal":
		        	severityVal = tempLog;
		        	break;
	    	}
	    	Inputs.severityBucketThreshold = severityVal[1];
	    	break;
	    case "lateral":
	    	//historyValues = ArrayUtils.toPrimitive(PartValues.latVib.toArray(new Double[PartValues.latVib.size()]));
	    	historyValues = Inputs.lateral;
	    	severity = ModelValues.latSeverityModel.toLowerCase();
	    	switch(severity){
		    	case "linear":
		    		severityVal = latLin;
		    		break;
		    	case "exponential":
		    		severityVal =  latExp;
		    		break;
		    	case "lognormal":
		    		severityVal =  latLog;
		    		break;
		    	}
	    	break;
	    case "stickslip":
	    	historyValues = Inputs.stickSlip;
	    	severity = ModelValues.stSlipSeverityModel.toLowerCase();
	    	switch(severity){
		    	case "linear":
		    		severityVal = stSlipLin;
		    		break;
		    	case "exponential":
		    		severityVal = stSlipExp;
		    		break;
		    	case "lognormal":
		    		severityVal = stSlipLog;
		    		break;
		    	}
	    	break;
	    }
	         
	    for(int j = 0; j < 8; j++){
	    	LateralVibSeverity = LateralVibSeverity + historyValues[j] * severityVal[j];
	    	SumTime = SumTime + historyValues[j];
	    }
	    
	    if (LateralVibSeverity < 0.00001){
	    	LateralVibSeverity = 0.1;
	    }
	    if (SumTime != 0)  {
	    	returnValue = LateralVibSeverity / SumTime;
	    }
	    else{
	    	returnValue = LateralVibSeverity; 
	    }
	    
	    if (environParam.toLowerCase().equals("temperature") && Inputs.TotaldrillingHours < Inputs.circHours && Inputs.circHours != 0 && Inputs.TotaldrillingHours != 0){
	    	if (Gap_Circ_Drill <= 0){
	                 Gap_Circ_Drill = 0;
	    	}
	        if (Gap_Circ_Drill >= 1000){
	           Gap_Circ_Drill = 1000;
	        }
	    
	        double Gap_m = 0.5 / 999;
	        int Gap_c = 1;
	    //* Electronics certified up to 125C
	        double SeverityBucketThreshold = severityVal[1];
	        if (returnValue > SeverityBucketThreshold){
	        	returnValue  = returnValue * (Gap_m * (Gap_Circ_Drill) + Gap_c);
	        }
	    }
	    returnValue = Check_Update_MaxMinSeverityVal(returnValue,environParam);
	    
	    return returnValue;
		
	}

	private static double  Check_Update_MaxMinSeverityVal(double Value, String Severity){
		double maxValue = 0;
		double minValue = 0;
		switch(Severity.toLowerCase()){
			case "temperature":
				maxValue =  Inputs.MaxOperVarBound[0][0];
				minValue =  Inputs.MinOperVarBound[0][0];
				break;
			case "stickslip":
				maxValue =  Inputs.MaxOperVarBound[0][1];
				minValue =  Inputs.MinOperVarBound[0][1];
				break;
			case "lateral":
				maxValue =  Inputs.MaxOperVarBound[0][2];
				minValue =  Inputs.MinOperVarBound[0][2];
				break;
		}
		
		if (Value > maxValue)
			Value = (maxValue + minValue )/2;
		if (Value < minValue)
			Value = minValue;
		return Value;
	}
	public static void Populatefailure_Suspension(){
		//double[] latVib = ArrayUtils.toPrimitive(ReadXML.latVib.toArray(new Double[ReadXML.latVib.size()]));
		double lateralVib =  0;
		for (int i = 0; i< Inputs.lateral.length; i++) {
			lateralVib = lateralVib + Inputs.lateral[i];
		}
		
		// Level1DataGap calculated below is not seen to be used anywhere
		if (lateralVib != 0){
	    	ReadXML.Level1DataGap.add(100 * Math.abs((Inputs.circHours - lateralVib) / lateralVib));
	    }else{
	    	ReadXML.Level1DataGap.add(0.);
	    }
	    
	    Inputs.lateral1 = CalcSeverity("lateral");
	    Inputs.stickSlip1 = CalcSeverity("stickslip");
	    
	    if(Inputs.tool.equalsIgnoreCase("atcurve"))
		{
			Inputs.lateral1 = 0.1;
			Inputs.stickSlip1 = 0.1;
		}
	    
	    
	    Inputs.temperature1 = CalcSeverity("temperature");	    
	    Inputs.temperatureStickSlip1 = Inputs.temperature1 * Inputs.stickSlip1;
	    Inputs.temperatureLateral1 = Inputs.temperature1 * Inputs.lateral1;
	    Inputs.stickSlipLateral1 = Inputs.lateral1 * Inputs.stickSlip1;
	    
	    //CalcSeverity("axial");
	    //RPMSeverity = Worksheets(WSname).Cells(i, RPM_Col).Value * Worksheets(SeveritySheetname).Cells(2, 24).Value + Worksheets(SeveritySheetname).Cells(3, 24).Value
	    
	    double distanceDrilledSeverity;
	    // '''''''''''''''''''''''''''''Distance Drilled Severity''''''''''''''''''''''''''''
	    if (Inputs.TotaldrillingHours >= 0){ 
	    	distanceDrilledSeverity = Inputs.totalDistDrilled / Inputs.TotaldrillingHours; //Val(Worksheets(WSname).Cells(i, DistanceDrilledSeverity_Col).Value) / Val(Worksheets(WSname).Cells(i, DrillHrs_Col).Value)
		}else{
			distanceDrilledSeverity = 2;
	    }
	    
	    
		if(distanceDrilledSeverity > ReadXML.maxDistanceDrilledSeverity){
	    	distanceDrilledSeverity = ReadXML.maxDistanceDrilledSeverity;
	    }
	    
	    if (distanceDrilledSeverity < ReadXML.minDistanceDrilledSeverity){
	    	distanceDrilledSeverity = ReadXML.minDistanceDrilledSeverity;
	    }
	    ReadXML.distanceDrilledSeverityEquation1 = 1/(ReadXML.maxDistanceDrilledSeverity - ReadXML.minDistanceDrilledSeverity);
	    ReadXML.distanceDrilledSeverityEquation2 = ReadXML.distanceDrilledSeverityEquation1 * ReadXML.minDistanceDrilledSeverity;
	    
	    distanceDrilledSeverity = distanceDrilledSeverity * ReadXML.distanceDrilledSeverityEquation1 - ReadXML.distanceDrilledSeverityEquation2;//Worksheets(SeveritySheetname).Cells(2, 52).Value + Worksheets(SeveritySheetname).Cells(3, 52).Value
	
		if (distanceDrilledSeverity > ModelValues.maxDistDrillSeverity ) {
			distanceDrilledSeverity = (ModelValues.maxDistDrillSeverity + ModelValues.minDistDrillSeverity ) / 2;
		}
		if (distanceDrilledSeverity < ModelValues.minDistDrillSeverity){
			distanceDrilledSeverity = ModelValues.minDistDrillSeverity;
	    }
		Inputs.DistanceDrilledSeverity1 = distanceDrilledSeverity;
	}
}
    //''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''
    /*
    If (Val(Worksheets(WSname).Cells(i, Pressure_Col).Value) > 0) Then
        PressureSeverity = Log(Worksheets(WSname).Cells(i, Pressure_Col).Value) * Worksheets(SeveritySheetname).Cells(2, 36).Value + Worksheets(SeveritySheetname).Cells(3, 36).Value
    Else
        PressureSeverity = 0.1
    End If
    
    If (Val(Worksheets(WSname).Cells(i, Torque_Col).Value) > 0) Then
        TorqueSeverity = Log(Worksheets(WSname).Cells(i, Torque_Col).Value) * Worksheets(SeveritySheetname).Cells(2, 40).Value + Worksheets(SeveritySheetname).Cells(3, 40).Value
    Else
        TorqueSeverity = 0.1
    End If
    */
/*Worksheets(WSname).Cells(i, ComputedCol + 4).Value = RPMSeverity
    Worksheets(WSname).Cells(i, ComputedCol + 5).Value = DistanceDrilledSeverity
    Worksheets(WSname).Cells(i, ComputedCol + 6).Value = PressureSeverity
    Worksheets(WSname).Cells(i, ComputedCol + 7).Value = TorqueSeverity
    

}
*/