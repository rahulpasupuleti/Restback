package elp.utils;

import java.io.BufferedWriter;
import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.io.PrintWriter;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Date;

import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.parsers.ParserConfigurationException;

import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;
import org.xml.sax.SAXException;

import elp.runSinglePart;
import elp.gui.fileBrowser;

public class ReadXML {
	//modified 3/2016 add 10 active part numbers& silenced 11 PNs
	static String[] ass = {"10220391","10240511","N_temp919103049", "10079551", "10082481", "10138147", "10082482", "10082483", "10112679", "10112680", "10146583",  "10221206", "10227724", "N_temp917511458", "N917511742", 
            "N917511743", "N917511830", "N917511831", "N919103046", "N919103047", "1_temp0186074", "N917511741", "N919103152", "1_temp0109796", "N_temp53350-101", "N917511740", "N917511744", "10079371","10154684", "N919103048", 
            "N917511781", "10140821", "10111155", "10176515", "1_temp0111082", "10174297", "10173569", "10115283", "10174161", "10166883", "10210811", "10212615", "10210527", "10207002", "10114092", "A1000888000","1_temp0166742",
            "1_temp0196936","1_temp0235876","1_temp0235878","10242241","1_temp0256007","1_temp0256131","10257079","1_temp0257346","10257549","10257760","1_temp0258608","10258909","10278193","10302413","1_temp0364366","10429628","1_temp0442407",
            "1_temp0165666","10147257","1_temp0430127","1_temp0435976","10183560","10434560","10462028"};

    static String[] bcpm = {"10122822","10122821","10177878","N917511769","1_temp0073675","N917511772","10263207","10235690","10177879","N_temp917600058","10176943","10122818","10111145","1_temp0075534","10102987","10121982",
            "10164763","10116275","10134342","1_temp0079869","10168964","10286151","N917511771","10088726","N917511770","1_temp0104582","N917511773","N917511818","10177876","10143134","10150470","N917511768","N917511775",
            "10175512","10114260","N917600002","N917511767","1_temp0126953","10176192","10106819","10102985","1_temp0113902","1_temp0105061","1_temp0158522","1_temp0132203","10256025","10147801","10238944","10064669",
    		"10160282","10109729","10282535","10305098","10114148","10109721","10138147","10122820","10282534","1_temp0289144","10363658"};
    
    static String[] ontrak = {"10246547","10192709","1_temp0079869","10068098","10068097","10109408","10160282","1_temp0198552","10109409","N52570-101","N67538-001","10246544","10282145","1_temp0074526","10170967",
            "10160257","10068099","10068100","1_temp0070671","1_temp0075534","10101663","10106573","10109410","A1000888000","A3000218000","10009832","10066756","10129136","10140984","10079662","10079661",
            "10064669","10068121","10074312","1_temp0074525","1_temp0172353","10176667","10183876","10183877","1_temp0190837","1_temp0190839","1_temp0190941","1_temp0190943","10218312","A_temp1000455000"};        

    static String[] atcurve = {"10183560", "1_temp0196936", "1_temp0206972", "1_temp0209800", "1_temp0256131", "1_temp0256986", "1_temp0257052", "10257549", "1_temp0257711", "1_temp0257835", "10258608", "10258892", "1_temp0258897", "10258909", "1_temp0260261", 
            "1_temp0260602", "1_temp0260625", "10261692", "1_temp0262188", "1_temp0262488", "10263124", "10278193", "1_temp0283215", "1_temp0305557", "1_temp0318107", "1_temp0361292", "1_temp0364366", "1_temp0390840", "1_temp0405063", "A1000888000", "N_temp702-500-670",
            "1_temp0257346", "1_temp0169147", "1_temp0188550", "1_temp0193241", "1_temp0229373", "1_temp0252673", "10256484", "1_temp0257514", "10261693", "1_temp0317652", "1_temp0319821","10147257","10229233","1_temp0283216","10434560","10462028","10257079",
            "10257760"};
    
    static String[] probe = {"N109015-PL-01", "N702-500-313", "N109017-PL-02", "10085745", "N702-500-316", "N109013-PL-01", "N106945-PL-03", "N52903-015", "N52903", "N52902-015", "10059716","10011781","10275786","N33056-100","N33076-100","N33081-200","N_temp60700-101",
    		                 "10229233","10282534","10282535","10109863"};

    static String[] coiltrak = {"10094134","10262735","10123576","10064621","10112711","10138147","N919103047","10112922","N702-500-570","A1000888000","10109863"};
    
    static String[] lithotrak = {"10006527","10006526","N67878-001","10071980","10223933","10224616","10211135","N53809-202","N53291-102","N53291-302","N53809-102","10126961","10006529","10095506","10248951",
    "10062957","10197663","N67933","10091340","10196445","10091641","10196447","10197553","10089912"};

    //dan add -pumps silenced on 9/27/2016
	static String[] hydraulicunit = {"10079520","10182010","10140822","10371671","1_temp0074724","1_temp0092714","1_temp0186433","1_temp0193241","1_temp0229373"};
	//dan added for testing models built by Matlab ELPModelBuilder 0504/2017
	//static String[] test = {"A1000888000","10176192","10256484"};
	
	static List<String> assList = new ArrayList<String>(Arrays.asList(ass));
	static List<String> bcpmList = new ArrayList<String>(Arrays.asList(bcpm));
	static List<String> ontrakList = new ArrayList<String>(Arrays.asList(ontrak));
	static List<String> atcurveList = new ArrayList<String>(Arrays.asList(atcurve));
	static List<String> probeList = new ArrayList<String>(Arrays.asList(probe));
	static List<String> lithotrakList= new ArrayList<String>(Arrays.asList(lithotrak));
	static List<String> coiltrakList= new ArrayList<String>(Arrays.asList(coiltrak));
	//dan added 03/03/2016------------
	static List<String> hydraulicunitList= new ArrayList<String>(Arrays.asList(hydraulicunit));
    //dan added 03/03/2016------------
	static List<String> tempList;
	
	public static String mainPN;
	public static String mainSN;
	public static String productDescription;
	public static String partDescription = "";
	
	public static int numEmptyData = 0;
	public static int repairRow;
	
	private NodeList PNList;
	public static boolean repairFlag = false;
	
	public static List<Double> Level1DataGap = new ArrayList<Double>();
	
	public final static double minDistanceDrilledSeverity = 2;
	public final static double maxDistanceDrilledSeverity = 250;
	public static double distanceDrilledSeverityEquation1 = 0;
	public static double  distanceDrilledSeverityEquation2 = 0;
	//public static double[] propDrillHrs ;
	public static HashMap <String, Double> propDrillHrs ;
	public static String[] rev ;	
	public static File errorLogFile;
	public static String FailureType_tem_1 ="";
	public static String TFF_tem_2 ="";
		
	public ReadXML(String file) throws IOException {
		
		File historyFile = new File(file);
		
		String logFile = historyFile.getParent().concat("\\ErrorLogFile.log");
		errorLogFile = new File(logFile);
		FileWriter fileWritter1 = new FileWriter(errorLogFile);
		BufferedWriter bufferWritter1 = new BufferedWriter(fileWritter1);
        PrintWriter pw1 = new PrintWriter(bufferWritter1);
        
		DocumentBuilderFactory dbFactory = DocumentBuilderFactory.newInstance();
		DocumentBuilder dBuilder;
			
		try {
			dBuilder = dbFactory.newDocumentBuilder();
			Document doc = dBuilder.parse(historyFile);
			doc.getDocumentElement().normalize();
			
			//Iterating through the nodes and extracting the data.
			PNList = doc.getElementsByTagName("Details_Collection");
			
		} catch (ParserConfigurationException | SAXException | IOException e) {
			e.printStackTrace();
		}
			
		mainPN = PNList.item(0).getChildNodes().item(0).getAttributes().getNamedItem("PN").getNodeValue();
		Inputs.mainPN = mainPN;
		mainSN = PNList.item(0).getChildNodes().item(0).getAttributes().getNamedItem("SN").getNodeValue();
		mainSN = mainSN.replaceAll("<|>", "");
		Inputs.mainSN = mainSN;
		//Dan marked possible changes but need to reedit the if condition----------------------------------------------start
		//if (PNList.item(1).getChildNodes().item(0).getAttributes().getNamedItem("ProductDescription").getNodeValue()="")
		//{
		   //productDescription = PNList.item(0).getChildNodes().item(0).getAttributes().getNamedItem("ProductDescription").getNodeValue();
		//}
		//else
		//{
			//productDescription = PNList.item(1).getChildNodes().item(0).getAttributes().getNamedItem("ProductDescription").getNodeValue();
		//}
		//----------------------------------------------end
		//Amit
		//If there are data in run history report, continue the analysis; 
		//  if not, end analysis and print no data available for analysis
	//if (PNList.item(1)="")	{
		productDescription = PNList.item(1).getChildNodes().item(0).getAttributes().getNamedItem("ProductDescription").getNodeValue();
		try
		{
			Inputs.Assembly_Level_ = PNList.item(0).getChildNodes().item(0).getAttributes().getNamedItem("Assemblylevel").getNodeValue();
		}
		catch(NullPointerException ne)
		{
			Inputs.Assembly_Level_ = "";
		}
		
		
		try
		{
			Inputs.Maint_Level_0 =  GetLastMaintLevel(PNList.item(1).getChildNodes());//PNList.item(1).getChildNodes().item(0).getAttributes().getNamedItem("LastMaintenanceLevel").getNodeValue();
		}
		catch(NullPointerException ne)
		{
			Inputs.Maint_Level_0 = "";
		}
		Inputs.HoursSinceLastMaint = GetHrsSinceLastMaintenance(PNList.item(1).getChildNodes());
		Inputs.Maint_Level_PN_1 = Inputs.Maint_Level_0;
		
		//Amit Insert		
		try
		{
			Inputs.RunDescription_ = PNList.item(1).getChildNodes().item(0).getAttributes().getNamedItem("Remark").getNodeValue();
		}
		catch(NullPointerException ne)
		{
			Inputs.RunDescription_ = "";
		}
		try
		{
			Inputs.IncidentDescription_ = PNList.item(1).getChildNodes().item(0).getAttributes().getNamedItem("IncidentDescription").getNodeValue();
		}
		catch(NullPointerException ne)
		{
			Inputs.IncidentDescription_ = "";
		}
		
		new FindLeadingIndicators();		
		//Amit Insert
		
		
		//Amit
		
		Inputs.productDescription = PNList.item(1).getChildNodes().item(0).getAttributes().getNamedItem("ProductDescription").getNodeValue();
		
		//tabs
		switch(Inputs.tool){
    		case "bcpm": 
    			tempList = bcpmList;
    			break;
    		case "ass": 
    			tempList = assList;
    			break;
    		case "ontrak": 
    			tempList = ontrakList;
    			break;
    		case "atcurve":
    			tempList = atcurveList;
    			break;
    		case "probe":
    			tempList = probeList;
    			break;
    		case "coiltrak":
    			tempList = coiltrakList;
    			break;
    		case "lithotrak":
    			tempList = lithotrakList;
    			break;
    		//dan add 06/22/2016----
    		case "hydraulicunic":
    			tempList = hydraulicunitList;
    			break;				
    	}
		
		/////////////Amit Added
	    FailureType_tem_1 ="";
	    TFF_tem_2 ="";
	    String Jarring_tem_2 ="";
	    /////////////Amit Added
	    	
		for (int i = 1; i < PNList.getLength(); i++) {
				
			Node node = PNList.item(i);
		    if (node instanceof Element) {
		    	NodeList  nodeList = node.getChildNodes();
		    	// rows in each tabs
		    	Inputs.PN = nodeList.item(0).getAttributes().getNamedItem("PN").getNodeValue();
		    	Inputs.SN = nodeList.item(0).getAttributes().getNamedItem("SN").getNodeValue();
		    	Inputs.SN = Inputs.SN.replaceAll("<|>", "");
	    		
		    		    	
		    	/////////////
		    	Inputs.Assembly_Level_PN =  PNList.item(0).getChildNodes().item(i-1).getAttributes().getNamedItem("Assemblylevel").getNodeValue();
		    	//Inputs.Assembly_Level_PN =  nodeList.item(0).getAttributes().getNamedItem("Assemblylevel").getNodeValue();
				try
				{
					Inputs.Maint_Level_PN = GetLastMaintLevel(nodeList);					
					//Inputs.Maint_Level_PN =  nodeList.item(0).getAttributes().getNamedItem("LastMaintenanceLevel").getNodeValue();
				}
				catch(NullPointerException ne)
				{
					if(!Inputs.Assembly_Level_PN.contentEquals("1"))
					{
						Inputs.Maint_Level_PN = Inputs.Maint_Level_PN_1;
					}
					else
					{
						Inputs.Maint_Level_PN = Inputs.Maint_Level_0;
					}
				}
				
				if(!Inputs.Assembly_Level_PN.contentEquals("1"))
				{
					if(Inputs.Maint_Level_PN=="")
					{
						Inputs.Maint_Level_PN = Inputs.Maint_Level_PN_1;
					}
				}
				else
				{
					if(Inputs.Maint_Level_PN=="")
					{
						Inputs.Maint_Level_PN = Inputs.Maint_Level_0;
					}		
					else
					{
						Inputs.Maint_Level_PN_1 = Inputs.Maint_Level_PN;
					}
				}
				
				pw1.println("SN " + Inputs.SN + " L" + Inputs.Maint_Level_PN);
		    	
		    	
		    	int rowsToCheck = nodeList.getLength();		    	
		    	GetIncidentFlags(nodeList,0);		    	
		    	
		    	if (rowsToCheck > 1) rowsToCheck =1;
		    	
			    try {
			    	if (tempList.contains(Inputs.PN) && (Inputs.SN.length()>0)){
			    		
			    		Node n1_tem = nodeList.item(0).getAttributes().getNamedItem("FailureType");
			        	if(n1_tem!=null)
			        	{
			        		FailureType_tem_1 = nodeList.item(0).getAttributes().getNamedItem("FailureType").getNodeValue();
			        		TFF_tem_2 = nodeList.item(0).getAttributes().getNamedItem("TFF").getNodeValue();
			        	}
			        	
	    				if ((nodeList.getLength() == 1) && getValue("TotalDrillHrs1",nodeList.item(0)).doubleValue() <= 0){
			    			pw1.println("ZERO drilling hours seen for SN " + Inputs.SN);
			    			continue;
			    		}
	    				//new ReadCummulativeDamageBucket();
			    		Inputs.partDescription = nodeList.item(0).getAttributes().getNamedItem("ComponentDescription").getNodeValue();		    		
			    		
			    		
			    		Inputs.TotaldrillingHours = getValue("TotalDrillHrs1",nodeList.item(0)).doubleValue();
			    		Inputs.circHours = getValue("TotalCircHrs",nodeList.item(0)).doubleValue();
	    				Inputs.drillHrs = getValue("DrillHrs",nodeList.item(0)).doubleValue();
			    		
			    		// check History for Repair 
			    		Inputs.repairFlag = false;
			    		repairRow = 0;
			    		int Diff_Repair_DateFlag = 0;
			    		String LastRepairDate = "";
			    		if(nodeList.item(0).getAttributes().getNamedItem("LastRepairDate") != null)
			    		{
			    			LastRepairDate = nodeList.item(0).getAttributes().getNamedItem("LastRepairDate").getNodeValue();
			    		}
			    		String repair, runID;
			    		for (int ii = 0; ii < nodeList.getLength(); ii++){
			    			repair = nodeList.item(ii).getAttributes().getNamedItem("RepairHistoryFlag").getNodeValue();
			    			
			    			if (repair.equalsIgnoreCase("Y")){
			    				Inputs.repairFlag = true;
			    				for (int  j= ii; j < nodeList.getLength(); j++)
			    				{
			    					Diff_Repair_DateFlag = GetLastRepairDate(nodeList,j,LastRepairDate);
			    					if (nodeList.item(j).getAttributes().getNamedItem("RepairHistoryFlag").getNodeValue().equalsIgnoreCase("N") || Diff_Repair_DateFlag>0){
			    						repairRow = j;
			    						break;
			    					}
			    				}
			    				break;
			    			}
			    		}
			    		double circHoursBeforeRepair = 0;
	
			    		// For repair models where hours are turned to zero after repair
			    		if(Inputs.repairFlag && (Inputs.PN.equalsIgnoreCase("A1000888000")||Inputs.PN.equalsIgnoreCase("10079662")|| Inputs.partDescription.startsWith("TRANSFORMER")
			    				|| Inputs.partDescription.startsWith("ALTERNATOR") || Inputs.partDescription.startsWith("PUMP") || Inputs.partDescription.startsWith("HYDRAULIC") )){
			    			Inputs.numDataSets = repairRow;
			    			Inputs.rev = new String[repairRow];
			    			Inputs.drillingHrsBeforeRepair = getValue("TotalDrillHrs1",nodeList.item(repairRow)).doubleValue();
			    			circHoursBeforeRepair = getValue("TotalCircHrs",nodeList.item(repairRow)).doubleValue();
			    			
			    			Inputs.TotaldrillingHours = Inputs.TotaldrillingHours - Inputs.drillingHrsBeforeRepair;
			    			Inputs.circHours = Inputs.circHours - circHoursBeforeRepair; 
			    		}else{
			    			Inputs.numDataSets = nodeList.getLength();
			    			Inputs.rev = new String[nodeList.getLength()];
			    			Inputs.drillingHrsBeforeRepair = 0;
			    		}
			    		
			    		double drillHrs = 0.0;
			    		//propDrillHrs = new double[nodeList.getLength()];
			    		
			    					    		
			    		String Rev = new String();
			    		if(nodeList.item(0).getAttributes().getNamedItem("Revision")!=null)
			    		{
			    			Inputs.rev[0] = nodeList.item(0).getAttributes().getNamedItem("Revision").getNodeValue();
			    			//Dan Added on 3/20/2017 ------------
			    			Inputs.rev[0]=Inputs.rev[0].replaceAll("\\s", "");
			    		}
			    		else
			    		{
			    			
			    		}
			    		
			    		Inputs.rev_count = 1;
			    		boolean newRevision = false;
			    		Inputs.propDrillHrs = new HashMap<String, Double>();
			    		
			    		Inputs.numEmptyData = 0;
			    		// Strip <> from PN and SN 
			    		Inputs.PN = Inputs.PN.replaceAll("<|>", "");
			    		Inputs.SN = Inputs.SN.replaceAll("<|>", "");
	
			    		String missingDataFileName = historyFile.getParent().concat("\\MissingData_PN_"+ Inputs.PN +"_SN_"+ Inputs.SN +".log");
			    		File missingDataFile = new File(missingDataFileName);
	    				FileWriter fileWritter = new FileWriter(missingDataFile);
		    	        BufferedWriter bufferWritter = new BufferedWriter(fileWritter);
		    	        PrintWriter pw = new PrintWriter(bufferWritter);
			    		pw.println("RunID,Location,JobID,RunNo");
			    		
			    		Inputs.failureStatus = false;
			    		Inputs.fStatus = false;
			    		Inputs.failureSeverity = 0;
			    		String status;
			    		
			    		Inputs.totalDistDrilled = 0.0;
			    		for(int l = 0; l <=7; l++){
			    			Inputs.lateral[l] = 0.0; 
				    		Inputs.stickSlip[l] = 0.0;
				    		//Amit Added
				    		Inputs.axial[l] = 0.0;
				    		//Amit Added
				    		if (l<7)
				    			Inputs.temperature[l] = 0.0;
			    		}
			    		
			    		///Amit added
			    		Inputs.jarringCount = 0;
			    		GetMaxModelWeightAndFlag(Inputs.PN);
			    		////////////.
			    		
			    		Inputs.IncidentDescription_ = "";
			    		FailureType_tem_1 = "";
			    		TFF_tem_2 = "";
			    		
			    		for (int j = 0 ; j < Inputs.numDataSets; j++){
			    			GetIncidentFlags(nodeList,j);
			    			runID = nodeList.item(j).getAttributes().getNamedItem("RunID").getNodeValue();
		    				String location = nodeList.item(j).getAttributes().getNamedItem("Location1").getNodeValue();
		    				String jobID = nodeList.item(j).getAttributes().getNamedItem("JobNo").getNodeValue();
		    				String runNo = nodeList.item(j).getAttributes().getNamedItem("RunNo").getNodeValue();
			    			Rev = nodeList.item(j).getAttributes().getNamedItem("Revision").getNodeValue();
			    			
			    			//Amit Added
			    			Jarring_tem_2 = nodeList.item(j).getAttributes().getNamedItem("Jarring").getNodeValue();
			    			if(Jarring_tem_2.equalsIgnoreCase("y"))
			    			{
			    				Inputs.jarringCount = Inputs.jarringCount +1;
			    			}		    			
			    			//Amit Added
			    			
			    			try{
				    			//if (Rev.equalsIgnoreCase(Inputs.rev[Inputs.rev_count - 1]))
			    				/////Amit Added
			    				if(CheckRevision(Rev)==1)
			    				{
			    				////Amit Added
				    				drillHrs = drillHrs + getValue("DrillHrs",nodeList.item(j)).doubleValue();
				    				
				    				if (newRevision)
				    				{
				    					newRevision = false;
				    				}				    				
				    			}
			    				else
			    				{
				    				newRevision = true;
				    				Inputs.propDrillHrs.put(Inputs.rev[Inputs.rev_count-1],(drillHrs / Inputs.TotaldrillingHours));
				    				drillHrs = getValue("DrillHrs",nodeList.item(j)).doubleValue();
				    				
				    				Inputs.rev[Inputs.rev_count] = Rev;
				    				Inputs.rev_count = Inputs.rev_count  + 1;
				    			}
			    			}catch(NullPointerException ne){
			    				String msg = runID + "," +location + ","+ jobID +"," +runNo + ": has Blank values in Drilling Hours";
			    				pw.println(msg);
		    				}			    			
			    					
			    			
			    			status = nodeList.item(j).getAttributes().getNamedItem("Textbox11").getNodeValue();
			    			//if (status.equalsIgnoreCase("F")){
			    			//	if (j <2)
			    			//		Inputs.fStatus = true;
			    			//	Inputs.failureStatus = true;
			    			//}
			    			
			    			if (Inputs.Check_Incident_History == 1)
			    			{			    				
			    		    	if (FailureType_tem_1.length()>0 && !FailureType_tem_1.equalsIgnoreCase("FOOS") && !FailureType_tem_1.equalsIgnoreCase("PRN"))
			    		    	{
			    		    		Inputs.fStatus = true;
			    		    		Inputs.failureStatus = true;			    		    		
			    		    	}
			    		    	if(TFF_tem_2.equalsIgnoreCase("y"))
		    					{
		    						Inputs.failureSeverity = 1;
		    					}
				    		}			    			
			    			
			    			//Amit Added
			    			Inputs.Diff_DateSinceLastAction_Flag = DiffLastRunDate_CurrentDate(nodeList);
			    			//Amit Added
			    			
			    			
			    			double sumLat = 0, sumTemp = 0, sumStSlip = 0;
			    			// Amit added
			    			double sumAxial = 0.0;
			    			// Amit added
				    		for ( int l = 0; l <= 7; l++){
				    			try{
					    			sumLat = sumLat + getValue("LatVib"+l,nodeList.item(j)).doubleValue();
				    				sumStSlip = sumStSlip + getValue("StiSlip"+l,nodeList.item(j)).doubleValue();
				    				sumAxial = sumAxial + getValue("AxVib"+l,nodeList.item(j)).doubleValue();
				    				Inputs.lateral[l] = Inputs.lateral[l] + getValue("LatVib"+l,nodeList.item(j)).doubleValue();
					    			Inputs.stickSlip[l] = Inputs.stickSlip[l] + getValue("StiSlip"+l,nodeList.item(j)).doubleValue();
					    			Inputs.axial[l] = Inputs.axial[l] + getValue("AxVib"+l,nodeList.item(j)).doubleValue();
					    			
					    			if (l<7){
				    					sumTemp = sumTemp + getValue("Temp"+l,nodeList.item(j)).doubleValue();
				    					Inputs.temperature[l] = Inputs.temperature[l] + getValue("Temp"+l,nodeList.item(j)).doubleValue();
				    				}
					    		}catch (NullPointerException ne){
				    				String msg = runID + "," +location + ","+ jobID +"," +runNo + ": has Blank values for Temperature or Lateral or StickSlip";
									pw.println(msg);
								}
			    			}
				    		// Checking Missing Data 
			    			if (sumLat == 0 || sumTemp == 0){
			    				Inputs.numEmptyData = Inputs.numEmptyData + 1;
			    				String msg = runID + "," +location + ","+ jobID +"," +runNo;
			    				pw.println(msg);
			    			}
			    			Inputs.totalDistDrilled = Inputs.totalDistDrilled + getValue("DistanceDrilled",nodeList.item(j)).doubleValue();
				    		
			    		}
			    		pw.close();	
			    		Inputs.propDrillHrs.put(Inputs.rev[Inputs.rev_count-1],(drillHrs / Inputs.TotaldrillingHours));
	    				Inputs.prevDrillHrs = Inputs.TotaldrillingHours - Inputs.drillHrs;
	
			    		Inputs.CalcPMD = (double)Inputs.numEmptyData / (double)(Inputs.numDataSets + 1) ; 
			    				    		
			    		if (Inputs.TotaldrillingHours > 0){
			    			
			    			if(Inputs.PN.contains("10218312"))
			    			{
			    				int tem_1 = 1;
			    			}
			    			
			    			new runSinglePart();
			    			fileBrowser.listTableModel.addRow(runSinglePart.rowData);
			    		}else{
			    			pw1.println("PN " + Inputs.PN + " has ZERO Drilling Hours");
			    		}
			    	}
			    	else{
			    		pw1.println("PN " + Inputs.PN + " does not have ELP model");
			    	}
			    }catch (Exception ex) {
					ex.printStackTrace();
				}
	        }
		}
        pw1.close();
	}

	private static void GetIncidentFlags(NodeList nodeList,int runIndex)
	{
		if(runIndex<=3)
		{
			Node n1_tem = nodeList.item(runIndex).getAttributes().getNamedItem("FailureType");
			Node n2_tem = nodeList.item(runIndex).getAttributes().getNamedItem("TFF");
			Node n3_tem = nodeList.item(runIndex).getAttributes().getNamedItem("IncidentDescription");
			
			if(n1_tem!=null)
			{
				if(FailureType_tem_1.length()==0)
				{
					FailureType_tem_1 = nodeList.item(runIndex).getAttributes().getNamedItem("FailureType").getNodeValue();
				}				
			}
			
			if(n2_tem!=null)
			{
				if(TFF_tem_2.length()==0 || TFF_tem_2.equalsIgnoreCase("N"))
				{
					TFF_tem_2 = nodeList.item(runIndex).getAttributes().getNamedItem("TFF").getNodeValue();
				}
			}
			
			
			if(n3_tem!=null)
			{
				if(Inputs.IncidentDescription_.length()==0)
				{
					Inputs.IncidentDescription_ = nodeList.item(runIndex).getAttributes().getNamedItem("IncidentDescription").getNodeValue();
					if(Inputs.IncidentDescription_.length()>10) 
			        {
			        	Inputs.Check_Incident_History = 1;
			        }
				}
			}
			
		}
	}
	
	private static int CheckRevision(String targetRev) 
	{
		int CheckRevision = 0;
		for (int j = 0 ; j < Inputs.rev_count; j++) 
		{
			if (targetRev.equalsIgnoreCase(Inputs.rev[j])) 
			{
				CheckRevision = 1;
				break;
			}
		}
		return CheckRevision;
	}
	
	private static Double getValue(String tag, Node node) {
		return Double.parseDouble(node.getAttributes().getNamedItem(tag).getNodeValue().toString());
	}
	
	private static Double GetHrsSinceLastMaintenance(NodeList nodeList) {        
    	Date dNoLic = new Date();
    	Double TotaDrillHrs_Temp = 0.0;
    	Double TotaDrillHrs_LastMaint = 0.0;
    	Double DiffRunHours_FromLastMaintenance = 0.0;
    	String StrDate="";
    	String Run_Date="";
    	String MaintLevel="";
    	int LenStr=0;
    	int EndIndex = 0;
    	long diff_date=0;
    	int retval = 0;
    	int foundMaintRowBefore_Run = 0;
        
    	TotaDrillHrs_Temp = getValue("TotalDrillHrs1",nodeList.item(0)).doubleValue();    	    	
    	SimpleDateFormat formatter = new SimpleDateFormat("yyyy-MM-dd");   	
    	Node n1 = nodeList.item(0).getAttributes().getNamedItem("LastMaintenanceDate");    	
    	
    	if(n1!=null)
    	{
	        for (int i = 1; i < nodeList.getLength(); i++)
	        {        	
	        	StrDate = nodeList.item(i-1).getAttributes().getNamedItem("LastMaintenanceDate").getNodeValue();
	        	LenStr = StrDate.length();
	        	EndIndex = StrDate.indexOf("T");
	        	StrDate = StrDate.substring(0, EndIndex);        	
	        	
	            for (int j = 1; j < nodeList.getLength(); j++)
	            {
	            	Run_Date = nodeList.item(j-1).getAttributes().getNamedItem("RunDate").getNodeValue();
	            	LenStr = Run_Date.length();
	            	EndIndex = Run_Date.indexOf("T");
	            	Run_Date = Run_Date.substring(0, EndIndex);   
	            	try
	            	{
	            		Date LastRun_Date = formatter.parse(Run_Date);
	            		Date LastMaint_Date = formatter.parse(StrDate);
	            		Inputs.LastRunInformationData = (LastRun_Date.getTime())/(1000 * 60 * 60 * 24);
	            		diff_date = (LastRun_Date.getTime()-LastMaint_Date.getTime())/(1000 * 60 * 60 * 24);
	            		if(diff_date<0)
	            		{
	            			foundMaintRowBefore_Run = j;
	            			TotaDrillHrs_LastMaint = getValue("TotalDrillHrs1",nodeList.item(j-1)).doubleValue();
	            			DiffRunHours_FromLastMaintenance = TotaDrillHrs_Temp - TotaDrillHrs_LastMaint;
	            			break;
	            		}
	            	}
	            	catch(Exception ex)
	            	{
	            	}
	            }    
	            
	            if(DiffRunHours_FromLastMaintenance>0)
	            {
	            	break;
	            }
	        }
    	}
        return DiffRunHours_FromLastMaintenance;
     }
	
	
	private static String GetLastMaintLevel(NodeList nodeList) {        
    	String MaintLevel="";
    	int LenStr = 0;
    	
    	for (int i = 1; i < nodeList.getLength(); i++)
        {
    		try
    		{
    			MaintLevel = nodeList.item(i-1).getAttributes().getNamedItem("LastMaintenanceLevel").getNodeValue();
    			LenStr = MaintLevel.length();
    			if(LenStr>0)
    			{
    				break;
    			}
    		}
    		catch(NullPointerException ne)
    		{
    			MaintLevel ="";
    		}
        }
    	return MaintLevel;
	}
	
	private static void GetMaxModelWeightAndFlag(String PN_this) 
	{
		double Hrs_Since_Last_Maint;
		double MaxModelWeight_maint;
		double MinModelWeight_maint;
		double MaxDrillHrs_forL3 = 0.0;
		double MinDrillHrs_forL3 = 0.0;
		int IncidentFlag = 0;
		double MaintLevel = 1.0;
		double ModelWeight_incident = 0.0;
		double m_slope = 0.0;
		double c_slope = 0.0;
		String TargetStr = "";
		String SearchStr = "";
				
		String[] PN_GlobalList_temp = new String[550];
		Hrs_Since_Last_Maint = Inputs.HoursSinceLastMaint;
		String M_4 = Inputs.Maint_Level_PN;
		PN_GlobalList_temp = FindLeadingIndicators.PN_GlobalList;
		
		Inputs.ModelWeight_FoundTargetPart = 0;
		
		MaxModelWeight_maint = 2.0;
		MinModelWeight_maint = 0.1;
		MaxDrillHrs_forL3 = 500;
		MinDrillHrs_forL3 = 0;
		if(M_4.contains("1"))
		{
			MaintLevel = 1.0;
		}
		else if(M_4.contains("2"))
		{
			MaintLevel = 2.0;
		}
		else if(M_4.contains("3"))
		{
			MaintLevel = 3.0;
		}
		else if(M_4.contains("4"))
		{
			MaintLevel = 3.0;
		}
		
		
		double temp =  Inputs.HoursSinceLastRun;
		m_slope = (MaxModelWeight_maint - MinModelWeight_maint)/MaxDrillHrs_forL3;
		c_slope = MaxModelWeight_maint - m_slope*MaxDrillHrs_forL3;			
		if(Hrs_Since_Last_Maint==0)
		{
			Inputs.ModelWeightSincelastMaint = 1.0;
		}
		else
		{
			Inputs.ModelWeightSincelastMaint = (c_slope + m_slope*Hrs_Since_Last_Maint)/MaintLevel;
		}
				
		for (int i = 0;i<550;i++)
		{
			TargetStr = PN_GlobalList_temp[i].trim();
			SearchStr = PN_this.trim();
			if(TargetStr.equalsIgnoreCase(SearchStr))
			{
				Inputs.ModelWeight_FoundTargetPart = 1;
				break;
			}
		}		
	}
	
	private static int DiffLastRunDate_CurrentDate(NodeList nodeList) 
	{        
    	Date dNoLic = new Date();
    	Double DiffRunHours_FromCurrentDate = 0.0;    	
    	String Run_Date="";
    	
    	int LenStr=0;
    	int EndIndex = 0;
    	long diff_date=0;
    	int retval = 0;
    	        
    	SimpleDateFormat formatter = new SimpleDateFormat("yyyy-MM-dd");   	
    	    	
    	Run_Date = nodeList.item(0).getAttributes().getNamedItem("RunDate").getNodeValue();
	    LenStr = Run_Date.length();
	    EndIndex = Run_Date.indexOf("T");
	    Run_Date = Run_Date.substring(0, EndIndex);   
	    try
	    {
	    	Date LastRun_Date = formatter.parse(Run_Date);
	        diff_date = -(LastRun_Date.getTime()-dNoLic.getTime())/(1000 * 60 * 60 * 24);
	        Inputs.HoursSinceLastRun = diff_date;
	        if(diff_date>120)
	        {
	        	retval = 1;
	        }
	    }
	    catch(Exception ex)
	    {
	    }
	   
        return retval;
     }
	
	
	private static int GetLastRepairDate(NodeList nodeList,int Runindex,String LastDate)
	{        
    	String StrDate="";
    	int LenStr=0;
    	int EndIndex = 0;
    	long diff_date=0;
    	
    	int foundMaintRowBefore_Run = 0;
        
    	SimpleDateFormat formatter = new SimpleDateFormat("yyyy-MM-dd");   	
    	Node n1 = nodeList.item(Runindex).getAttributes().getNamedItem("LastRepairDate");    	
    	
    	
    	LenStr = LastDate.length();
        EndIndex = LastDate.indexOf("T");
        LastDate = LastDate.substring(0, EndIndex);      
        		
    	if(n1!=null && LenStr>0)
    	{
	        StrDate = nodeList.item(Runindex).getAttributes().getNamedItem("LastRepairDate").getNodeValue();
	        LenStr = StrDate.length();
	        EndIndex = StrDate.indexOf("T");
	        StrDate = StrDate.substring(0, EndIndex);       
	        try
		    {
	        	Date CurrentRepair_Date = formatter.parse(StrDate);
	        	Date LastRepair_Date = formatter.parse(LastDate);
	        	diff_date = -(CurrentRepair_Date.getTime()-LastRepair_Date.getTime())/(1000 * 60 * 60 * 24);
	        	if(diff_date>10)
	        	{
	        		foundMaintRowBefore_Run = 1;
	        	}
		    }
	        catch(Exception ex)
		    {
		    }
    	}
    	else if(n1==null && LenStr>0)
    	{
    		foundMaintRowBefore_Run = 1;
    		return foundMaintRowBefore_Run;
    	}
        return foundMaintRowBefore_Run;
     }
    	
}