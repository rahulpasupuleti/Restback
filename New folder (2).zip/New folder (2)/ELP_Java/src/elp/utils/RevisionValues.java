package elp.utils;

import java.math.BigInteger;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

import org.apache.commons.lang3.ArrayUtils;
import org.apache.poi.hssf.usermodel.HSSFSheet;

public class RevisionValues{
	
	public static String[] est = {"Estimates_FirstRun","EstimatesUsingFailures_FR","EstimatesMixed","Estimates_FirstRunSus","Estimates_QuarterSuspension","Estimates_75Suspension","Estimates_Repair","Estimates_RepairSus"};
	public double[] estimateCirc;
	public double[][] estimateMean ;
	public double[][] estimateStdDev ;
	public double[][] estimateLB ;
	public double[][] estimateUB ;
	public HashMap <String, String> distributionType ;
	
	boolean revisionNotFound = true;
	public RevisionValues(HSSFSheet sheet, int j){
		estimateCirc = new double[8];
		estimateMean = new double[8][];
		estimateStdDev = new double[8][];
		estimateLB = new double[8][];
		estimateUB = new double[8][];
		distributionType = new HashMap<String, String>();
		
		List<Double> estimateVals = new ArrayList<Double>();
		// if Revision value is available else change revision to nearest revision.
		int lastRevision = 0;
		String closeMatch = Inputs.revision[j];
		
		for(int i = 0; i<sheet.getLastRowNum();i++){
			try{
				if(sheet.getRow(i).getCell(18).getStringCellValue().equalsIgnoreCase(Inputs.revision[j])){
					revisionNotFound = false;
					//break;
				}
			}catch(Exception e){
				lastRevision = i;
				ModelValues.distributionType = sheet.getRow(i-1).getCell(90).getStringCellValue();
				break;
			}
		}
	    
		if (revisionNotFound){
			
		    StringBuilder sb1 = new StringBuilder();
		    int Diff_asc;
		    int Diff_min = 1000000;
		 
		    for (char c : Inputs.revision[j].toCharArray())
		    	sb1.append((int)c);
		    BigInteger mInt = new BigInteger(sb1.toString());

		    for(int i = 1; i < lastRevision; i++){
				StringBuilder sb2 = new StringBuilder();
				
				for (char c : sheet.getRow(i).getCell(18).getStringCellValue().toCharArray())
				    sb2.append((int)c);
				BigInteger mInt2 = new BigInteger(sb2.toString());
		
				Diff_asc = Math.abs((mInt.intValue() - mInt2.intValue()));
				if (Diff_min > Diff_asc) {
					Diff_min = Diff_asc;
					closeMatch = sheet.getRow(i).getCell(18).getStringCellValue();
				}
			}
		}
		
		// Find Revision Values for every Estimate
		boolean firstRev = false;
		if (j ==0) firstRev = true;
		
			estimateVals = copyModelEstimateData(sheet, "Estimates_Circ", closeMatch,2,true);
			estimateCirc = ArrayUtils.toPrimitive(estimateVals.toArray(new Double[estimateVals.size()]));
			estimateVals.clear(); 
			
			for (int i = 0; i <8 ;i++){
				estimateVals = copyModelEstimateData(sheet, est[i], closeMatch,2,true); 
				estimateMean[i] = ArrayUtils.toPrimitive(estimateVals.toArray(new Double[estimateVals.size()]));
				estimateVals.clear();
			}
			
			for (int i = 0; i <6;i++){
				estimateVals = copyModelEstimateData(sheet, est[i], closeMatch,3,false); 
				estimateStdDev[i] = ArrayUtils.toPrimitive(estimateVals.toArray(new Double[estimateVals.size()]));
				estimateVals.clear();
			}
			
			for (int i = 0; i <6;i++){
				estimateVals = copyModelEstimateData(sheet, est[i], closeMatch,6,false); 
				estimateLB[i] = ArrayUtils.toPrimitive(estimateVals.toArray(new Double[estimateVals.size()]));
				estimateVals.clear();
			} 
			
			for (int i = 0; i <6;i++){
				estimateVals = copyModelEstimateData(sheet, est[i], closeMatch,7,false); 
				estimateUB[i] = ArrayUtils.toPrimitive(estimateVals.toArray(new Double[estimateVals.size()]));
				estimateVals.clear();
			}
		
		if (firstRev) {//get model parameters for the first revision
			Inputs.estimateCirc = estimateCirc;
			Inputs.estimateMean = estimateMean;
			Inputs.estimateStdDev = estimateStdDev;
			Inputs.estimateLB = estimateLB;
			Inputs.estimateUB = estimateUB;
			Inputs.distributionType = distributionType;
		}
	}
		
	private ArrayList<Double> copyModelEstimateData(HSSFSheet sheet, String estimate, String rev, int index, boolean checkDistType) {
		
		int indx = 0,i;
		ArrayList<Double> retArray = new ArrayList<Double>();
		
			for(i=19; i < sheet.getRow(0).getLastCellNum(); i+=12){
				if(sheet.getRow(0).getCell(i).getStringCellValue().equalsIgnoreCase(estimate)){
					indx = i;
					break;
				}
			}
			if (indx >0){
				int cnt=0;
				//get distribution type
				for(i=0; i < sheet.getLastRowNum(); i++){
					//find the estimation type
					if(sheet.getRow(i).getCell(indx+1).getStringCellValue().isEmpty()){
						break;
					}else if(sheet.getRow(i).getCell(indx+9).getStringCellValue().equalsIgnoreCase(rev) ){//find revision
						if (checkDistType) distributionType.put(estimate, sheet.getRow(i).getCell(indx+11).getStringCellValue());
						cnt = ((i-1)*10)+1;
						break;
					}
				}
				
				//get the data array for each term &interaction in the model we are currently interested in 
				if (cnt >0){
					for(int j=cnt; j < cnt+9; j++){
						//temp.add(modelSheet.cell[i+j][indx+1]);
						if(!(sheet.getRow(j).getCell(indx+2) == null)){
							retArray.add(sheet.getRow(j).getCell(indx+index).getNumericCellValue());
						}else{
							break;
						}
					}
				}else{
					System.err.println("PN: " + Inputs.PN + " SN: " + Inputs.SN + " Revision: " + Inputs.revision + " Estimate: " + estimate + " not found!! \n Check the revision name and values....");
				}
			}
		return retArray;
		}
	}
