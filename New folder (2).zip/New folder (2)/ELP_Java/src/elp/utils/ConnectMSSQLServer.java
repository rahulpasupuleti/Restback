package elp.utils;

import java.io.BufferedWriter;
import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.io.PrintWriter;
import java.sql.DriverManager;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Date;
import java.util.HashMap;
import java.util.List;

import javax.swing.JOptionPane;

import org.w3c.dom.Node;
import org.w3c.dom.NodeList;

import elp.runSinglePart;
import elp.gui.fileBrowser;

public class ConnectMSSQLServer{
        
	    //modified 3/2016 add 10 active part numbers& silenced 11 PNs
	static String[] ass = {"10220391","10240511","N_temp919103049", "10079551", "10082481", "10138147", "10082482", "10082483", "10112679", "10112680", "10146583",  "10221206", "10227724", "N_temp917511458", "N917511742", 
            "N917511743", "N917511830", "N917511831", "N919103046", "N919103047", "1_temp0186074", "N917511741", "N919103152", "1_temp0109796", "N_temp53350-101", "N917511740", "N917511744", "10079371","10154684", "N919103048", 
            "N917511781", "10140821", "10111155", "10176515", "1_temp0111082", "10174297", "10173569", "10115283", "10174161", "10166883", "10210811", "10212615", "10210527", "10207002", "10114092", "A1000888000","1_temp0166742",
            "1_temp0196936","1_temp0235876","1_temp0235878","10242241","1_temp0256007","1_temp0256131","10257079","1_temp0257346","10257549","10257760","1_temp0258608","10258909","10278193","10302413","1_temp0364366","10429628","1_temp0442407",
            "1_temp0165666","10147257","1_temp0430127","1_temp0435976","10183560","10434560","10462028"};

    static String[] bcpm = {"10122822","10122821","10177878","N917511769","1_temp0073675","N917511772","10263207","10235690","10177879","N_temp917600058","10176943","10122818","10111145","1_temp0075534","10102987","10121982",
            "10164763","10116275","10134342","1_temp0079869","10168964","10286151","N917511771","10088726","N917511770","1_temp0104582","N917511773","N917511818","10177876","10143134","10150470","N917511768","N917511775",
            "10175512","10114260","N917600002","N917511767","1_temp0126953","10176192","10106819","10102985","1_temp0113902","1_temp0105061","1_temp0158522","1_temp0132203","10256025","10147801","10238944","10064669",
    		"10160282","10109729","10282535","10305098","10114148","10109721","10138147","10122820","10282534","1_temp0289144","10363658"};
    
    static String[] ontrak = {"10246547","10192709","1_temp0079869","10068098","10068097","10109408","10160282","1_temp0198552","10109409","N52570-101","N67538-001","10246544","10282145","1_temp0074526","10170967",
            "10160257","10068099","10068100","1_temp0070671","1_temp0075534","10101663","10106573","10109410","A1000888000","A3000218000","10009832","10066756","10129136","10140984","10079662","10079661",
            "10064669","10068121","10074312","1_temp0074525","1_temp0172353","10176667","10183876","10183877","1_temp0190837","1_temp0190839","1_temp0190941","1_temp0190943","10218312","A_temp1000455000"};        

    static String[] atcurve = {"10183560", "1_temp0196936", "1_temp0206972", "1_temp0209800", "1_temp0256131", "1_temp0256986", "1_temp0257052", "10257549", "1_temp0257711", "1_temp0257835", "10258608", "10258892", "1_temp0258897", "10258909", "1_temp0260261", 
            "1_temp0260602", "1_temp0260625", "10261692", "1_temp0262188", "1_temp0262488", "10263124", "10278193", "1_temp0283215", "1_temp0305557", "1_temp0318107", "1_temp0361292", "1_temp0364366", "1_temp0390840", "1_temp0405063", "A1000888000", "N_temp702-500-670",
            "1_temp0257346", "1_temp0169147", "1_temp0188550", "1_temp0193241", "1_temp0229373", "1_temp0252673", "10256484", "1_temp0257514", "10261693", "1_temp0317652", "1_temp0319821","10147257","10229233","1_temp0283216","10434560","10462028","10257079",
            "10257760"};
    
    static String[] probe = {"N109015-PL-01", "N702-500-313", "N109017-PL-02", "10085745", "N702-500-316", "N109013-PL-01", "N106945-PL-03", "N52903-015", "N52903", "N52902-015", "10059716","10011781","10275786","N33056-100","N33076-100","N33081-200","N_temp60700-101",
    		                 "10229233","10282534","10282535","10109863"};

    static String[] coiltrak = {"10094134","10262735","10123576","10064621","10112711","10138147","N919103047","10112922","N702-500-570","A1000888000","10109863"};
    
    static String[] lithotrak = {"10006527","10006526","N67878-001","10071980","10223933","10224616","10211135","N53809-202","N53291-102","N53291-302","N53809-102","10126961","10006529","10095506","10248951",
    "10062957","10197663","N67933","10091340","10196445","10091641","10196447","10197553","10089912"};

    //dan add -pumps silenced on 9/27/2016
	static String[] hydraulicunit = {"10079520","10182010","10140822","10371671","1_temp0074724","1_temp0092714","1_temp0186433","1_temp0193241","1_temp0229373"};
	//dan added for testing models built by Matlab ELPModelBuilder 0504/2017
	//static String[] test = {"A1000888000","10176192","10256484"};


        
        static List<String> assList = new ArrayList<String>(Arrays.asList(ass));
        static List<String> bcpmList = new ArrayList<String>(Arrays.asList(bcpm));
        static List<String> ontrakList = new ArrayList<String>(Arrays.asList(ontrak));
        static List<String> atcurveList = new ArrayList<String>(Arrays.asList(atcurve));
        static List<String> probeList = new ArrayList<String>(Arrays.asList(probe));
        static List<String> lithotrakList= new ArrayList<String>(Arrays.asList(lithotrak));
        static List<String> coiltrakList= new ArrayList<String>(Arrays.asList(coiltrak));
        //dan add
    	static List<String> hydraulicunitList= new ArrayList<String>(Arrays.asList(hydraulicunit));
    	//05/04/2017
    	//static List<String> testList= new ArrayList<String>(Arrays.asList(test));

    	//dan add
        static List<String> tempList;
        
        public static int repairRow;
        public static String[] rev;
        public PrintWriter pw;
        public double drillHrs = 0.0;
        public boolean newRevision = false;
        private static Connection conn;
        //public ConnectMSSQLServer() 
        public ConnectMSSQLServer(String mainPN, String mainSN,String tempfile_loc)throws SQLException, ClassNotFoundException, IOException 
        {              
                String folder = new String("\\PN" + mainPN + "_SN" + mainSN);
                new File(tempfile_loc.concat(folder)).mkdir();          
                String logFile = tempfile_loc.concat(folder + "\\ErrorLogFile.log");
                
                File errorLogFile = new File(logFile);
                FileWriter fileWritter1 = new FileWriter(errorLogFile);
                BufferedWriter bufferWritter1 = new BufferedWriter(fileWritter1);
        PrintWriter pw1 = new PrintWriter(bufferWritter1);
        
                // Creating the connection string for DB
                Class.forName("com.microsoft.sqlserver.jdbc.SQLServerDriver");       
                String userName = "elpuser";
                String pwd = "!M@PS_elp";
                String url = "jdbc:sqlserver://10.167.38.115;portNumber=5007;DatabaseName=MaPS_Repl";//
                //String userName = "elpuser";
        		//String pwd = "eLpUSeR_Qa_16";
        		//String url = "jdbc:sqlserver://10.167.59.33;portNumber=5007;DatabaseName=MAPS_REPL";//
                conn = DriverManager.getConnection(url,userName,pwd);
                System.out.println("Connected to SQL server..");
                
                //Executing the stored procedure
                Statement sta = conn.createStatement();
                // Stored Procedure to get Assembly Tree at 2 sub levels
                String SQLgetAssemblyTree;         
                
                if(fileBrowser.runMode.equals("db") && Inputs.assemblyID.length()>0)
                {
                        // Syed Jamil : When doing by Assembly
                        SQLgetAssemblyTree = new String("exec usp_getAssemblyTree_FiveSubLevel_SingleDate \'" + mainPN +"\' , \'" + Inputs.CarrateReplaceSTR + mainSN + "\' ,'" + Inputs.assemblyID + "\'");
                        //JOptionPane.showMessageDialog(null, SQLgetAssemblyTree, "ConnectMSSQLServer: " + "Title", JOptionPane.INFORMATION_MESSAGE);
                }
                else
                {
                        // Syed Jamil : When doing by individual part
                        SQLgetAssemblyTree = new String("exec usp_getAssemblyTree_FiveSubLevel \'" + mainPN +"\' , \'" + Inputs.CarrateReplaceSTR + mainSN + "\'");
                        //JOptionPane.showMessageDialog(null, SQLgetAssemblyTree, "ConnectMSSQLServer: " + "Title", JOptionPane.INFORMATION_MESSAGE);
                }
                
                ResultSet rs1 = sta.executeQuery(SQLgetAssemblyTree);
                
                // Checking all the PN's & SN's for available models 
                int cnt=0;
                
                ///////kaleami 06/25/2015////////////////////////
                String FailureType_tem_1 ="";
        boolean TFF_tem_2 =false;
        String IncidentKey_Str = "";
        Inputs.mainPN = mainPN;
        Inputs.mainSN = mainSN;
        Inputs.tool = "";
                /////////////////////////////////////////////////               
                
        int tempCount =0;
                while (rs1.next()) 
                {
                        tempCount++;
                        
                        // Syed Jamil
                        //JOptionPane.showMessageDialog(null, "Walk each PN/SN found in the assembly", "ConnectMSSQLServer: ", JOptionPane.INFORMATION_MESSAGE);
                        
                        //if (tempCount == 13 || Inputs.assemblyID.length() <= 0)
                        if (true)
                        {
                                Inputs.PN = rs1.getString("PN");
                                Inputs.SN = ReplaceCarrats(rs1.getString("SN"));
                                
                                // find out what tool
                                if (Inputs.tool.equals(""))
                                {
                                        // Syed Jamil : Identify the tool and the load the templist
                                        getToolNameAndList(pw1);
                                }
                                
                                
                                if(Inputs.tool.length()>0 && tempList.contains(Inputs.PN) && Inputs.SN.length() > 0)
                                {
                                        // Syed Jamil : Now e know the tool and it is in our list, time to model it
                                        cnt = processModel(tempfile_loc, folder, pw1, cnt);
                                }
                                else
                                {
                                        // We have a tool that is not in our list of tools
                                if(!errorLogFile.exists())
                                        errorLogFile.createNewFile();
                                
                                pw1.println("PN " + Inputs.PN + " does not have ELP model");
                        }
                                
                                // Syed Jamil : Reset the tool name
                                Inputs.tool = "";
                        }
                }
                System.out.println("Count of available models: "+ cnt);
                pw1.close();
        }

        /**
        * @param tempfile_loc
        * @param folder
        * @param pw1
        * @param cnt
        * @return
        * @throws IOException
        * @throws SQLException
        */
        private int processModel(String tempfile_loc, String folder, PrintWriter pw1, int cnt)
                        throws IOException, SQLException {
                String FailureType_tem_1;
                boolean TFF_tem_2;
                String IncidentKey_Str;
                // Stored Procedure to get Ops data(run history) for given PN and SN
                String missingDataFileName = tempfile_loc.concat(folder +"\\MissingData_PN_"+ Inputs.PN +"_SN_"+ Inputs.SN +".log");
                File missingDataFile = new File(missingDataFileName);
                FileWriter fileWritter = new FileWriter(missingDataFile);
                BufferedWriter bufferWritter = new BufferedWriter(fileWritter);
                pw = new PrintWriter(bufferWritter);
                pw.println("RunID,Location,JobID,RunNo");
                
                drillHrs = 0.0;
                
                Inputs.totalDistDrilled = 0.0;
                Inputs.numEmptyData = 0;
                Inputs.TotaldrillingHours = 0.0;
                for (int l = 0; l<7; l++)
                {
                        Inputs.lateral[l] = 0.0; 
                        Inputs.stickSlip[l] = 0.0;
                        Inputs.temperature[l] = 0.0;
                        //Amit Added
                        Inputs.axial[l] = 0.0;
                        //Amit Added
                }
                Inputs.lateral[7] = 0.0; 
                Inputs.stickSlip[7] = 0.0;
                //Amit Added
                Inputs.axial[7] = 0.0;
                //Amit Added
                
                Statement sta2 = conn.createStatement();
                //String SQLgetPNSNOpsData = "exec usp_getOpsDataForPNSerialNumber \'"+ Inputs.PN +"\', \'" + Inputs.CarrateReplaceSTR + Inputs.SN+ "\'";
                String SQLgetPNSNOpsData = "exec usp_getOpsDataForPNSerialNumber \'"+ Inputs.PN +"\', \'"+ Inputs.CarrateReplaceSTR + Inputs.SN+ "\'";
                
                //JOptionPane.showMessageDialog(null, SQLgetPNSNOpsData, "InfoBox: ToolName: " + Inputs.tool, JOptionPane.INFORMATION_MESSAGE);
                
                ResultSet rs2=null;
                
                try
                {
                        rs2 = sta2.executeQuery(SQLgetPNSNOpsData);
                }
                catch (SQLException e1) 
                {
                        e1.printStackTrace();
                }
                
                String repair;
                Inputs.propDrillHrs = new HashMap<String, Double>();
                Inputs.rev_count = 1;
                //Dan change String size from 10 t0 30 2016/8/11
                Inputs.rev = new String[30];
                
                // Strip <> from PN and SN 
                Inputs.PN = Inputs.PN.replaceAll("<|>", "");
                Inputs.SN = ReplaceCarrats(Inputs.SN);
                
                
                ///Amit added
                Inputs.jarringCount = 0;
                GetMaxModelWeightAndFlag(Inputs.PN);
                Inputs.repairFlag = false;
                repairRow = 1;
                Inputs.drillingHrsBeforeRepair = 0.0;
                double circHoursBeforeRepair = 0;
                int foundReparEnd = 0;
                Inputs.PNDuplicate = Inputs.PN;
                int TotaRows = 0;
                int Diff_Repair_DateFlag = 0;
                String LastRepairDate = "";
                
                while (rs2!=null && rs2.next()){
                        TotaRows++;
                        if(repairRow==1) 
                        {
                                Inputs.PNDuplicate = rs2.getString("PN"); //PN in data report
                                Inputs.TotaldrillingHours = rs2.getDouble("TotalDrillHrs");
                                Inputs.circHours = rs2.getDouble("TotalCircHrs");
                                Inputs.partDescription = rs2.getString("ComponentDescription");
                                LastRepairDate = getIncidentValues(rs2,"LastRepairDate");
                        }
                        
                        repair = rs2.getString("RepairHistoryFlag");                                     
                        
                        if (repair.equalsIgnoreCase("Y"))
                        {
                                Inputs.repairFlag = true;
                                while(rs2.next())
                                {
                                        TotaRows++;
                                        if(foundReparEnd==0)
                                        {
                                                repairRow++;
                                        }
                                        repair = rs2.getString("RepairHistoryFlag");     
                                        Diff_Repair_DateFlag = GetLastRepairDate(rs2,LastRepairDate);
                                        if ((repair.equalsIgnoreCase("N") || Diff_Repair_DateFlag>0) && foundReparEnd==0)
                                        {                                                      
                                        if(Inputs.repairFlag && (Inputs.PN.equalsIgnoreCase("A1000888000")||Inputs.PN.equalsIgnoreCase("10079662")|| Inputs.partDescription.startsWith("TRANSFORMER")
                                                        || Inputs.partDescription.startsWith("ALTERNATOR") ||Inputs.partDescription.startsWith("PUMP") || Inputs.partDescription.contains("HYDRAULIC") ))
                                        {
                                                Inputs.drillingHrsBeforeRepair = rs2.getDouble("TotalDrillHrs");
                                                        circHoursBeforeRepair = rs2.getDouble("TotalCircHrs");
                                                foundReparEnd = 1;
                                                        System.out.println("     There was a repair for the below model " );                                                       
                                                        Inputs.TotaldrillingHours = Inputs.TotaldrillingHours - Inputs.drillingHrsBeforeRepair;
                                                        Inputs.circHours = Inputs.circHours - circHoursBeforeRepair;                                                         
                                                }
                                                break;
                                        }
                                }
                        }
                        else
                        {
                                if(foundReparEnd==0) 
                                {
                                        repairRow++;
                                }
                        }
                        
                }
                
                try
                {
                        rs2 = sta2.executeQuery(SQLgetPNSNOpsData);
                }
                catch (SQLException e1) 
                {
                        e1.printStackTrace();
                }
                
                ////////////.
                int RowCount = 0;
                while (rs2!=null && rs2.next())
                {
                	    Inputs.rev[0] = rs2.getString("Revision");    
                	    //Dan Added on 1/26/2016 ------------
                	    Inputs.rev[0]=Inputs.rev[0].replaceAll("\\s", "");
                        //Dan Added Ends-------------
                        getRowValues(rs2);
                                                        
                        Inputs.drillHrs = rs2.getDouble("DrillHrs");
                        //dan test VSS2
                        //double vSStest = rs2.getDouble("LatVib0VSS2");
                        /////////Amit Added
                        drillHrs = Inputs.drillHrs;
                        /////////////////////////
                        repair = rs2.getString("RepairHistoryFlag");                                     
                                                                
                        Inputs.repairFlag = false;
                        if (repair.equalsIgnoreCase("Y"))
                        {
                                Inputs.repairFlag = true;
                        }                              
                                                        
                        Inputs.failureStatus = false;
                        Inputs.fStatus = false;
                        Inputs.failureSeverity = 0;                            
                                                        
                        int EndRowIterate = TotaRows;
                        if(foundReparEnd == 1)
                        {
                                EndRowIterate = repairRow-2;
                        }
                        
                        Inputs.IncidentDescription_ = "";
                        FailureType_tem_1 = "";
                        TFF_tem_2 = false;
                        IncidentKey_Str = "";
                                                        
                        while(rs2.next() && RowCount<EndRowIterate)
                        {
                                
                                //////////Amit Added
                                if(RowCount<=3)
                                {
                                        if(Inputs.IncidentDescription_.length()<10) 
                                        {
                                                Inputs.IncidentDescription_ = getIncidentValues(rs2,"IncidentDescription");
                                                if(Inputs.IncidentDescription_.length()>10) 
                                        {
                                                Inputs.Check_Incident_History = 1;
                                        }
                                        }
                                        if(FailureType_tem_1.length()<=0)
                                        {
                                                FailureType_tem_1 = getIncidentValues(rs2,"FailureType");
                                        }
                                        if(TFF_tem_2==false)
                                        {
                                                TFF_tem_2 = getIncidentValuesBool(rs2,"TFF");
                                        }
                                        if(IncidentKey_Str.length()<=0)
                                        {
                                                IncidentKey_Str = getIncidentValues(rs2,"IncidentKey");
                                        }
                                }
                                ///////////////////
                                
                                RowCount++;
                                repair = rs2.getString("RepairHistoryFlag");
                                if (repair.equalsIgnoreCase("Y"))
                                {
                                        Inputs.repairFlag = true;
                                }                                      
                                ////////Amit Added
                                String Rev = new String();
                                Rev = rs2.getString("Revision");
                                //Dan Added on 1/26/2016 ------------
                                Rev=Rev.replaceAll("\\s", "");
                                //Dan Added Ends-------------
                                try
                                {      
                                        // For calculating Proportional Drill Hours
                                        if(CheckRevision(Rev)==1) //check if Rev is already existing in Inputs.rev: if yes, add up the drilling hrs & set newRevision to false
                                        	                      //                                                if not, set newRevision to true, calculate the proportional drill hours for the previous Rev ID
                                        	                      //                                                        add current Rev to Inputs.rev and increase Inputs.rev_count by 1
                                        {
                                //if (Rev.equalsIgnoreCase(Inputs.rev[Inputs.rev_count - 1])){
                                                drillHrs = drillHrs + rs2.getDouble("DrillHrs");
                                                if (newRevision){
                                                        newRevision = false;
                                                }
                                        }
                                        else
                                        {
                                                newRevision = true;
                                                Inputs.propDrillHrs.put(Inputs.rev[Inputs.rev_count-1],(drillHrs / (Inputs.TotaldrillingHours)));//calculate proportional drillings
                                                drillHrs = rs2.getDouble("DrillHrs");
                                                
                                                Inputs.rev[Inputs.rev_count] = Rev;
                                                Inputs.rev_count = Inputs.rev_count  + 1;
                                        }
                                }
                                catch(NullPointerException ne)
                                {
                                        //String msg = runID + "," +location + ","+ jobID +"," +runNo + ": has Blank values in Drilling Hours";
                                        //pw.println(msg);
                                }
                                /////////////////                            
                                
                                
                                try
                                {
                                        if (IncidentKey_Str.length() != 0)
                                        {
                                                Inputs.Check_Incident_History = 1;
                                                
                                                if(FailureType_tem_1.length()>0 && !FailureType_tem_1.equalsIgnoreCase("FOOS") && !FailureType_tem_1.equalsIgnoreCase("PRN"))
                                                {
                                                        Inputs.fStatus = true;
                                                Inputs.failureStatus = true;
                                                }
                                                if(TFF_tem_2==true)
                                                {
                                                        Inputs.failureSeverity = 1;
                                                }
                                        }
                                }
                                catch(NullPointerException ne)
                                {
                                        // Should add a warning
                                }
                                
                                getRowValues(rs2);
                        }
                        
                        Inputs.numDataSets = EndRowIterate;
                        if(foundReparEnd == 1)
                        {
                                Inputs.numDataSets  = repairRow-1;
                        }
                        

                        rs2.close();
                        break;
                }
                
                if(Inputs.numEmptyData>0)
                {
                        Inputs.CalcPMD = (double)Inputs.numEmptyData / (double)(Inputs.numDataSets + 1) ;
                }
                pw.close();                                 
                if (Inputs.TotaldrillingHours > 0)
                {
                        //new ReadCummulativeDamageBucket();
                        // Calculation of Proportional Drill Hours for each revision.
                        Inputs.propDrillHrs.put(Inputs.rev[Inputs.rev_count-1],(drillHrs / (Inputs.TotaldrillingHours)));//(for current revision)
                        Inputs.prevDrillHrs = Inputs.TotaldrillingHours - Inputs.drillHrs; //total DrillHrs except the latest run
                        if(Inputs.PNDuplicate.length()>0 && tempList.contains(Inputs.PNDuplicate)) //if PN obtained from the data report contained in the modeled active part list of tool
                        {
                                Inputs.PN = Inputs.PNDuplicate; //current analysis PN = PN from data report
                        }
                        int tem_1=1;
                        if(Inputs.PN.contains("10218312"))
                        {
                                tem_1 = 1;
                        }
                        new runSinglePart();
                        fileBrowser.listTableModel.addRow(runSinglePart.rowData);
                }
                else
                {
                        pw1.println("PN " + Inputs.PN + " has ZERO Drilling Hours");
                }
                cnt++;
                return cnt;
        }

        /**
        * @throws SQLException
        */
        private void getToolNameAndList(PrintWriter pw1) throws SQLException {
                Statement sta2 = conn.createStatement();
                //String SQLgetPNSNOpsData = "exec usp_getOpsDataForPNSerialNumber \'"+ mainPN +"\', \'"+ Inputs.CarrateReplaceSTR + mainSN+ "\'";      
                // Jamisyeb : Look for actual part, not for assembly itself
                String SQLgetPNSNOpsData = "exec usp_getOpsDataForPNSerialNumber \'"+ Inputs.PN +"\', \'"+ Inputs.CarrateReplaceSTR + Inputs.SN+ "\'"; 
                
                //JOptionPane.showMessageDialog(null, SQLgetPNSNOpsData, "InfoBox: ToolName: " + "Empty", JOptionPane.INFORMATION_MESSAGE);
   
                ResultSet rs2=null;
                
                try
                {
                        rs2 = sta2.executeQuery(SQLgetPNSNOpsData);
                }
                catch (SQLException e1) 
                {
                        e1.printStackTrace();
                        return;
                }
                                        
                
                rs2.next();
                
                try
                {
                        
                        ///////////////////////////////////////////////////////        
                        try
                        {
                                Inputs.RunDescription_ = getIncidentValues(rs2,"Remark");
                        }
                        catch(NullPointerException ne)
                        {
                                Inputs.RunDescription_ = "";
                        }
                        try
                        {
                                Inputs.IncidentDescription_ = getIncidentValues(rs2,"IncidentDescription");
                        }
                        catch(NullPointerException ne)
                        {
                                Inputs.IncidentDescription_ = "";
                        }
                        try
                        {
                                GetLastRunDate(getIncidentValues(rs2,"RunDate"));
                        }
                        catch(NullPointerException ne)
                        {
                                Inputs.LastRunInformationData = 0.0;
                        }
                        
                        
                        Inputs.Check_Incident_History = 0;
                        new FindLeadingIndicators();         
                        //Amit Insert 
                        String PNASS =Inputs.PN;//Dan insert
                        String productDesc =  getIncidentValues(rs2,"ProductDescription");
                        Inputs.productDescription = productDesc; 
                        
                        System.out.println("Product Description :" +productDesc);
                        if(PNASS.startsWith("10079520")|| PNASS.startsWith("10182010")|| PNASS.startsWith("10140822")|| PNASS.startsWith("10371671")|| PNASS.startsWith("10074724")
                        		|| PNASS.startsWith("10092714")|| PNASS.startsWith("10186433")|| PNASS.startsWith("10193241")|| PNASS.startsWith("10229373"))
            			{
            				    Inputs.tool = "hydraulicunit";
            				    tempList = hydraulicunitList;
            			}
                        //05/04/2017 Dan
                        //else if(PNASS.startsWith("10176192")|| PNASS.startsWith("10256484"))
                        //{
                                //Inputs.tool = "test";
                                //tempList = testList;
                        //}
                        else if(productDesc.startsWith("LB") || productDesc.startsWith("GAU") || productDesc.startsWith("MOS") || productDesc.startsWith("MTO") || productDesc.startsWith("PUM")
                        		|| PNASS.startsWith("10261693")|| PNASS.startsWith("LCP") || productDesc.startsWith("ATK")|| productDesc.startsWith("NBG")) //|| PNASS.startsWith("10283216") KSA requested PN under validation || PNASS.startsWith("10318107")
                        {
                                Inputs.tool = "atcurve";
                                tempList = atcurveList;
                        }
                        else if (productDesc.startsWith("ASS") || productDesc.startsWith("ASU") || productDesc.startsWith("HU") || PNASS.startsWith("10256007")
                        		|| PNASS.startsWith("10256131") || PNASS.startsWith("10257079")|| PNASS.startsWith("10257549") || PNASS.startsWith("10257760")
                        		|| PNASS.startsWith("10278193") || PNASS.startsWith("10302413")) //Slienced due to bad performance PNASS.startsWith("10364366")|| PNASS.startsWith("10257346")|| PNASS.startsWith("10196936") 
                        	//10258608 activated in ATCurve, since it has latest model
                        {
                                Inputs.tool = "ass";
                                tempList = assList; 
                        }
                        else if(productDesc.startsWith("HBC") || productDesc.startsWith("HEA") || productDesc.startsWith("BCPM")|| PNASS.startsWith("10102987")
                        		|| PNASS.startsWith("10160282")|| PNASS.startsWith("10138147")|| PNASS.startsWith("10150470")|| PNASS.startsWith("10064669")) //|| PNASS.startsWith("10075534") silenced on 6/26/2017
                        {
                                Inputs.tool = "bcpm";
                                tempList = bcpmList;
                        }
                        else if(productDesc.startsWith("ASN") || productDesc.startsWith("AOA")|| productDesc.startsWith("OSA")|| productDesc.startsWith("OTK")|| productDesc.startsWith("COP")|| productDesc.startsWith("CoP"))
                        {
                                Inputs.tool = "ontrak";
                                tempList = ontrakList;
                        }
                        else if(productDesc.startsWith("DAS") || productDesc.startsWith("SDS")|| productDesc.startsWith("SNT")|| productDesc.startsWith("SDM")|| productDesc.startsWith("DHP") || productDesc.startsWith("VTK")|| productDesc.startsWith("ASE")
                        		||productDesc.startsWith("MPR")||productDesc.startsWith("RPTrak")||productDesc.startsWith("MEM")||productDesc.startsWith("UPA")||productDesc.startsWith("DPS")||productDesc.startsWith("SRIG"))
                        {
                                Inputs.tool = "probe";
                                tempList = probeList;
                        }
                        else if(productDesc.startsWith("DGS")||productDesc.startsWith("CTK"))
                        {
                                Inputs.tool = "coiltrak";
                                tempList = coiltrakList;
                        }
                        else if(productDesc.startsWith("CCN") || productDesc.startsWith("SDN")|| productDesc.startsWith("ORD") || productDesc.startsWith("ORA") || productDesc.startsWith("SBS"))
                        {
                                Inputs.tool = "lithotrak";
                                tempList = lithotrakList;
                        }
                        else 
                        {
                                // The description of the part is missing in maps
                                //JOptionPane.showMessageDialog(null, "No part description found", "Data Error !!!", JOptionPane.ERROR_MESSAGE);
                                pw1.println("Data Error: PN " + Inputs.PN + ": no part description found in MaPS");
                        }
                        rs2.close();
                }
                catch(Exception e)
                {
                        rs2.close();
                        System.out.println(e);
                }
        }

        private static void GetMaxModelWeightAndFlag(String PN_this) 
        {
                String TargetStr = "";
                String SearchStr = "";
                                
                String[] PN_GlobalList_temp = new String[550];               
                PN_GlobalList_temp = FindLeadingIndicators.PN_GlobalList;
                
                Inputs.ModelWeight_FoundTargetPart = 0;      
                                
                for (int i = 0;i<550;i++)
                {
                        TargetStr = PN_GlobalList_temp[i].trim();
                        SearchStr = PN_this.trim();
                        if(TargetStr.equalsIgnoreCase(SearchStr))
                        {
                                Inputs.ModelWeight_FoundTargetPart = 1;
                                break;
                        }
                }              
        }
        
        
        private void getRowValues(ResultSet rs3) throws SQLException {
                
                String runID = rs3.getString("RunID");
                String location = rs3.getString("Location");
                String jobID = rs3.getString("JobNo");
                String runNo = rs3.getString("RunNo");
                /////Amit Added//////////////          
                String Jarring_tem_f = "";
                
                Inputs.totalDistDrilled = Inputs.totalDistDrilled + rs3.getDouble("DistanceDrilled");   
                
                Jarring_tem_f = getIncidentValues(rs3,"Jarring");
                if(Jarring_tem_f!=null)
                {
                        if(Jarring_tem_f.equalsIgnoreCase("Yes"))
                        {
                                Inputs.jarringCount = Inputs.jarringCount+1;
                        }
                }
                
                double sumLat = 0, sumTemp = 0, sumStSlip = 0,sumAxial=0.0;
                for ( int l = 0; l <= 7; l++){
                        double lat = 0;
                        double temp = 0;
                        double stSlip = 0;
                        double axial_vib = 0.0;
                        try{
                                lat = rs3.getDouble("LatVib"+l);
                                stSlip = rs3.getDouble("StiSlip"+l);
                                axial_vib = rs3.getDouble("AxVib"+l);
                                
                                sumLat = sumLat + lat;
                                sumStSlip = sumStSlip + stSlip;
                                sumAxial = sumAxial + axial_vib;
                                
                                Inputs.lateral[l] = Inputs.lateral[l] + lat;
                                Inputs.stickSlip[l] = Inputs.stickSlip[l] + stSlip;
                                Inputs.axial[l] = Inputs.axial[l]+axial_vib;
                                        
                                if (l<7){
                                        temp = rs3.getDouble("Temp"+l);
                                        sumTemp = sumTemp + temp;
                                        Inputs.temperature[l] = Inputs.temperature[l] + temp;
                                }
                        }catch (NullPointerException ne){
                                String msg = runID + "," +location + ","+ jobID +"," +runNo + ": has Blank values for Temperature or Lateral or StickSlip";
                                pw.println(msg);
                        }
                }
                // check missing data
                if (sumLat == 0 || sumTemp == 0){
                        Inputs.numEmptyData = Inputs.numEmptyData + 1;
                        String msg = runID + "," +location + ","+ jobID +"," +runNo;
                        pw.println(msg);
                }
        }      
        
                
        private static int CheckRevision(String targetRev) 
        {
                int CheckRevision = 0;
                for (int j = 0 ; j < Inputs.rev_count; j++) 
                {
                        if (targetRev.equalsIgnoreCase(Inputs.rev[j])) 
                        {
                                CheckRevision = 1;
                                break;
                        }
                }
                return CheckRevision;
        }
        
        private static boolean getIncidentValuesBool(ResultSet rs3,String FieldName) throws SQLException 
        {
                boolean TestStr1 = false;
                
                try
                {      
                        TestStr1 = rs3.getBoolean(FieldName);                                           
                }              
                catch(Exception e)
                {
                        
                }
                
                return TestStr1;
        }
        
        private static int GetLastRepairDate(ResultSet rs3,String LastDate)
        {        
        int LenStr=0;
        int EndIndex = 0;
        long diff_date=0;
        String CurrentDate = "";
        
        int foundMaintRowBefore_Run = 0;
        
        SimpleDateFormat formatter = new SimpleDateFormat("yyyy-MM-dd");      
                
        LenStr = LastDate.length();
        EndIndex = LastDate.indexOf(" ");
        LastDate = LastDate.substring(0, EndIndex);      
        try
        {
                CurrentDate = getIncidentValues(rs3,"LastRepairDate");
        }
        catch(Exception e)
                {
                        
                }
                        
        if(CurrentDate.length()>0 && LenStr>0)
        {
                LenStr = CurrentDate.length();
                EndIndex = CurrentDate.indexOf(" ");
                CurrentDate = CurrentDate.substring(0, EndIndex);       
                try
                    {
                        Date CurrentRepair_Date = formatter.parse(CurrentDate);
                        Date LastRepair_Date = formatter.parse(LastDate);
                        diff_date = -(CurrentRepair_Date.getTime()-LastRepair_Date.getTime())/(1000 * 60 * 60 * 24);
                        if(diff_date>10)
                        {
                                foundMaintRowBefore_Run = 1;
                        }
                    }
                catch(Exception ex)
                    {
                    }
        }
        else if(CurrentDate.length()<=0 && LenStr>0)
        {
                foundMaintRowBefore_Run = 1;
                return foundMaintRowBefore_Run;
        }
        return foundMaintRowBefore_Run;
     }
        
        private static void GetLastRunDate(String CurrentDate)
        {        
        int LenStr=0;
        int EndIndex = 0;
        long diff_date=0;
        int foundMaintRowBefore_Run = 0;
        
        SimpleDateFormat formatter = new SimpleDateFormat("yyyy-MM-dd");      
                                
        if(CurrentDate.length()>0)
        {
                LenStr = CurrentDate.length();
                EndIndex = CurrentDate.indexOf(" ");
                CurrentDate = CurrentDate.substring(0, EndIndex);       
                try
                    {
                        Date CurrentRepair_Date = formatter.parse(CurrentDate);                   
                        Inputs.LastRunInformationData = (CurrentRepair_Date.getTime())/(1000 * 60 * 60 * 24);
                    }
                catch(Exception ex)
                    {
                    }
        }      
        
     }
        
        private static String getIncidentValues(ResultSet rs3,String FieldName) throws SQLException 
        {
                String TestStr1 = new String();
                TestStr1 = "";
                try
                {      
                        TestStr1 = rs3.getString(FieldName);                     
                }              
                catch(Exception e)
                {
                        
                }
                if(TestStr1==null)
                {
                        TestStr1 = "";
                }
                
                return TestStr1;
        }
        
        
        private static ResultSet getTopPNSN_ResultSet(ResultSet rs3,String PN,String SN) throws SQLException 
        {
                String Temp_TopPN = "";
                String Temp_TopSN = "";
                ResultSet rs2=null;
                if(rs3 != null)
                {
                        try
                        {      
                                Temp_TopPN = rs3.getString("TopPN");                  
                        }              
                        catch(Exception e)
                        {
                                
                        }
                        try
                        {      
                                Temp_TopSN = rs3.getString("TopSN");  
                                Temp_TopSN = Temp_TopSN.replaceAll("<|>", "");
                        }              
                        catch(Exception e)
                        {
                                
                        }
                        
                        if(Temp_TopPN.length()>0 && Temp_TopSN.length()>0)
                        {
                                if(!Temp_TopPN.equalsIgnoreCase(PN) && !Temp_TopSN.equalsIgnoreCase(SN))
                                {
                                        Statement sta2 = conn.createStatement();
                                        String SQLgetPNSNOpsData = "exec usp_getOpsDataForPNSerialNumber \'"+ Temp_TopPN +"\', \'"+ Temp_TopSN+ "\'";                
                                        rs2 = sta2.executeQuery(SQLgetPNSNOpsData);              
                                        rs2.next();
                                }
                        }
                        
                }
                
                return rs2;
        }
        
        private static String getTopPNSN_FieldValues(ResultSet rs_Top,ResultSet rs_original,String FieldName) 
        {
                String FieldValue = "";
                try
                {
                        FieldValue = getIncidentValues(rs_original,FieldName);
                }
                catch(Exception e)
                {
                        
                }
                if(FieldValue.length()<=0)
                {
                        try
                        {                              
                                FieldValue = getIncidentValues(rs_Top,FieldName);
                        }
                        catch(Exception e)
                        {
                                
                        }
                }
                return FieldValue;
        }
        
        private static boolean getTopPNSN_FieldValuesBool(ResultSet rs_Top,ResultSet rs_original,String FieldName) 
        {
                boolean FieldValue = false;
                try
                {
                        FieldValue = getIncidentValuesBool(rs_original,FieldName);
                }
                catch(Exception e)
                {
                        
                }
                if(FieldValue==false)
                {
                        try
                        {                              
                                FieldValue = getIncidentValuesBool(rs_Top,FieldName);
                        }
                        catch(Exception e)
                        {
                                
                        }
                }
                return FieldValue;
        }
        
        private static String ReplaceCarrats(String This_SN)
    {
        String This_SNOld = This_SN;
        This_SN = This_SN.replaceAll("<|>", "");
        if(This_SNOld.length()==This_SN.length())
        {
                Inputs.CarrateReplaceSTR = "";
        }
        else
        {
                Inputs.CarrateReplaceSTR = "<>";
        }
        return This_SN;
    }
        
}
