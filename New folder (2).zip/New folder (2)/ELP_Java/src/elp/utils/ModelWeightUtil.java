package elp.utils;
import java.util.HashMap;

import elp.ModelWeight;
import elp.getLifeSingleRevision;

import org.apache.commons.math3.distribution.LogNormalDistribution;
import org.apache.commons.math3.distribution.NormalDistribution;

public class ModelWeightUtil {

	static double aveTotalMean;
	static double stdTotalMean;
	static double varTotalMean;
	public static double[] PM = {0,0,0,0,0,0};
	
	protected static double Delta_temp;
	protected static double Delta_lat;
	protected static double Delta_stsl;
	protected static double Delta_hrs;
	protected static double scaleProbability ;
	protected static double Prob_ScaleFactorMult_ComparePF_Life;
	protected static double Temo_Mult;
	protected static double scaleFactorMultComparePfLife;
		
	protected HashMap<String, String> inputs;
	protected static double decisionValue;
	protected static double decisionVal;
	public static double multFactor = 1;
	protected static double[][] ModelMultFactor= {{1,1,1,1,1,1},{1,1,1,1,1,1},{1,1,1,1,1,1},{1,1,1,1,1,1},{1,1,1,1,1,1},{1,1,1,1,1,1}};
	protected static double proportionDrill[] = {1};
	
	protected static NormalDistribution normalDist = new NormalDistribution();
	public static double yetaSum;
	public static double lifeMeanSum;
	public static double probabilityDistributionFunctionSum;
	public static double cumulativeDistributionFunctionSum;
	//double stdevLifeSum;
	public static double varDistributionSum[]={0,0,0};
	
	public static double yeta;
	public static double lifeMean;
	public static double Pdf;
	public static double Pf;
	//double stdevLife;
	public static double[] varDistribution = {0,0,0};
	
	public static double setMultFactor() {
		
		double Life_Delta = (Inputs.drillHrsForModelUpdate - Inputs.aveFailureTime) / Inputs.stdFailureTime;
		double Life_Adder;
		double BayesianThreshold = 0.5;
		double aveFailureTime = 0;
		int ModeledFailureTimeLimit = 0;
		
		aveFailureTime = (Inputs.aveFailureTime + 0.75 * Inputs.stdFailureTime);
		
		if (Inputs.drillHrsForModelUpdate > 0.5 * (Inputs.maxFailureTime + Inputs.maxOperatingTime)) {
		    ModeledFailureTimeLimit = 1;
		}
		
		if (ModeledFailureTimeLimit == 1 || Inputs.failureStatus || (scaleFactorMultComparePfLife > 1 && Pf < BayesianThreshold) || 
				((Pf < BayesianThreshold) && (scaleFactorMultComparePfLife < 1) && (Inputs.drillHrsForModelUpdate > Inputs.aveFailureTime + Inputs.stdFailureTime))) {
		    multFactor = 
		    		(Temo_Mult * (Pf * lifeMean + (1 - Pf) * Inputs.drillHrsForModelUpdate) + Prob_ScaleFactorMult_ComparePF_Life * aveFailureTime) / lifeMean;
		}
		else if (Inputs.tool.toLowerCase().equalsIgnoreCase("ass") && 
				((Pf > BayesianThreshold && (Life_Delta > 3 && decisionValue < 0)) || (Life_Delta <= 0 && decisionValue < 0))) {
		    Life_Adder = Inputs.maxOperatingTime;
		    multFactor = 
		    		(Pf * lifeMean + (1 - Prob_ScaleFactorMult_ComparePF_Life) * Inputs.drillHrsForModelUpdate + Prob_ScaleFactorMult_ComparePF_Life * Life_Adder) / (lifeMean * (Pf + 1));
		}
		else if (!Inputs.tool.toLowerCase().equalsIgnoreCase("ass") && 
				(Pf > BayesianThreshold && ((Life_Delta > 3 && decisionValue < 0) || (Life_Delta <= 0 && decisionValue < 0)))) {
		    Life_Adder = Inputs.maxOperatingTime;
		    multFactor = 
		    		(Pf * lifeMean + (1 - Prob_ScaleFactorMult_ComparePF_Life) * Inputs.drillHrsForModelUpdate + Prob_ScaleFactorMult_ComparePF_Life * Life_Adder) / (lifeMean * (Pf + 1));
		}
		else if (Inputs.tool.toLowerCase().equalsIgnoreCase("ass") && 
				((Pf > BayesianThreshold && (Life_Delta > 3 && decisionValue < 0.25)) || (Life_Delta > 2 && decisionValue < 0) || (Life_Delta <= 0 && decisionValue < 0.25))) {
		    Life_Adder = (Inputs.maxOperatingTime + Inputs.maxFailureTime) / 2;
		    multFactor = 
		    		(Pf * lifeMean + (1 - Prob_ScaleFactorMult_ComparePF_Life) * Inputs.drillHrsForModelUpdate + Prob_ScaleFactorMult_ComparePF_Life * Life_Adder) / (lifeMean * (Pf + 1));
		}
		else if (!Inputs.tool.toLowerCase().equalsIgnoreCase("ass") &&
				(Pf > BayesianThreshold && ((Life_Delta > 3 && decisionValue < 0.25) || (Life_Delta > 2 && decisionValue < 0) || (Life_Delta <= 0 && decisionValue < 0.25)))) {
		    Life_Adder = (Inputs.maxOperatingTime + Inputs.maxFailureTime) / 2;
		    multFactor = 
		    		(Pf * lifeMean + (1 - Prob_ScaleFactorMult_ComparePF_Life) * Inputs.drillHrsForModelUpdate + Prob_ScaleFactorMult_ComparePF_Life * Life_Adder) / (lifeMean * (Pf + 1));
		}
		else if (Pf > BayesianThreshold && ((Life_Delta > 3 && decisionValue < 0.5) || (Life_Delta > 2 && decisionValue < 0.25) || (Life_Delta > 1 && decisionValue < 0))) {
		    Life_Adder = Inputs.maxFailureTime;
		    multFactor = 
		    		(Pf * lifeMean + (1 - Prob_ScaleFactorMult_ComparePF_Life) * Inputs.drillHrsForModelUpdate + Prob_ScaleFactorMult_ComparePF_Life * Life_Adder) / (lifeMean * (Pf + 1));
		}
		else if (Pf > BayesianThreshold && ((Life_Delta > 2 && decisionValue < 0.5) || (Life_Delta > 1 && decisionValue < 0.25))) {
		    Life_Adder = (Inputs.maxFailureTime + aveFailureTime) / 2;
		    multFactor = 
		    		(Pf * lifeMean + (1 - Prob_ScaleFactorMult_ComparePF_Life) * Inputs.drillHrsForModelUpdate + Prob_ScaleFactorMult_ComparePF_Life * Life_Adder) / (lifeMean * (Pf + 1));
		}
		else if (Pf > BayesianThreshold && (Life_Delta > 1 && decisionValue < 0.5)) {
		    Life_Adder = (Inputs.maxFailureTime + 2 * aveFailureTime) / 3;
		    multFactor = 
		    		(Pf * lifeMean + (1 - Prob_ScaleFactorMult_ComparePF_Life) * Inputs.drillHrsForModelUpdate + Prob_ScaleFactorMult_ComparePF_Life * Life_Adder) / (lifeMean * (Pf + 1));
		}
		else if (Pf > BayesianThreshold && ((Life_Delta > 0.5 && decisionValue < 0.5) || (Life_Delta > 0 && decisionValue < 0))) {
		    Life_Adder = (Inputs.maxFailureTime + 5 * aveFailureTime) / 6;
		    multFactor = 
		    		(Pf * lifeMean + (1 - Prob_ScaleFactorMult_ComparePF_Life) * Inputs.drillHrsForModelUpdate + Prob_ScaleFactorMult_ComparePF_Life * Life_Adder) / (lifeMean * (Pf + 1));
		}
		else if (Pf > BayesianThreshold && (Life_Delta > 0.5 && decisionValue < 0.75)) {
		    Life_Adder = (Inputs.maxFailureTime + 6 * aveFailureTime) / 7;
		    multFactor = 
		    		(Pf * lifeMean + (1 - Prob_ScaleFactorMult_ComparePF_Life) * Inputs.drillHrsForModelUpdate + Prob_ScaleFactorMult_ComparePF_Life * Life_Adder) / (lifeMean * (Pf + 1));
		}
		else if (Pf > (BayesianThreshold + 0.25) && Life_Delta > 0) {
		    Life_Adder = aveFailureTime;
		    multFactor = 
		    		(Pf * lifeMean + (1 - Prob_ScaleFactorMult_ComparePF_Life) * Inputs.drillHrsForModelUpdate + Prob_ScaleFactorMult_ComparePF_Life * Life_Adder) / (lifeMean * (Pf + 1));
		}
		multFactor = CalcMult_ScaleFactor_temp(lifeMean);
		return multFactor;
	}

	public double findUserScalefactor() {

	    double deltaHrs = Inputs.TotaldrillingHours - (Inputs.aveFailureHoursSus - (Inputs.stdevFailureHoursSus)/2);
	    double adderScale = 0.2;
	    
	    if (deltaHrs < 0 && decisionValue < 0 && (!Inputs.failureStatus) ) {
	        return( Inputs.negativeSusScaleFactor + adderScale);
	    }else if ((deltaHrs < 0 || decisionValue < 0) && (!Inputs.failureStatus) ) {
	        return(0.5 * (Inputs.negativeSusScaleFactor + Inputs.negativeScaleFactor + adderScale));
	    }else
	        return(Inputs.negativeScaleFactor);
		
	}

	public static double CompareAverageLife_F_S() {
		
		double temp = comparePfAverageLife();
		
		double PivotTime = Inputs.aveFailureHrsSus;
        if(Inputs.aveFailureTime > Inputs.aveFailureHrsSus)
            PivotTime = Inputs.aveFailureTime;
        
        
        if((decisionValue < 0 ) && (Inputs.TotaldrillingHours < PivotTime) && (!Inputs.fStatus))
	        return(1.0);
	    else
	        return(0);
	}


	public double getMaxModelWeight(){

		double scaleFactor = 1;
		double maxModelWeight = scaleFactor * 20;
	    
	    //getPNValues();
	    
		if (Inputs.stdTemperature > 0) {
			Delta_temp = (Inputs.temperature1 - Inputs.aveTemperature) / Inputs.stdTemperature;
		}else{
			Delta_temp = (Inputs.temperature1 - Inputs.aveTemperature);
		}
		
		if (Inputs.stdLateral > 0) {
			Delta_lat = (Inputs.lateral1 - Inputs.aveLateral) / Inputs.stdLateral;
		}else{
			Delta_lat = (Inputs.lateral1 - Inputs.aveLateral);
		}
		
		if (Inputs.stdStickSlip > 0) {
			Delta_stsl = (Inputs.stickSlip1 - Inputs.aveStickSlip) / Inputs.stdStickSlip;
		}else{
			Delta_stsl = (Inputs.stickSlip1 - Inputs.aveStickSlip);
		}
		    
		if (Inputs.stdFailureTime > 0) {
			Delta_hrs = (Inputs.TotaldrillingHours - Inputs.aveFailureTime) / Inputs.stdFailureTime;
		}else{
			Delta_hrs = (Inputs.TotaldrillingHours - Inputs.aveFailureTime);
		}
			     
	    decisionVal = Delta_temp + Delta_lat + Delta_stsl - Delta_hrs;
	    
	    if (decisionVal >= 8) {
	        return(maxModelWeight);
	    }else if (decisionVal >= 3) {
	        return(maxModelWeight / 2);
	    }else if (decisionVal >= 1) {
	        return(maxModelWeight / 4);
	    }else if (decisionVal >= -1) {
	        return(maxModelWeight / 8);
	    }else if (decisionVal >= -3) {
	        return(maxModelWeight / 16);
	    }else if (decisionVal >= -8) {
	        return(maxModelWeight / 32);
	    }else{
	        return(maxModelWeight / 64);
	    }
	}

	
	public void getInitialModelWeight(double[] PM){
		double tempWeight = getMaxModelWeight();
		double maxModelWeight = 1;
		double minModelWeight = 1;
		double diffWeight, sumWeight=0;
		
		if (tempWeight > 1){
			maxModelWeight = tempWeight;
		}else{
			minModelWeight = tempWeight; 
		}
		diffWeight = (maxModelWeight - minModelWeight)/5;
		
		for (int i = 0; i < 6; i++){
			sumWeight = sumWeight + minModelWeight +((i)*diffWeight); 
		}
		for (Integer i=0; i<6; i++){
			if (maxModelWeight > 1){
				PM[i] = (minModelWeight +((5-i)*diffWeight))/sumWeight;
			}else{
				PM[i] = (minModelWeight +(i*diffWeight))/sumWeight;
			}
		}
	}
	// presently in java the modelMultFactor is being taken directly from input file.
	// need to check how the below can be implemented (vb logic) 
	public void InitializeModelMultFactor(double scaleFactor){
		double[][] BaseLifeFor_ARev = {{1,0},{1,1},{1,2},{1,3},{1,4},{1,5}};
		
		for (int i =0; i < proportionDrill.length; i++){
			//get base life prob of failure for each model type
			for (int j = 0; j < 6; j++){
		    	BaseLifeFor_ARev[j][0] = GetBase_Pf_ForARev();
		        //BaseLifeFor_ARev[j][1] = j;
		    }
		    ModelWeight.sort2DArray(BaseLifeFor_ARev, 6);   

		    //' give highest weight the Lowest probability
		    for (int j = 0; j < 6; j++){
		        ModelMultFactor[i][(int) BaseLifeFor_ARev[j][1]] = multFactor;
		    }
		}
	}
	
	/*	------ Since GetBase_Pf_ForARev is not used anywhere calling the function.
	// the values selected in function getModelByRevision() is already directly avialable here, 
	 * so I have directly called the Get_Pf_MultFactor() function (renamed to getBase_Pf_ForARev())
	 *   
	private double GetBase_Pf_ForARev(ByVal This_Revision As String, ByVal ModelSheetName As String, ByVal ModelIndex As Integer) 
		Dim lifemean As Double
	    
	    RevModelRowID = GetModelByRevision(This_Revision, ModelSheetName)
	    DistributionType = GetDistributionByRevision(This_Revision, ModelSheetName)
	    Call GetCoefficientRows(RevModelRowID, ModelSheetName)
	    
	    ' Average
	    temp_1 = FindAvefailureTime(Worksheets("FilteringInputs").Cells(2, 20).Value, 13)
	    lat_1 = FindAvefailureTime(Worksheets("FilteringInputs").Cells(2, 20).Value, 15)
	    stsl_1 = FindAvefailureTime(Worksheets("FilteringInputs").Cells(2, 20).Value, 17)
	    distdrilled_1 = FindAvefailureTime(Worksheets("FilteringInputs").Cells(2, 20).Value, 19)
	    GetBase_Pf_ForARev = Get_Pf_MultFactor(ModelSheetName, temp_1, lat_1, stsl_1, distdrilled_1, DistributionType, CurrentDrillHours, lifemean)
	}
	*/
	// below function include both getBase_PF_ForARev and get_PF_MultFactor() functions from VB
	public double GetBase_Pf_ForARev(){ 
		
	    double[] estimatesInp = Inputs.estimateMean[1];
	    double yeta, Pf;
	    double beta_mean = estimatesInp[7];
	   
	    double LifeMean_Ln_MainEffects = estimatesInp[0] + estimatesInp[1] * Inputs.temperature1 +
				estimatesInp[2] * Inputs.stickSlip1 + estimatesInp[3] * Inputs.lateral1 + 
				estimatesInp[6] * Inputs.DistanceDrilledSeverity1;
				
	    double LifeMean_Ln_Interactions = estimatesInp[4] * Inputs.temperatureStickSlip1 + 
				estimatesInp[5] * Inputs.temperatureLateral1 + 
				estimatesInp[8] * Inputs.stickSlipLateral1; 
	    		
	    double LifeMean_Ln = LifeMean_Ln_MainEffects + LifeMean_Ln_Interactions;
	    LifeMean_Ln = getLifeSingleRevision.CheckLifeMean(LifeMean_Ln, beta_mean, Inputs.distributionType.get(RevisionValues.est[1]));
	        
	    if (Inputs.distributionType.get(RevisionValues.est[1]).toLowerCase().equals("weibull")) {
	        yeta = Math.exp(LifeMean_Ln);
	        Pf = 1 - Math.exp(-Math.pow((Inputs.TotaldrillingHours / yeta) , beta_mean));
	    }else{
	        yeta = LifeMean_Ln + 0.5 * beta_mean * beta_mean;
	        LogNormalDistribution logNormal = new LogNormalDistribution( yeta, beta_mean);
	        Pf  = logNormal.cumulativeProbability(Inputs.TotaldrillingHours);
	    }
	 
	    return(Pf);
	}
	 
	
	public Integer FindIndicesForUpdate(int NumDataSets, int loopIndex, int[] updateIndices){
		int IndicesForUpdate = 1;
		int i = loopIndex;
		@SuppressWarnings("unused")
		int prev_i = 0;
		int CountValidData_Update = 0;
		updateIndices[2] = loopIndex;
		if (NumDataSets + 1 > 1) {
		    while ((i <= NumDataSets + 1) && CountValidData_Update < 2){
		        if (Check_Prev_And_This_OperVar()) {
		            updateIndices[2 - CountValidData_Update] = i;
		            CountValidData_Update = CountValidData_Update + 1;
		            prev_i = i;
		        }
		        i = i + 1;
		    }
		}
		IndicesForUpdate = CountValidData_Update;
		
		if (CountValidData_Update == 1) {
		    updateIndices[1] = loopIndex;
		}
		return(IndicesForUpdate);
	}
	
	
	public boolean Check_Prev_And_This_OperVar(){
		
		//CumulativeStickSlip_prev = Worksheets("Predictions_Life_Pf_of_1").Cells(prev_i, NormStickSlip_Col).Value;
		//CumulativeStickSlip_this = Worksheets("Predictions_Life_Pf_of_1").Cells(this_i, NormStickSlip_Col).Value;
		
		double diffSS = 100 * Math.abs(Inputs.CumulativeStickSlip_prev - Inputs.stickSlip1) / Inputs.CumulativeStickSlip_prev;
		double diffTemp = 100 * Math.abs(Inputs.CumulativeTemperature_prev - Inputs.temperature1) / Inputs.CumulativeTemperature_prev;
		double diffLateral = 100 * Math.abs(Inputs.CumulativeLateral_prev - Inputs.lateral1) / Inputs.CumulativeLateral_prev;
		
		if (Inputs.prevDrillHrs > 0) {
		}else{
		}
		
		if ((diffSS > 1 || diffTemp > 1 || diffLateral > 1)) {
		    return(true);
		}else{
			return(false);
		}
	}
	
	public double calcTempCorrections(int i, double drillingHours, double circHours, double normTemp) {
		
		double Gap_Circ_Drill = circHours - drillingHours;
		
		if (drillingHours < circHours && circHours != 0 && drillingHours != 0) {
			if (Gap_Circ_Drill <= 0) {
		        Gap_Circ_Drill = 0 ;
			}
		    else if(Gap_Circ_Drill >= 1000) {
		    	Gap_Circ_Drill = 1000;
		    }

			double Gap_m = 0.5 / 999;
		    double Gap_c = 1;
		    // Electronics certified up to 125C
		    if (normTemp > Inputs.severityBucketThreshold) {
		    	normTemp = normTemp / (Gap_m * (Gap_Circ_Drill) + Gap_c);
			}
		}
		return normTemp;
	}

	public static double ModelMultFactor() {
		// TODO Auto-generated method stub
		return multFactor;
	}
	
	public static double comparePfAverageLife(){
		
		double aveTemperature = Inputs.aveTemperature;//update stress_ave
		double aveLateral = Inputs.aveLateral;
		double aveStickSlip = Inputs.aveStickSlip;
		
		Inputs.Delta_temp_glb = 0.0;
		Inputs.Delta_lat_glb = 0.0;
		Inputs.Delta_stsl_glb = 0.0;
	    
	    if (Inputs.stdTemperature > 0) {
	        Delta_temp = (Inputs.temperature1 - aveTemperature) / Inputs.stdTemperature;//difference between current stress and ave stress
	    }else{
	        Delta_temp = (Inputs.temperature1 - aveTemperature) / aveTemperature;
	    }
	    if (Delta_temp > 0){
	    	Inputs.Delta_temp_glb  = 1;
	    }
	    
	    if (Inputs.stdLateral > 0) {
	        Delta_lat = (Inputs.lateral1 - aveLateral) / Inputs.stdLateral;
	    }else{
	        Delta_lat = (Inputs.lateral1 - aveLateral) / aveLateral;
	    }
	    if (Delta_lat > 0){
	    	Inputs.Delta_lat_glb  = 1;
	    }
	    
	    if (Inputs.stdStickSlip > 0) {
	        Delta_stsl = (Inputs.stickSlip1 - aveStickSlip) / Inputs.stdStickSlip;
	    }else{
	        Delta_stsl = (Inputs.stickSlip1 - aveStickSlip) / aveStickSlip;
	    }
	    if (Delta_stsl > 0){
	    	Inputs.Delta_stsl_glb  = 1;
	    }
	        
	    if (Inputs.stdFailureTime > 0) {
	        Delta_hrs = (Inputs.TotaldrillingHours - Inputs.aveFailureTime) / Inputs.stdFailureTime;
	    }else{
	        Delta_hrs = (Inputs.TotaldrillingHours - Inputs.aveFailureTime) / Inputs.aveFailureTime;
	    }
	     
	    aveTotalMean = aveTemperature + aveLateral + aveStickSlip;//total stress mean
	    stdTotalMean = Math.sqrt(Math.pow(Inputs.stdTemperature,2) + Math.pow(Inputs.stdLateral,2) + Math.pow(Inputs.stdStickSlip,2));//total stress std
	    varTotalMean = Inputs.temperature1 + Inputs.lateral1 + Inputs.stickSlip1;//total stress
	    
	    decisionValue = (varTotalMean - aveTotalMean) / stdTotalMean;//total stress- total stress mean)\std
	    
        if (decisionValue > 0) {
	        return (1.0 + Math.log(1 + Math.abs(decisionValue)));//acceleartion factors
	    }else if (decisionValue < 0) {
	        return (1.0 / (1 + Math.log(1 + Math.abs(decisionValue))));
	    }else{
	    	return(1.0);
	    }
	}
	
	public static double GetCummulativeAxial()
	{
		double sum_4_8 = Inputs.axial[2] + Inputs.axial[3] + Inputs.axial[4] + Inputs.axial[5] + Inputs.axial[6];
	    double m_slope = 2.0 / (40.0 - 5.0);
	    double c_intercept = 1 - m_slope * 5.0;
	    double GetCummulativeAxial = sum_4_8 * m_slope + c_intercept;
	    
	    if (sum_4_8 > 40)
	    {
	        GetCummulativeAxial = 3.0;
	    }
	    if (sum_4_8 < 5)
	    {
	        GetCummulativeAxial = 1.0;
	    }
	    return GetCummulativeAxial;
	}	
	
	public static double GetCummulativeJarring()
	{
		double numRunWeight =(0.2/ Math.exp(Inputs.negativeScaleFactor)) * Inputs.numDataSets;
		double GetCummulativeJarring = 1.0+(1.0/ Math.exp(Inputs.negativeScaleFactor)) * Inputs.jarringCount + numRunWeight;
		Inputs.Delta_jarr_glb = 0;
		if(Inputs.jarringCount>3)
		{
			Inputs.Delta_jarr_glb = 1;
		}
	    return GetCummulativeJarring;
	}	
	
	
	public static double CalcMult_ScaleFactor_temp(double Life_mean)
	{
		//Inputs.maxOperatingTime;
		//Inputs.maxFailureTime;
        //Inputs.TotaldrillingHours;
        //Inputs.aveFailureTime) / Inputs.stdFailureTime;
		double Min_Delta_temp = 0;
		double Min_Delta_lat = 0;
		double Min_Delta_stsl = 0;
		double Max_Model_Weight = 1.0;
		double aveTemperature = Inputs.aveTemperature;//update stress_ave
		double aveLateral = Inputs.aveLateral;
		double aveStickSlip = Inputs.aveStickSlip;
	    
	    double axial_1 = GetCummulativeAxial();    
	    double JarringWeight = GetCummulativeJarring();
	    Inputs.Delta_axial_glb = 0;
	    if(axial_1 > 1.0)
	    {
	    	Inputs.Delta_axial_glb = 1;
	    }	    
	    double Delta_glb_sum = Inputs.Delta_temp_glb + Inputs.Delta_lat_glb + Inputs.Delta_stsl_glb + Inputs.Delta_jarr_glb + Inputs.Delta_axial_glb;
	    double pivotHours = GetPivotHours(Delta_glb_sum, Life_mean);
	    Max_Model_Weight =1.0;
	    Max_Model_Weight = GetMaxModMult(Life_mean,pivotHours, Max_Model_Weight);	    
	    	    
	    Delta_temp = 0;
	    Delta_lat = 0;
	    Delta_stsl = 0;
	    Delta_hrs = 0;	    
	   	
	    ///////////////////////////////////////////////////////////////////
	    if (Inputs.stdTemperature > 0)
	    {
	    	Delta_temp = (Inputs.temperature1 - aveTemperature) / Inputs.stdTemperature;//difference between current stress and ave stress
	        Min_Delta_temp = (0.1 - aveTemperature) / Inputs.stdTemperature;//difference between current stress and ave stress
	    }
	    else
	    {
	        Delta_temp = (Inputs.temperature1 - aveTemperature) / aveTemperature;
	        Min_Delta_temp = (0.1 - aveTemperature) / aveTemperature;
	    }
	    if (Delta_temp > 2)
	    {
	        Delta_temp = 2.0;
	    }
	    
	    //////////////////////////////////////////////////////////////////
	    
	    if (Inputs.stdLateral > 0)
	    {
	    	Delta_lat = (Inputs.lateral1 - aveLateral) / Inputs.stdLateral;
	        Min_Delta_lat = (0.1 - aveLateral) / Inputs.stdLateral;
	    }
	    else
	    {
	        Delta_lat = (Inputs.lateral1 - aveLateral) / aveLateral;
	        Min_Delta_lat = (0.1 -aveLateral) / aveLateral;
	    }	    
	    if (Delta_lat > 2)
	    {
	        Delta_lat = 2.0;
	    }
	    
	    ////////////////////////////////////////////////////////////////
	    if (Inputs.stdStickSlip > 0)
	    {
	        Delta_stsl = (Inputs.stickSlip1 - aveStickSlip) / Inputs.stdStickSlip;
	        Min_Delta_stsl = (0.1 - aveStickSlip) / Inputs.stdStickSlip;
	    }
	    else
	    {
	    	Delta_stsl = (Inputs.stickSlip1 - aveStickSlip) / aveStickSlip;
	        Min_Delta_stsl = (0.1 - aveStickSlip) /aveStickSlip;
	    }
	    if (Delta_stsl > 2)
	    {
	        Delta_stsl = 2.0;
	    }
	    
	    
	    
	    
	    ///////////////////////////////////////////////////////////////
	    Inputs.Delta_Hrs_glb = 0;
	    Delta_hrs = (Inputs.TotaldrillingHours - pivotHours);
	    if (Delta_hrs > 0)
	    {
	        Delta_hrs = 0.0;
	        Inputs.Delta_Hrs_glb = 1;
	    }
	    
	    double IncidentWeight = 1.0;	   
	    if (Inputs.failureStatus == true && Inputs.failureSeverity==1) 
	    {
	        IncidentWeight = 1.0+2*Max_Model_Weight;
	    }
	    else if (Inputs.failureStatus == true) 
	    {
	        IncidentWeight = 1.0+Max_Model_Weight;
	    }
	    else if(Inputs.Check_Incident_History == 1 && Inputs.ModelWeight_FoundTargetPart==1)
	    {
	    	IncidentWeight = 1.0 + 3*Max_Model_Weight / 4;
	    }
	    else if(Inputs.Check_Incident_History == 1 || Inputs.ModelWeight_FoundTargetPart==1)
	    {	    	
	        IncidentWeight = 1.0 + Max_Model_Weight / 2;
	    }    
	    
	    double temp_weight = GetModWeightVsVar(2.0, Min_Delta_temp, Delta_temp, 1.0, Max_Model_Weight);
	    double lat_weight = GetModWeightVsVar(2.0, Min_Delta_lat, Delta_lat, 1.0, Max_Model_Weight);
	    double stsl_weight = GetModWeightVsVar(2.0, Min_Delta_stsl, Delta_stsl, 1.0, Max_Model_Weight);
	    double axial_weight = GetModWeightVsVar(3.0, 1.0, axial_1, 1.0, Max_Model_Weight);
	    double hours_weight = GetModWeightVsVar(0.0, -pivotHours, Delta_hrs, 1.0, 2.0*Max_Model_Weight);
	   
	    
	    
	    double totweight = IncidentWeight*1.0*(IncidentWeight + temp_weight + lat_weight + stsl_weight + axial_weight + hours_weight + JarringWeight)/7.0;
	    double CalcMult_ScaleFactor_temp = 1.0 / totweight;
	    return CalcMult_ScaleFactor_temp;
	}
	
	public static double GetMaxModMult(double Life_mean,double aveval,double Max_Model_Weight)
	{
		Max_Model_Weight = 1.0;
		if (Life_mean > aveval)
	    {
	        Max_Model_Weight = Life_mean / aveval;
	    }
		
		return Max_Model_Weight;
	}
	public static double GetModWeightVsVar(double maxvar,double minvar,double Currvar,double minweight,double maxweight)
	{
		if(Currvar > maxvar)
		{
            Currvar = maxvar;
		}
    
	    if(Currvar < minvar)
	    {
	        Currvar = minvar;
	    }
	    
	    double m_slope = (maxweight - minweight) / (maxvar - minvar);
	    double c_intercept = minweight - m_slope * minvar;
	    
	    double GetModWeightVsVar = m_slope * Currvar + c_intercept;
	    return GetModWeightVsVar;
	}
	
	private static double GetPivotHours(double Delta_glb_sum, double Life_mean)
	{
		double PivotHours = 0.0;
		
		if(Delta_glb_sum>=3)
		{
			PivotHours = Inputs.aveFailureTime/2.0;		
		}
		else if(Delta_glb_sum>=2)
		{
			PivotHours = Inputs.aveFailureTime;
		}
		else if(Delta_glb_sum>=1)
		{
			PivotHours = (Inputs.aveFailureTime+Inputs.aveFailureHrsSus)/2.0;			
		}
		else if(Delta_glb_sum>0)
		{
			PivotHours = Inputs.aveFailureHrsSus; 		
		}
		else
		{
			PivotHours = (Inputs.aveFailureHrsSus + Inputs.maxFailureTime)/2.0;
		}		
		
		
		if(Inputs.TotaldrillingHours<100 && Delta_glb_sum<3)
		{
			PivotHours = (PivotHours+Inputs.aveFailureHrsSus)/2.0;
		}
		
		int Delta_temp_neg=-1,Delta_lat_neg=-1,Delta_stsl_neg=-1,sum_delta_neg=0;
		if(Delta_temp<0.0)
		{
			Delta_temp_neg = 1;
		}
		if(Delta_lat<0.0)
		{
			Delta_lat_neg = 1;
		}
		if(Delta_stsl<0.0)
		{
			Delta_stsl_neg = 1;
		}
		
		sum_delta_neg = Delta_temp_neg + Delta_lat_neg +Delta_stsl_neg;
		
		if(sum_delta_neg>2)
		{
			PivotHours = (PivotHours + Inputs.maxFailureTime+Inputs.maxOperatingTime)/3.0;
		}
		else if(sum_delta_neg>1)
		{
			PivotHours = (PivotHours+Inputs.maxFailureTime)/2.0;
		}
		else if(sum_delta_neg==1)
		{
			PivotHours = (4.0*PivotHours+Inputs.maxFailureTime)/5.0;
		}
		return PivotHours;
	}
	
	private static double ret_max(double a,double b)
	{
		double max_x = a;
		if(max_x<b)
		{
			max_x = b;
		}
		return max_x;
	}
}