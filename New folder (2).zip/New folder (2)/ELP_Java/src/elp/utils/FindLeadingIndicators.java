package elp.utils;

import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

import org.apache.commons.lang3.ArrayUtils;
import org.apache.poi.hssf.usermodel.HSSFSheet;
import org.apache.poi.hssf.usermodel.HSSFWorkbook;
import org.apache.poi.ss.usermodel.Cell;
import org.w3c.dom.Node;

/*import jxl.Sheet;
import jxl.Workbook;
import jxl.read.biff.BiffException;*/
public class FindLeadingIndicators{
	public static String[][] cell ;
	public static String[][] keyword_indicator_specific = new String[550][3];	
	public static String[] failure_indicator_specific = new String[550];
	public static String[][] Part_Number_flag_specific = new String[550][30];
	public static double SeperationLengthSpecific[] = new double[550];
	public static double SeperationLengthGeneric[] = new double[550];
	public static String[][] keyword_indicator_generic = new String[550][3];
	public static String[] failure_indicator_generic = new String[550];
	public static int TotNumFields_Specific = 0;
	public static int TotNumFields_Generic = 0;
	public static int PN_ListSize = 0;
	public static String[] PN_GlobalList = new String[550];
	public static int PosTempBCPM = -1;
    public static int PosTempOnTrak = -1;
    public static int PosTempASS = -1;
    public static String[] LeadingIndicators = {"bad","constant","dead","erro","fail","fault","flag","flat","froze","intermit","issue",
    	"lock","lost","malfunc","never","not","problem","quit","stop","unable","weird","wrong","zero"};
    public static String GlobalGenericList;
	
	private static void Initialize()
	{
		int i = 0;
		int j = 0;
		
		for(i = 0;i<550;i++)
		{
			for(j = 0;j<3;j++)
			{
				keyword_indicator_specific[i][j] = "";
				keyword_indicator_generic[i][j]="";
			}
			
			failure_indicator_specific[i] = "";
			SeperationLengthSpecific[i] = 0;
			SeperationLengthGeneric[i] = 0;			
			failure_indicator_generic[i] = "";
			PN_GlobalList[i] = "";
			
			for(j = 0;j<30;j++)
			{
				Part_Number_flag_specific[i][j] = "";
			}		
		}			
		
		PN_ListSize = 0;
		TotNumFields_Specific = 0;
		TotNumFields_Generic = 0;       
		GlobalGenericList = "";
	}
	

	public FindLeadingIndicators() throws IOException{
		String modelFile = new String();		
		
		double temp2 = 0.0;
		String temp1 = new String();
		modelFile = System.getProperty("user.dir")+"\\Random_input.xls";
			
		HSSFSheet sheet;
        FileInputStream inputFile = new FileInputStream(new File(modelFile));
        HSSFWorkbook workbook = new HSSFWorkbook(inputFile);        
        sheet = workbook.getSheet("Specific");
        
        Initialize();
        
        TotNumFields_Specific = sheet.getLastRowNum();
        int j =1;
        int i = 1;
        if (sheet != null)
        {
        	for (i = 0; i < sheet.getLastRowNum(); i++){			
        		for (j = 0; j < 3; j++){		
        			try
        			{				
        				keyword_indicator_specific[i][j] = sheet.getRow(i).getCell(j).getStringCellValue().toLowerCase().trim();        		
        			}
        			catch(Exception e)
        			{
        				keyword_indicator_specific[i][j] = "";
        			}
        		}       		
        		
        		try 
        		{				
        			j=6;
        			sheet.getRow(i).getCell(j).setCellType(1);
        			failure_indicator_specific[i] = sheet.getRow(i).getCell(j).getStringCellValue().toLowerCase().trim();
        		}
        		catch(Exception e)
        		{
        			failure_indicator_specific[i] = "";
        		}
        		
        		try 
        		{				
        			j=7;
        			SeperationLengthSpecific[i] = sheet.getRow(i).getCell(j).getNumericCellValue();
        		}
        		catch(Exception e)
        		{
        			SeperationLengthSpecific[i] = 10000;
        		}
        		
        		/////////////PN List
        		for (j = 8; j < 30; j++){	
        			try
        			{				
        				sheet.getRow(i).getCell(j).setCellType(1);
        				//temp2 = sheet.getRow(i).getCell(j).getCellValue();
        				Part_Number_flag_specific[i][j-8] = sheet.getRow(i).getCell(j).getStringCellValue().toLowerCase().trim();
        			}
        			catch(Exception e)
        			{
        				Part_Number_flag_specific[i][j-8] = "";
        			}
        		}       		
        		/////////////PN List       		
        	}
        }
		
        sheet = workbook.getSheet("Generic");
        TotNumFields_Generic = sheet.getLastRowNum();
        
        if (sheet != null)
        {
        	for (i = 0; i < sheet.getLastRowNum(); i++)
        	{				
        		for (j = 0; j < 2; j++){		
        			try
        			{				
        				keyword_indicator_generic[i][j] = sheet.getRow(i).getCell(j).getStringCellValue().toLowerCase().trim();    		
        			}
        			catch(Exception e)
        			{
        				keyword_indicator_generic[i][j] = "";
        			}
        		}       
			
        		try
        		{				
        			j=6;
        			sheet.getRow(i).getCell(j).setCellType(1);
        			failure_indicator_generic[i] = sheet.getRow(i).getCell(j).getStringCellValue().toLowerCase().trim();
        		}
        		catch(Exception e)
        		{
        			failure_indicator_generic[i] = "";
        		}
    		
        		try 
        		{				
        			j=7;
        			SeperationLengthGeneric[i] = sheet.getRow(i).getCell(j).getNumericCellValue();
        		}
        		catch(Exception e)
        		{
        			SeperationLengthGeneric[i] = 10000;
        		}		
			}
    	}	
        i = 1;
        String IncidentRemark = "";
        String RunRemark = "";
        if(Inputs.IncidentDescription_!=null)
        {
        	IncidentRemark = Inputs.IncidentDescription_.toLowerCase().trim();
        }
        if(Inputs.RunDescription_!=null)
        {
        	RunRemark = Inputs.RunDescription_.toLowerCase().trim();
        }
        
        String GenericListRunRemark = GenerateGenericList(RunRemark);
        String GenericListIncident = GenerateGenericList(IncidentRemark);
        
        GlobalGenericList = GenericListRunRemark.concat(GenericListIncident);
        
        GenerateSpecificList(RunRemark);
        GenerateSpecificList(IncidentRemark);
        
        temp1 = Inputs.Maint_Level_PN;        
        String temp3 = Inputs.SN;
        Inputs.Check_Incident_History = 0;
        if(IncidentRemark.length()>10) 
        {
        	Inputs.Check_Incident_History = 1;
        }
    }
	
	private static void GenerateSpecificList(String RunRemark) 
	{
		int i = 0;
		double DecisionVal=0;		
		
		String tempStr = new String();
		
		for (i = 0; i < TotNumFields_Specific; i++)
    	{		    
			//System.out.println(i);			
			DecisionVal = RunSpecificIndicatorPos_Multiple(i, RunRemark);
			//DecisionVal = SearchRunRemarkForSpecificFlag(i, RunRemark);			
    	}	
	}
	
	
	private static String GenerateGenericList(String RunRemark) 
	{
		int i = 0;
		double DecisionVal=0;
		
		PosTempBCPM = -1;
	    PosTempOnTrak = -1;
	    PosTempASS = -1;
		
		String tempStr = new String();
		
		for (i = 0; i < TotNumFields_Generic; i++)
    	{		    
			//System.out.println(i);
			 
			 
			//DecisionVal = SearchRunRemarkForSub(i, RunRemark, PosTempBCPM, PosTempOnTrak, PosTempASS);
			DecisionVal = RunGenericIndicatorPos_Multiple(i, RunRemark);
			if (DecisionVal <= 0 && (PosTempBCPM > -1 || PosTempOnTrak > -1 || PosTempASS > -1))
			{
				if (PosTempBCPM > 0)
				{
					tempStr = tempStr.concat("_BCPM");
				}
			    if (PosTempOnTrak > 0)
			    {
			    	tempStr = tempStr.concat("_OnTrak");
			    }
			    if (PosTempASS > 0) 
			    {
			    	tempStr = tempStr.concat("_ASS");
			    }
			    break;
			}
    	}
		return tempStr;
	}
	
	
	private static double SearchRunRemarkForSub(int FlagIndex, String RunRemark, int GlobalIndicatorPos)
	{
		String[] SubFlagOnTrak = new String[6];
		String[] SubFlagASS = new String[4];
		String SubFlagBCPM = "bcpm";
		String Temp;
		String TempIndicatorFlag;
		int Count = 0;
		int SearchFlagCount = 0;
		int PosTemp;
		int StartPos=0;
		int IndicatorFlagPos;
		double ValSum = 100000;
		double DecisionVal = 1;
		
		SubFlagOnTrak[0] = "ontrak";
		SubFlagOnTrak[1] = "osa";
		SubFlagOnTrak[2] = "otk";
		SubFlagOnTrak[3] = "asn";
		SubFlagOnTrak[4] = "azi";
		SubFlagOnTrak[5] = "aoa";
		SubFlagASS[0] = "ass";
		SubFlagASS[1] = "asu";
		SubFlagASS[2] = "steering head";
		SubFlagASS[3] = "steering system";
		RunRemark = RunRemark.toLowerCase();
		if(RunRemark.length() > 0)
		{
			for (int j = 0; j < 3; j++)
	    	{
				Temp = keyword_indicator_generic[FlagIndex][j];
				if (Temp.length() > 0) 
				{
					SearchFlagCount = SearchFlagCount + 1;
					PosTemp = RunRemark.indexOf(Temp,GlobalIndicatorPos);
					if (PosTemp >-1 && Count < 1)
					{
						ValSum = 0;
					}
                    
                    StartPos = 1;
                    if (PosTemp - 50 > 0)
                    {
                    	StartPos = PosTemp - 50;
                    }
                
                    TempIndicatorFlag = failure_indicator_generic[FlagIndex];
                    if (TempIndicatorFlag.length()> 0)
                    {
                    	//IndicatorFlagPos = InStr(StartPos, RunRemark.indexOf(IndicatorFlag(FlagIndex))
                    	IndicatorFlagPos = RunRemark.indexOf(TempIndicatorFlag, StartPos);
                    }
                    else
                    {
                    	IndicatorFlagPos = 0;
                    }
                
                    if (PosTemp > -1)
                    {
                    	Count = Count + 1;
                    	if (IndicatorFlagPos < PosTemp)
                    	{
                        	ValSum = ValSum + Math.abs(IndicatorFlagPos + TempIndicatorFlag.length() - PosTemp);
                    	}
                        else
                        {
                        	ValSum = ValSum + Math.abs(PosTemp + Temp.length() - IndicatorFlagPos);
                    	}
                    }//
				}//
	    	}//FOR
			
			if (Count > 0) 
			{
				ValSum = ValSum / Count;
			}
			
			DecisionVal = ValSum - SeperationLengthGeneric[FlagIndex];
			
			PosTempBCPM = 0;
			PosTempOnTrak = 0;
			PosTempASS = 0;
			if (DecisionVal <= 0 && SearchFlagCount == Count) 
			{
				//PosTempBCPM = InStr(LCase(RunRemark), LCase(Trim(SubFlagBCPM)))
				PosTempBCPM = RunRemark.indexOf(SubFlagBCPM);
				for (int i = 0; i < 5; i++)
				{
					PosTempOnTrak = PosTempOnTrak + RunRemark.indexOf(SubFlagOnTrak[i]);
				}			            
				for (int i = 0; i < 4; i++)
				{
			    	PosTempASS = PosTempASS + RunRemark.indexOf(SubFlagASS[i]);
				}
				
			}
		}//if
		return DecisionVal;
	}  
	
	private static double SearchRunRemarkForSpecificFlag(int FlagIndex, String RunRemark, int GlobalIndicatorPos)
	{
		String Temp;
		String TempIndicatorFlag;
		int Count = 0;
		int SearchFlagCount = 0;
		int PosTemp;
		int StartPos=0;
		int IndicatorFlagPos;
		double ValSum = 100000;
		double DecisionVal = 0;
		int retflag = 0;
		
		RunRemark = RunRemark.toLowerCase();
		if(RunRemark.length() > 0)
		{
			for (int j = 0; j < 3; j++)
	    	{
				Temp = keyword_indicator_specific[FlagIndex][j];
				if (Temp.length() > 0) 
				{
					SearchFlagCount = SearchFlagCount + 1;
					PosTemp = RunRemark.indexOf(Temp,GlobalIndicatorPos);
					if (PosTemp >-1 && Count < 1)
					{
						ValSum = 0;
					}
                    
                    StartPos = 1;
                    if (PosTemp - 50 > 0)
                    {
                    	StartPos = PosTemp - 50;
                    }
                
                    TempIndicatorFlag = failure_indicator_specific[FlagIndex];
                    if (TempIndicatorFlag.length()> 0)
                    {
                    	//IndicatorFlagPos = InStr(StartPos, RunRemark.indexOf(IndicatorFlag(FlagIndex))
                    	IndicatorFlagPos = RunRemark.indexOf(TempIndicatorFlag, StartPos);
                    }
                    else
                    {
                    	IndicatorFlagPos = 0;
                    }
                
                    if (PosTemp > 0)
                    {
                    	Count = Count + 1;
                    	if (IndicatorFlagPos < PosTemp)
                    	{
                        	ValSum = ValSum + Math.abs(IndicatorFlagPos + TempIndicatorFlag.length() - PosTemp);
                    	}
                        else
                        {
                        	ValSum = ValSum + Math.abs(PosTemp + Temp.length() - IndicatorFlagPos);
                    	}
                    }//
				}//
	    	}//FOR
			
			if (Count > 0) 
			{
				ValSum = ValSum / Count;
			}
			
			DecisionVal = ValSum - SeperationLengthSpecific[FlagIndex];
			
			if (DecisionVal <= 0 && SearchFlagCount == Count) 
			{
				retflag = AddtoList(FlagIndex);	
				retflag = 1;
			}
		}//if		
		return retflag;		
	}  
	
	
	private static int AddtoList(int FlagIndex)
	{
		int k = 0;
		int foundFlag = 0;
		int i = 0;		
		
		while (Part_Number_flag_specific[FlagIndex][k].length() > 0)
		{
			foundFlag = 0;
			for (i = 0;i<PN_ListSize;i++)
			{				
				if (PN_GlobalList[i].indexOf(Part_Number_flag_specific[FlagIndex][k].toLowerCase()) > -1)
				{
					foundFlag = 1;
					break;
				}
			}
            if (foundFlag < 1)
            {
            	PN_GlobalList[PN_ListSize] = Part_Number_flag_specific[FlagIndex][k].toLowerCase().trim();
            	PN_ListSize = PN_ListSize + 1;
            }
            k = k + 1;
            //System.out.println("k is" + i);
		}
		return foundFlag;
	}
	
	//////////////////
	private static double RunSpecificIndicatorPos_Multiple(int FlagIndex,String RunRemark)
	{
		//Dan Change size of GloablIndicatorPos from 100 t0 200 2016/08/11
		int GlobalIndicatorPos[] = new int[200];
		int NumGlobalIndicatorPos=0;
		double DecisionVal = 1;		
		int i=0;
		
		//Dan changed 2016/08/11 from i<100 to i<200
		for (i = 0; i<200;i++)
		{
			GlobalIndicatorPos[i] = 0;
		}
		
		int Flag = 1;		
		int StartPosGlobal = 1;
		i = 0;
		
		while (Flag==1 && failure_indicator_specific[FlagIndex].length() > 0)
		{
			//GlobalIndicatorPos[i] = InStr(StartPosGlobal, RunRemark, IndicatorFlag(FlagIndex))			
			GlobalIndicatorPos[i] = RunRemark.indexOf(failure_indicator_specific[FlagIndex],StartPosGlobal);
			StartPosGlobal = GlobalIndicatorPos[i] + 10;
			if (GlobalIndicatorPos[i] <= 0)
			{
				Flag = 0;
				break;
			}
			i = i + 1;
		}
		NumGlobalIndicatorPos = i;
		
		for(i = 0;i<NumGlobalIndicatorPos;i++)
		{
		    GlobalIndicatorPos[i] = GlobalIndicatorPos[i] - 50;
		}		 
		 
		for (i = 0;i<NumGlobalIndicatorPos;i++)
		{
		    if (GlobalIndicatorPos[i] <= 0)
			{
			    GlobalIndicatorPos[i] = 1;
			}
			DecisionVal = SearchRunRemarkForSpecificFlag(FlagIndex, RunRemark, GlobalIndicatorPos[i]);
			if (DecisionVal <= 0)
			{
			     break;
			}			 
		}
		return DecisionVal;	
	}	
	/////////////////
	private static double RunGenericIndicatorPos_Multiple(int FlagIndex,String RunRemark)
	{
		//Dan Change from GlobalIndicatorPos[]=[100] to [200]
		int GlobalIndicatorPos[] = new int[200];
		int NumGlobalIndicatorPos=0;
		double DecisionVal = 1;
		int i=0;
				
		for (i = 0; i<200;i++)
		{
			GlobalIndicatorPos[i] = 0;
		}
		
		int Flag = 1;		
		int StartPosGlobal = 1;
		i = 0;
		while (Flag==1 && failure_indicator_generic[FlagIndex].length() > 0)
		{
			//GlobalIndicatorPos[i] = InStr(StartPosGlobal, RunRemark, IndicatorFlag(FlagIndex))			
			GlobalIndicatorPos[i] = RunRemark.indexOf(failure_indicator_generic[FlagIndex],StartPosGlobal);
			StartPosGlobal = GlobalIndicatorPos[i] + 10;
			if (GlobalIndicatorPos[i] <= 0)
			{
				Flag = 0;
				break;
			}
			i = i + 1;
		}
		NumGlobalIndicatorPos = i;
		
		 for(i = 0;i<NumGlobalIndicatorPos;i++)
		 {
			 GlobalIndicatorPos[i] = GlobalIndicatorPos[i] - 50;
		 }		 
		 
		 for (i = 0;i<NumGlobalIndicatorPos;i++)
		 {
			 if (GlobalIndicatorPos[i] <= 0)
			 {
				 GlobalIndicatorPos[i] = 1;
			 }
			 DecisionVal = SearchRunRemarkForSub(FlagIndex, RunRemark,GlobalIndicatorPos[i]);
			 if (DecisionVal <= 0)
			 {
				 break;
			 }			 
		 }
		 return DecisionVal;
	}	
	
	////////////////
	
}
