package elp;
import java.io.IOException;

import org.apache.commons.math3.distribution.LogNormalDistribution;

import elp.utils.Inputs;
import elp.utils.ModelValues;
import elp.utils.ModelWeightUtil;
import elp.utils.RevisionValues;
import elp.utils.runSinglePartUtil;

public class getLifeSingleRevision extends Inputs{
/**
 *  Class where we calculate the Life Meain, Yeta, PDF, CDF, Var_Distribution values at 25%, 50%, 75% values
Inputs are directly read from Ascii file(Txt) through a browser UI Class written in fileBrowser (which presently also contains the main method)
The input variables are written in the below fashion to the file
VARIABLE_NAME = VALUE
*/
    
   	private static double[] cofLogGamma = {76.18009172947146,-86.50532032941677,
		24.01409824083091,-1.231739572450155,0.1208650973866179e-2,-0.5395239384953e-5};
	static double temperature1;
	static double stickSlip1;
	static double lateral1;
	static double DistanceDrilledSeverity1;
	static double temperatureStickSlip1;
	static double temperatureLateral1;
	static double stickSlipLateral1;
	
	static double varDistribution[]={0,0,0};
	static double yeta;
	static double lifeMean;
	static double cumulativeDistributionFunction;
	static double probabilityDistributionFunction;
	static double ConsumedCirc_Hours =0;
	static double[] estimatesInp ;
	boolean consumedCircHoursCalculation = false;
	
	public static double[] MinOperVarBound = {0,0,0,0};
	public static double[] MaxOperVarBound = {0,0,0,0};
		    
	public getLifeSingleRevision(int cnt, double proportionDrill) throws IOException{
	/** Constructor for the Single Revision Class
	*/
		
		double LifeMean_Ln_MainEffects, LifeMean_Ln_Interactions, LifeMean_Ln;
		double betaMean;
		double drillHours = 0;
		double varDistribution_50=0.0;
		LogNormalDistribution logNormal;
		
    	/*temperature1 = Inputs.temperature1;
    	stickSlip1 = Inputs.stickSlip1;
    	lateral1 = Inputs.lateral1;
    	DistanceDrilledSeverity1 = Inputs.DistanceDrilledSeverity1;
    	temperatureStickSlip1 = Inputs.temperatureStickSlip1;
    	temperatureLateral1 = Inputs.temperatureLateral1;
    	stickSlipLateral1 = Inputs.stickSlipLateral1;
    	*/
		estimatesInp = Inputs.estimateMean[cnt];
		if (ModelWeight.MCSRun){
	     	runSinglePartUtil.GenerateMCSModel(cnt);//quantile generated based random numbers
			estimatesInp = runSinglePartUtil.R1_Rand; 
		}
		//get consumed circulating hours and calculate lifemean, pf
		ConsumedCirc_Hours = getConsumedCircHours(estimateCirc, proportionDrill, cnt);
		
		/*intercept = estimatesInp[0];
		temperature = estimatesInp[1];
		stickSlip = estimatesInp[2];
		lateral = estimatesInp[3];
		temperatureStickSlip = estimatesInp[4];
		temperatureLateral = estimatesInp[5];
		distanceDrilledSeverity = estimatesInp[6];*/
		betaMean = estimatesInp[7]; //bata value
		//stickSlipLateral = estimatesInp[8];
		
		GetNormalizedOpervar_Check(cnt); //check boudary of operating parameters
		
		LifeMean_Ln_MainEffects = estimatesInp[0] + estimatesInp[1] * temperature1 + estimatesInp[2] * stickSlip1
				 + estimatesInp[3] * lateral1 + estimatesInp[6] * DistanceDrilledSeverity1; 
	
		LifeMean_Ln_Interactions = (estimatesInp[4] * temperatureStickSlip1) + 
				(estimatesInp[5] * temperatureLateral1) + (estimatesInp[8] * stickSlipLateral1); 
		
		LifeMean_Ln = LifeMean_Ln_MainEffects + LifeMean_Ln_Interactions;

		LifeMean_Ln = CheckLifeMean(LifeMean_Ln, betaMean, distributionType.get(RevisionValues.est[cnt]));
		
		if (Inputs.modelUpdate) {
			drillHours = drillHrsForModelUpdate;
		}else{
			drillHours = Inputs.TotaldrillingHours;
		}
		
		if (ModelWeight.repairFlag) 
		{
			ModelMultFactorForRevision = 1;
		}
		else
		{
			ModelMultFactorForRevision = ModelWeight.multFactor;
		}
		
		if (distributionType.get(RevisionValues.est[cnt]).toLowerCase().equals("weibull")) 
		{//Weibull Distribution
			if (Math.exp(LifeMean_Ln) > ConsumedCirc_Hours){
				yeta = ModelMultFactorForRevision * (Math.exp(LifeMean_Ln) - ConsumedCirc_Hours);//update Yeta using factor for revision and comsumed CircHrs
			}else{
	    		yeta = ModelMultFactorForRevision * Math.exp(LifeMean_Ln);
	    	}
			lifeMean = yeta * Math.exp(lnGamma(1 + (1 / betaMean)));
		    cumulativeDistributionFunction = 1 - Math.exp(-Math.pow((drillHours / yeta) , betaMean));
    		
		    probabilityDistributionFunction = (betaMean / yeta) * 
		    		Math.pow((drillHours / yeta) , (betaMean - 1)) * 
		    		Math.exp(-Math.pow((drillHours / yeta) , betaMean));
		    
		    //D_Life_Dbeta = lifeMean * psi(getVal(inputs.get("BETA_MEAN"))) * (-1 / Math.pow(getVal(inputs.get("BETA_MEAN")) , 2)); 
		    //get confidence bound (quantile)
		    varDistribution[0] = yeta * (Math.pow (-Math.log(1 - 0.75) , (1 / betaMean)));
		    varDistribution[1] = yeta * (Math.pow (-Math.log(1 - 0.25) , (1 / betaMean)));
		    varDistribution[2] = yeta * (Math.pow (-Math.log(1 - 0.95) , (1 / betaMean)));
			////////kaleami 06/18/2015///////////////////////////////////
		    varDistribution_50 = yeta * (Math.pow (-Math.log(1 - 0.50) , (1 / betaMean)));
		    ////////kaleami 06/18/2015///////////////////////////////////
		}
		else
		{//non Weibull Distribution (presently lognormal)

        	yeta = (LifeMean_Ln + 0.5 * Math.pow(betaMean ,2));
			if (ModelMultFactorForRevision * Math.exp(yeta) - ConsumedCirc_Hours > 0) 
			{
            	lifeMean = ModelMultFactorForRevision *  Math.exp(yeta) - ConsumedCirc_Hours;
        	}else{
            	lifeMean = ModelMultFactorForRevision *  Math.exp(yeta);
        	}
        	
			//D_Life_Dbeta = yeta * getVal(inputs.get("beta_mean"));
			yeta = Math.log(lifeMean);
	        
	        logNormal = new LogNormalDistribution(yeta, betaMean);
	        
	        cumulativeDistributionFunction  = logNormal.cumulativeProbability(drillHours);
	        try{
	        	probabilityDistributionFunction = logNormal.density(drillHours);
	        }catch(Throwable e)
	        {
	        	System.out.println("Throwable during PDF: "+ e);
			}
	        varDistribution[0] = logNormal.inverseCumulativeProbability(0.75);
	        varDistribution[1] = logNormal.inverseCumulativeProbability(0.25);
	        varDistribution[2] = logNormal.inverseCumulativeProbability(0.95);
	        ////////kaleami 06/18/2015///////////////////////////////////
			varDistribution_50 = logNormal.inverseCumulativeProbability(0.50);
			////////kaleami 06/18/2015///////////////////////////////////
		}
		
		/////////////////////////kaleami 06/08/2015///////////////////////////////
		if (lifeMean < varDistribution[1] || lifeMean > varDistribution[0])
		{
			lifeMean = varDistribution_50;
		}
		
		double ratio_25 = varDistribution[1] / lifeMean;
		double ratio_95 = varDistribution[0] / lifeMean;
		
		if (lifeMean >= Inputs.maxOperatingTime)
		{
			lifeMean = Inputs.maxOperatingTime;
			varDistribution[1] = ratio_25 * lifeMean;
			varDistribution[0] = ratio_95 * lifeMean;
		}
		
		yeta = yeta * lifeMultFactor;
		lifeMean = lifeMean * lifeMultFactor;	
	}
	
    private void GetNormalizedOpervar_Check(int cnt) {

    	temperature1 = Inputs.temperature1;
    	stickSlip1 = Inputs.stickSlip1;
    	lateral1 = Inputs.lateral1;
    	DistanceDrilledSeverity1 = Inputs.DistanceDrilledSeverity1;
    	temperatureStickSlip1 = Inputs.temperatureStickSlip1;
    	temperatureLateral1 = Inputs.temperatureLateral1;
    	stickSlipLateral1 = Inputs.stickSlipLateral1;
    	
    	boolean calculatedCircHours = false;
    	int i = 0;
    	if (ModelWeight.repairFlag){
    		if (consumedCircHoursCalculation) calculatedCircHours = true; 
    		else{
    			if (cnt == 0){
    				i = 2;// for Repair
    			}else if (cnt == 1) i = 3;// Repair_Sus
    		}
    	}else{
    		if (consumedCircHoursCalculation){
    			if (cnt >= 0) calculatedCircHours = true;
    			else if (cnt == -1){
    				cnt = 3;
    				i = 0;
    			}
    			else if (cnt == -2){
    				cnt = 5;
    				i = 0;
    			}
    		}else {
    			if (cnt < 2) {
		    		i = 1;//_F
		    	}else if(cnt < 6) i = 0;//_FS
    		}
    	}
    	
    	//ModelWeight.lastCnt = cnt;
    	
    	if (!calculatedCircHours){
    		MinOperVarBound = Inputs.MinOperVarBound[i];
    		MaxOperVarBound = Inputs.MaxOperVarBound[i];
    	}

	    if (temperature1 < MinOperVarBound[0]) temperature1 = MinOperVarBound[0];
		if (temperature1 > MaxOperVarBound[0]) temperature1 = MaxOperVarBound[0];
    	
		if (stickSlip1 < MinOperVarBound[1]) stickSlip1 = MinOperVarBound[1];
		if (stickSlip1 > MaxOperVarBound[1]) stickSlip1 = MaxOperVarBound[1];
    	
		if (lateral1 < MinOperVarBound[2]) lateral1 = MinOperVarBound[2];
		if (lateral1 > MaxOperVarBound[2]) lateral1 = MaxOperVarBound[2];
    	
		if (DistanceDrilledSeverity1 < MinOperVarBound[3]) DistanceDrilledSeverity1 = MinOperVarBound[3];
		if (DistanceDrilledSeverity1 > MaxOperVarBound[3]) DistanceDrilledSeverity1 = MaxOperVarBound[3];
    	
    	if (Math.abs(temperatureStickSlip1 - (temperature1 * stickSlip1))> 0.00001) 
    		temperatureStickSlip1 = temperature1 * stickSlip1;
    	
    	if (Math.abs(temperatureLateral1 - (temperature1 * lateral1))> 0.00001) 
    		temperatureLateral1 = temperature1 * lateral1;
    	
    	if (Math.abs(stickSlipLateral1 - (stickSlip1 * lateral1))> 0.00001) 
    		stickSlipLateral1 = stickSlip1 * lateral1;
    	
	}

	protected static void checkRange(double x, double low, double high) throws Throwable {
        if(x<low )
			//throw new OutOfRangeException("The argument of the distribution method should be > "+low+".");
			x=low;
		if(x>high)
			//throw new OutOfRangeException("The argument of the distribution method should be < "+high+".");
			x=high;
	}
	
	public static double psi(double beta_mean ){ 
	    double x = 1 + (1 / beta_mean);
	    return( 1.442 * Math.log(x) - 0.5546);
	}
	
	public static double lnGamma(double x){
	/**
	* Returns natural logarithm of gamma function. 
	* @param x the value
	*/
		double y,tmp,ser;
		int j;
		
		y=x;
		tmp=x+5.5;
		tmp -= (x+0.5)*Math.log(tmp);
		ser=1.000000000190015;
		for (j=0;j<=5;j++) {
			ser += cofLogGamma[j]/++y;
		}
		return -tmp+Math.log(2.5066282746310005*ser/x);
	}
	
	
	public double getConsumedCircHours(double[] estimateCirc, double proportionDrill, int cnt) {
		/* Input array is a array of values(coeff) in the following order
		estimateCirc[0] = Intercept
		estimateCirc[1] = Temperature
		estimateCirc[2] = StickSlip
		estimateCirc[3] = Lateral
		estimateCirc[4] = Temperature*StickSlip
		estimateCirc[5] = Temperature*Lateral
		estimateCirc[6] = DistanceDrilledSeverity
		estimateCirc[7] = Beta
		estimateCirc[8] = Lateral*StickSlip
*/
		LogNormalDistribution logNormal;
		double LifeMean_Ln_MainEffects, LifeMean_Ln_Interactions; 
		double LifeMean_Ln ;
		double yeta;
		double Pf,Circ_Drill_Diff;
		
		double betaMean = estimateCirc[7];
		consumedCircHoursCalculation = true;
		//check whether the bound of predictors are satisfied or not
		GetNormalizedOpervar_Check(ModelWeight.lastCnt);
		consumedCircHoursCalculation = false;
		
		//calculate ln yeta
		LifeMean_Ln_MainEffects = estimateCirc[0] + estimateCirc[1] * temperature1 + estimateCirc[2] * stickSlip1 + 
				estimateCirc[3] * lateral1 + estimateCirc[6] * DistanceDrilledSeverity1;
		
		LifeMean_Ln_Interactions = estimateCirc[4] * temperatureStickSlip1 + 
				estimateCirc[5] * temperatureLateral1 + estimateCirc[8] * stickSlipLateral1;
		
		LifeMean_Ln = LifeMean_Ln_MainEffects + LifeMean_Ln_Interactions;
		
		String distributionType = new String();
    	
    	// changes to incorporate no updated bounds in VB code for CalculateCircHours() function 
		if (ModelWeight.MCSRun)
			ModelWeight.lastCnt = cnt;
		if (ModelWeight.repairFlag){
			if (cnt == 1) distributionType = Inputs.distributionType.get(RevisionValues.est[ModelWeight.lastCnt]);
			else distributionType= Inputs.distributionType.get("Estimates_Repair");
        }else{
        	if (ModelWeight.startCalculation ){
        		distributionType = ModelValues.distributionType;
        		ModelWeight.startCalculation = false;
        	}else{
	    		try{
	    			distributionType = Inputs.distributionType.get(RevisionValues.est[ModelWeight.lastCnt]);
	    		}catch(Exception e){
	    			distributionType = Inputs.distributionType.get(RevisionValues.est[3]);
	    		}
        	}
        }
		
		LifeMean_Ln = CheckLifeMean(LifeMean_Ln, betaMean, distributionType);
		ModelWeight.lastCnt = cnt;
		
		Circ_Drill_Diff = proportionDrill * (circHours - TotaldrillingHours);
		
		if (Inputs.distributionType.get("Estimates_Circ").toLowerCase().equals("weibull")) {
		    yeta = Math.exp(LifeMean_Ln);
		    //lifeMean = yeta * Math.exp(lnGamma(1 + (1 / betaMean ) ) );
		    Pf = 1 - Math.exp(-Math.pow((Circ_Drill_Diff / yeta) , betaMean));
		}else{
		    yeta = LifeMean_Ln + 0.5 * Math.pow(betaMean, 2);
		    //lifeMean = Math.exp(yeta);
		    logNormal = new LogNormalDistribution( yeta, betaMean);
		    
		    Pf = logNormal.cumulativeProbability(Circ_Drill_Diff);
		}
		
		if (circDrillRelation.trim().toUpperCase().equals("LINEAR")) {
		    return( Pf * (p1 * Circ_Drill_Diff + p2) / 2);
		}else{
			return(Pf * (p2 * Math.pow(Circ_Drill_Diff , p1) ) / 2);
		}
	}

	
	public static double CheckLifeMean(double lifemeanln, double beta_mean, String distributionType)
	{    
	
		double yeta, lifemean;
		if (lifemeanln < 0.01) {
	        lifemeanln = 0.01;
	    }
	    
		if (distributionType.toLowerCase().equals("weibull")){
	        yeta = Math.exp(lifemeanln);
	        lifemean = yeta * Math.exp(lnGamma(1 + (1 / beta_mean)));
		}else{
	        yeta = lifemeanln + 0.5 * beta_mean * beta_mean;
	        lifemean = Math.exp(yeta);
		}
	    
	    if (lifemean < Inputs.minOperatingTime) {
	        lifemean = Inputs.minOperatingTime;
	    }
	    if (lifemean > Inputs.maxOperatingTime) {
	        lifemean = Inputs.maxOperatingTime;
		}
	    
		if (distributionType.toLowerCase().equals("weibull")){
	        yeta = lifemean / (Math.exp(lnGamma(1 + (1 / beta_mean))));
	        return(Math.log(yeta));
	    }else{
	        yeta = Math.log(lifemean);
	        return(yeta - (+ 0.5 * Math.pow(beta_mean, 2)));
	    }
	}
}
