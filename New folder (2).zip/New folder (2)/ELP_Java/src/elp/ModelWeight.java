package elp;

import java.io.*;

import elp.utils.*;

public class ModelWeight extends ModelWeightUtil {

	public static double meanLifeUnRepairedParts;
	public static int lastCnt = -1; 
	protected static double repairEnhancementFactor = 0.25;
	static double cumulativeTemp;
	static double cumulativeStSlip;
	static double cumulativeLat;
	double cumulativeDistDrilledSeverity;
	static boolean MCSRun = false;
	public static int earlierEstimate = 0;
	public static boolean repairFlag = false;
	public static boolean startCalculation;

	public ModelWeight() throws IOException{
		
		double userFindScaleFactor;
		int KnobsIterate = 0;
		int UpdateIndices[] = {0,0,0,0,0,0,0};
		multFactor = 1;
		meanLifeUnRepairedParts = 0;
		new ModelValues(Inputs.PN);
		new ReadCummulativeDamageBucket();
		CalculateInputs.Populatefailure_Suspension();
		
		scaleFactorMultComparePfLife = comparePfAverageLife();
		userFindScaleFactor = findUserScalefactor();
		
		
		InitializeModelMultFactor(multFactor);//get base line probability of failure of each model
		lastCnt = -1;
		startCalculation = true;		
		getLifeSingleRevision.ConsumedCirc_Hours =0;
		MCSRun = false;
		double[][] InputArr = new double[6][2];
			
		//get the life_mean, std, pf for all 6 models
		for(int cnt= 0; cnt<6; cnt++){
			try {
					YetaPfLifeModel(true,false,cnt);
			        InputArr[cnt][0] = lifeMeanSum;
			        InputArr[cnt][1] = cnt;
				} catch (IOException e) {
					e.printStackTrace();
				}
		}
		
		GetInitialModelWeightTemp(PM, InputArr, decisionValue, Inputs.failureStatus);
					
		//int CountValidData_Update = FindIndicesForUpdate(numDataSets, loopIndex, UpdateIndices);
		int CountValidData_Update = 1;
		if (Inputs.numDataSets > 0) {
			for (int i_count = CountValidData_Update;  i_count  <= CountValidData_Update; i_count++){
				int i = UpdateIndices[i_count];
			    //use 75%of current drill hours and 25% of previous drill hour to update drillhrs
			    Inputs.drillHrsForModelUpdate = 0;
			    setDrillHrsForModelUpdate();
			    if (Check_Prev_And_This_OperVar()) {
			    	GetOriginalLat_Temp(i);
			        double PMSum = 0;//weight
					double[] localPdf= {0,0,0,0,0,0};
					MCSRun = false;
					for(int cnt= 0; cnt < 6; cnt++){
						try {
								YetaPfLifeModel(true, true, cnt);
								localPdf[cnt] = probabilityDistributionFunctionSum;
							} catch (IOException e) {
								e.printStackTrace();
							}
						PMSum = PMSum + (PM[cnt] * probabilityDistributionFunctionSum);
					}
					for(int cnt = 0; cnt<6; cnt++){
						PM[cnt] = PM[cnt] * (1 + (localPdf[cnt] / PMSum)) / 2;
					}
			    }
			}
		}
			
		yetaPfLife();

		scaleProbability = normalDist.cumulativeProbability((Inputs.drillHrsForModelUpdate - Inputs.aveFailureTime) / Inputs.stdFailureTime);
		Prob_ScaleFactorMult_ComparePF_Life = normalDist.cumulativeProbability(decisionValue) ;
		Temo_Mult = 1 - Prob_ScaleFactorMult_ComparePF_Life;
		setMultFactor();
		multFactor = multFactor * userFindScaleFactor;
		startCalculation = true;
		lastCnt = -1;
	}
	
	public static void sort2DArray(double[][] inputArr, int cnt) {
		for (int i = 0; i < cnt; i++){
			for (int j = i + 1 ; j< cnt; j++){
		    	if (inputArr[i][0] > inputArr[j][0]) {
		        	double temp = inputArr[i][0];
		            inputArr[i][0] = inputArr[j][0];
		            inputArr[j][0] = temp;
		                
		            temp = inputArr[i][1];
		            inputArr[i][1] = inputArr[j][1];
		            inputArr[j][1] = temp;
		    	}
			}
		}
	}


	public static void yetaPfLife() {
		/* Calculation of Yeta, PF, Life for each Revision
		 * 
		 */
		meanLifeUnRepairedParts = 0;
		yeta =0;
		lifeMean = 0;
		Pdf = 0;
		Pf = 0;
		for(int i = 0; i < 3; i++)varDistribution[i] = 0;
		
		for(int cnt = 0; cnt < 6; cnt++){
			
			try {
				YetaPfLifeModel(false,false,cnt);
			} catch (IOException e) {
				e.printStackTrace();
			}
			//weighted average of yeta, lifemean, Pdf, Pf, std
			yeta = yeta + (PM[cnt] * yetaSum );
			lifeMean = lifeMean + (PM[cnt] * lifeMeanSum);
			Pdf = Pdf + (PM[cnt] * probabilityDistributionFunctionSum);
			Pf = Pf + (PM[cnt] * cumulativeDistributionFunctionSum);
			for(int i = 0; i < 3; i++){
				varDistribution[i] = varDistribution[i] + (PM[cnt] * varDistributionSum[i]);
			}
		}
		//StdevLife_UnRepairedParts = PM(1) * stdev_life_s + PM(2) * stdev_life_f + PM(3) * stdev_life_mixed + PM(4) * stdev_life_suspension + PM(5) * stdev_life_25Q + PM(6) * stdev_life_75Q
		meanLifeUnRepairedParts = lifeMean ;
		
	}

	
	public static void YetaPfLifeModel(boolean repairFlag, boolean modelUpdate, int estimatesInput) throws IOException{
		//drillHrsForModelUpdate change to model update flag and do calculation in getLifeSingleRevision()
		/* Calculation of Yeta, PF, Life for each Estimate
		 * 
		 */
		Inputs.modelUpdate = modelUpdate;
		double stdevLifeUnRepairedParts = 0;
		
		yetaSum = 0;
		lifeMeanSum = 0;
		probabilityDistributionFunctionSum = 0;
		cumulativeDistributionFunctionSum = 0;
		varDistributionSum[0] = 0;
		varDistributionSum[1] = 0;
		varDistributionSum[2] = 0;
		
		for (int i =0; i< Inputs.proportionDrill.length; i++){
			if (Inputs.proportionDrill[i] > 0.000001){	
				Inputs.estimateCirc = ModelValues.revValues[i].estimateCirc;
				Inputs.estimateMean = ModelValues.revValues[i].estimateMean;
				Inputs.estimateStdDev = ModelValues.revValues[i].estimateStdDev;
				Inputs.estimateLB = ModelValues.revValues[i].estimateLB;
				Inputs.estimateUB = ModelValues.revValues[i].estimateUB;
				Inputs.distributionType = ModelValues.revValues[i].distributionType;
				
				try {
					getRevisionValues(Inputs.proportionDrill[i],estimatesInput);
				} catch (IOException e) {
					e.printStackTrace();
				}
			}
		}

		if (Inputs.repairFlag && repairFlag){
			//Total drilling hour at last repair
			ModelWeight.earlierEstimate = estimatesInput;
			if(Inputs.TotaldrillingHours > (meanLifeUnRepairedParts + stdevLifeUnRepairedParts)){
				ModelWeight.repairFlag = true;
				try {
					getRevisionValues(repairEnhancementFactor, 1);
					getRevisionValues(repairEnhancementFactor, 0);//keep updating yeta and lifemean and std mean and pf
				} catch (IOException e) {
					e.printStackTrace();
				}
				ModelWeight.repairFlag = false;
			}
		}
	    if (lifeMeanSum > Inputs.maxOperatingTime) {
	    	lifeMeanSum = Inputs.maxOperatingTime;
	    }
	    if (lifeMeanSum < getLifeSingleRevision.minOperatingTime) {
	    	lifeMeanSum = getLifeSingleRevision.minOperatingTime;
	    }
	}
		
	public static void getRevisionValues(double multFactor, int estimatesInput) throws IOException{
		
		if (repairFlag) {
			new getLifeSingleRevision(estimatesInput, 1);
			multFactor = 0.25;
		}else{
			new getLifeSingleRevision(estimatesInput, multFactor);
		}
		//keep updating yeta and lifemean and std mean and pf
		yetaSum = yetaSum + (getLifeSingleRevision.yeta * multFactor);
		lifeMeanSum = lifeMeanSum + (getLifeSingleRevision.lifeMean * multFactor);
		
		probabilityDistributionFunctionSum = probabilityDistributionFunctionSum + (getLifeSingleRevision.probabilityDistributionFunction * multFactor);
		cumulativeDistributionFunctionSum = cumulativeDistributionFunctionSum + (getLifeSingleRevision.cumulativeDistributionFunction * multFactor);

		varDistributionSum[0] = varDistributionSum[0] + (getLifeSingleRevision.varDistribution[0] * multFactor);
		varDistributionSum[1] = varDistributionSum[1] + (getLifeSingleRevision.varDistribution[1] * multFactor);
		varDistributionSum[2] = varDistributionSum[2] + (getLifeSingleRevision.varDistribution[2] * multFactor);
	}
	
	public void GetOriginalLat_Temp(Integer rowID){

		getSeverityMCS("Temperature",ModelValues.tempSeverityModel);
		getSeverityMCS("Lateral",ModelValues.latSeverityModel);
		getSeverityMCS("StickSlip",ModelValues.stSlipSeverityModel);
		
		double correctedNormTemp = calcTempCorrections(15, Inputs.TotaldrillingHours, Inputs.circHours, Inputs.temperature1);
		
		double[] latLin = {0.25,0.75,1.5,2.5,4,6.5,11.5,22.5};
		//double[] latLin = {0.1,0.120224719,0.150561797,0.191011235,0.251685392,0.352808987,0.555056177,0.999999995};
		double[] tempLin = {50,105,137.5,157.5,170,180,192.5,225};
		//double[] tempLin = {0.10001,0.382875,0.5500225,0.6528825,0.71717,0.7686,0.8328875,1.000035};
		double[] stSlipLin = {0.1,0.3,0.5,0.7,0.9,1.1,1.6,3};
		//double[] stSlipLin = {0.100000483,0.162069448,0.224138414,0.28620738,0.348276345,0.410345311,0.565517725,1.000000484};
		
		cumulativeLat = 0;
		cumulativeStSlip = 0;
		cumulativeTemp = 0;
		double LateralVibSeverity = 0;
		double stickSlipSeverity = 0;
		double tempSeverity = 0;
		double SumLateral = 0;
		double SumStSlip = 0;
		double SumTemp = 0;
		
	    for(int j = 0; j < 8; j++){
	    	LateralVibSeverity = LateralVibSeverity + Inputs.lateral[j] * latLin[j];
	    	stickSlipSeverity = stickSlipSeverity + Inputs.stickSlip[j] * stSlipLin[j];
	    	tempSeverity = tempSeverity + Inputs.temperature[j] * tempLin[j];
	    	SumLateral = SumLateral + Inputs.lateral[j];
	    	SumTemp = SumTemp +  Inputs.temperature[j];
	    	SumStSlip = SumStSlip + Inputs.stickSlip[j];
	    }
	    cumulativeLat = LateralVibSeverity / SumLateral;
		cumulativeStSlip = stickSlipSeverity / SumStSlip;
		cumulativeTemp = tempSeverity / SumTemp;
		
	    /*
		cumulativeLat = getOriginalVal(ModelValues.latSeverityModel, LateralC, LateralA, Inputs.lateral1);
		cumulativeStSlip = getOriginalVal(ModelValues.stSlipSeverityModel, StickSlipC, StickSlipA, Inputs.stickSlip1);
		if (ModelValues.tempSeverityModel.toLowerCase().equals("linear")){
			cumulativeTemp = getOriginalVal(ModelValues.tempSeverityModel, TemperatureC, TemperatureA, correctedNormTemp);
		}else{
			cumulativeTemp = getOriginalVal(ModelValues.tempSeverityModel, TemperatureA, TemperatureC, correctedNormTemp);
		}*/
	}


	public double getOriginalVal(String severity, double C, double A, double norm){
		double retVal = 0;
		
		switch(severity.toLowerCase()){
		case "linear":
			retVal = ((norm - C)/A);
			break;
		case "lognormal":
			retVal = Math.exp((norm - C)/A);
			break;
		case "exponential":
			if (norm > 0)
				retVal = (Math.log(norm/A) / C);
			else
				retVal = 0;
			break;
		}
		return retVal;
	}
	
	public static String getSeverity(String attribute){
		switch (attribute){
		case "Temperature":
			return "Exp";
		default:
			return "Log";
		}
	}
	
	public void setDrillHrsForModelUpdate() {
		Inputs.drillHrsForModelUpdate = Inputs.aveFailureHrsSus;
	}

	public double LateralC, LateralA, TemperatureC, TemperatureA , StickSlipC, StickSlipA ;
	
	public void getSeverityMCS(String attribute, String severity){
		
		switch (attribute) {
			case "Lateral":
				switch(severity.toLowerCase()){
				case "lognormal":
					LateralA = Inputs.latSeverityLogA;
		        	LateralC = Inputs.latSeverityLogC;
		        	break;	
				case "linear":
					LateralA = Inputs.latSeverityLinA;
		        	LateralC = Inputs.latSeverityLinC;
		        	break;	
				case "exponential":
					LateralA = Inputs.latSeverityExpA;
		        	LateralC = Inputs.latSeverityExpC;
		        	break;
				}
				break;
			case "Temperature":
				switch(severity.toLowerCase()){
				case "lognormal":
					TemperatureA = Inputs.tempSeverityLogA;
					TemperatureC = Inputs.tempSeverityLogC;
		        	break;	
				case "linear":
					TemperatureA = Inputs.tempSeverityLinA;
					TemperatureC = Inputs.tempSeverityLinC;
		        	break;	
				case "exponential":
					TemperatureA = Inputs.tempSeverityExpA;
		        	TemperatureC = Inputs.tempSeverityExpC;
		        	break;	
				}
				break;
			case "StickSlip":
				switch(severity.toLowerCase()){
				case "lognormal":
					StickSlipA = Inputs.stSlSeverityLogA;
					StickSlipC = Inputs.stSlSeverityLogC;
		        	break;	
				case "linear":
					StickSlipA = Inputs.stSlSeverityLinA;
					StickSlipC = Inputs.stSlSeverityLinC;
		        	break;	
				case "exponential":
					StickSlipA = Inputs.stSlSeverityExpA;
					StickSlipC = Inputs.stSlSeverityExpC;
		        	break;	
				}
				break;
			}
	}
	
	
	public void GetInitialModelWeightTemp(double[] PM, double[][] InputArrTemp, double DecisionVal, boolean CheckRunStatusColOnHistory)
	{
		double Diff_Hrs[] = {0,0,0,0,0,0,0};
		double weight_temp[] = {0,0,0,0,0,0,0};
		double[][] InputArr_prev = new double[6][2];
		double OpsVarDependence_Weights[][] = new double[6][2];
		double m_slope,c_intercept;
		double Curr_Drill_Hrs = 0;
		int i = 0;				
		double minweight =0.0;
		double SumWeight = 0.0;
		double max_diff = -10000;
		double min_diff = 10000;
		
		Curr_Drill_Hrs = Inputs.TotaldrillingHours;		
    
	    for (i = 0;i<6;i++)
	    {
	        InputArr_prev[i][0] = InputArrTemp[i][0];
	        InputArr_prev[i][1] = InputArrTemp[i][1];
	        Diff_Hrs[i] = Curr_Drill_Hrs - InputArrTemp[i][0];
	        InputArrTemp[i][0] = Diff_Hrs[i];
	        if (Diff_Hrs[i] > max_diff)
	        {
	            max_diff = Diff_Hrs[i];
	        }
	        if (Diff_Hrs[i] < min_diff)
	        {
	            min_diff = Diff_Hrs[i];
	        }
	    }
        
	    m_slope = 0.9 / (max_diff - min_diff);
	    c_intercept = 0.1 - m_slope * min_diff;
	    
	    sort2DArray(InputArrTemp, 6);
	    double Sum_weight = 0.0;
	    for (i = 0;i< 6;i++)
	    {
	        InputArrTemp[i][0]  = InputArrTemp[i][0]  * m_slope + c_intercept;
	        if (DecisionVal > 0 || CheckRunStatusColOnHistory == true)
	        {
	            weight_temp[i] = 1 * InputArrTemp[i][0];
	        }
	        else
	        {
	            weight_temp[i] = 1 / InputArrTemp[i][0];
	        }
	        Sum_weight = Sum_weight + weight_temp[i];
	    }
	    
	    double axial_factor = GetCummulativeAxial();
	    if (DecisionVal > 0 && CheckRunStatusColOnHistory == true)
	    {
	        minweight = 0.05 / axial_factor;
	    }
	    else if(DecisionVal > 0 || CheckRunStatusColOnHistory == true)
	    {
	        minweight = 0.09 / axial_factor;
	    }
	    else
	    {
	        minweight = 0.12 / axial_factor;
	    }
	    	    
	    GetModWeightVs_AllOperatingVar(InputArr_prev, OpsVarDependence_Weights, minweight);
	    
	    double Diff_Weight = (1.0 - minweight * 6.0) / Sum_weight;
	    double PMSum = 0.0;
	    int index = 0;
	    for (i = 0;i<6;i++)
	    {
	    	index = (int) InputArrTemp[i][1];
	        if (DecisionVal > 0 || CheckRunStatusColOnHistory == true)
	        {
	            PM[index] = minweight + InputArrTemp[i][0] * Diff_Weight;
	        }
	        else
	        {
	            PM[index] = minweight + Diff_Weight / InputArrTemp[i][0];
	        }
	        PM[index] = (PM[index] + OpsVarDependence_Weights[index][0]) / 2;
	        PMSum = PMSum + PM[index];
	    }   
	}
	
	
	
	public double GetModWeightVs_AllOperatingVar(double[][] InputArrTempprev,double[][] OpsVarDependence_Weights,double minweight)
	{
        int i = 0;      
	    double temp_ave_max = Inputs.aveTemperature  + 2 * Inputs.stdTemperature;
	    double lat_ave_max = Inputs.aveLateral  + 2 * Inputs.stdLateral; 
	    double stsl_ave_max = Inputs.aveStickSlip  + 2 * Inputs.stdStickSlip;
	    
	    double temp_ave_min =  Inputs.aveTemperature  - Inputs.stdTemperature; 
	    double lat_ave_min = Inputs.aveLateral  - Inputs.stdLateral;
	    double stsl_ave_min = Inputs.aveStickSlip  - Inputs.stdStickSlip;	    
	    		
	    double temp_1 = Inputs.temperature1;
	    double stsl_1 = Inputs.stickSlip1;
	    double lat_1 =Inputs.lateral1;
	    double CurrDrillHrs = Inputs.TotaldrillingHours;
	    
	    double MaxOperatingTime = Inputs.maxOperatingTime;
	    double AveOperatingTime = Inputs.aveFailureTime;
	    
	    double ModWeightHours = GetModWeightVsVar(MaxOperatingTime, AveOperatingTime, CurrDrillHrs, minweight,1.0);
	    double ModWeightTemp = GetModWeightVsVar(temp_ave_max, temp_ave_min, temp_1, minweight,1.0);
	    double ModWeightLat = GetModWeightVsVar(lat_ave_max, lat_ave_min, lat_1, minweight,1.0);
	    double ModWeightstsl = GetModWeightVsVar(stsl_ave_max, stsl_ave_min, stsl_1, minweight,1.0);
	    
	    double GetModWeightVs_AllOperatingVar = (ModWeightHours + ModWeightTemp + ModWeightLat + ModWeightstsl)/4.0;
	    
	    sort2DArray(InputArrTempprev, 6);
	    double m_slope = (GetModWeightVs_AllOperatingVar - minweight) / (InputArrTempprev[0][0] - InputArrTempprev[5][0]);
	    double c_intercept = minweight - m_slope * InputArrTempprev[5][0];
	    
	    double SumWeight = 0.0;
	    int index1 = 0;	   
	    for(i = 0;i<6;i++)
	    {
	    	index1 = (int) InputArrTempprev[i][1];	    	
	        OpsVarDependence_Weights[index1][0] = InputArrTempprev[i][0] * m_slope + c_intercept;
	        OpsVarDependence_Weights[index1][1] = index1;
	        SumWeight = SumWeight + OpsVarDependence_Weights[index1][0];
	    }
	    
	    for(i = 0;i<6;i++)
	    {
	        OpsVarDependence_Weights[i][0] = OpsVarDependence_Weights[i][0] / SumWeight;
	    }
	    GetModWeightVs_AllOperatingVar = SumWeight;
	    return GetModWeightVs_AllOperatingVar;
	}	
}